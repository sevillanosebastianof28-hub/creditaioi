// ORACLE Scoring Edge Function — supabase/functions/oracle-score/index.ts
// Full causal scoring pipeline with Claude explanation + Realtime delivery

import { createClient } from "npm:@supabase/supabase-js@2";
import Anthropic from "npm:@anthropic-ai/sdk";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Content-Type": "application/json",
};

// Causal priors: [cause, effect, direction, strength]
const PRIORS: [string,string,string,number][] = [
  ["revolving_utilization",   "probability","increases_risk",0.74],
  ["missed_payments_12m",     "probability","increases_risk",0.88],
  ["derogatory_marks",        "probability","increases_risk",0.91],
  ["gambling_amount",         "probability","increases_risk",0.55],
  ["cash_flow_stress",        "probability","increases_risk",0.77],
  ["dti_ratio",               "probability","increases_risk",0.65],
  ["inquiries_6m",            "probability","increases_risk",0.42],
  ["income_norm",             "probability","decreases_risk",0.58],
  ["income_stability",        "probability","decreases_risk",0.64],
  ["loan_payment_regularity", "probability","decreases_risk",0.68],
  ["oldest_account_norm",     "probability","decreases_risk",0.55],
  ["income_verified",         "probability","decreases_risk",0.38],
];

const ECOA: Record<string,string> = {
  revolving_utilization:   "Proportion of balances to credit limits is too high",
  missed_payments_12m:     "Delinquent past or present credit obligations",
  derogatory_marks:        "Derogatory public record or collection filed",
  inquiries_6m:            "Too many inquiries in the last 12 months",
  dti_ratio:               "Ratio of debt to income",
  income_norm:             "Insufficient income",
  cash_flow_stress:        "Insufficient balance in deposit accounts",
  gambling_amount:         "Proportion of income dedicated to discretionary expenses",
};

function probToScore(p: number) {
  return Math.round(Math.max(300, Math.min(850, 580 - Math.log(p/(1-p+1e-9))*80)));
}

function encodeFeatures(f: any, m: any): Record<string,number> {
  const txns: any[] = f.transactions || [];
  const now = Date.now();
  const dAgo = (d: string) => Math.floor((now - new Date(d).getTime())/86400000);
  const debits = txns.filter(t=>t.type==="debit");
  const credits = txns.filter(t=>t.type==="credit");
  const spendW = (d: number) => debits.filter(t=>dAgo(t.date)<=d).reduce((s:number,t:any)=>s+Math.abs(t.amount),0);
  const income = f.stated_income || 4000;
  const spend30 = spendW(30), spend60 = spendW(60);

  let deficits = 0;
  for(let mo=0;mo<12;mo++){
    const md = debits.filter(t=>dAgo(t.date)>=mo*30&&dAgo(t.date)<(mo+1)*30).reduce((s:number,t:any)=>s+t.amount,0);
    const mc = credits.filter(t=>dAgo(t.date)>=mo*30&&dAgo(t.date)<(mo+1)*30).reduce((s:number,t:any)=>s+t.amount,0);
    if(md>mc*1.1)deficits++;
  }

  const gambling90 = debits.filter(t=>t.category==="gambling"&&dAgo(t.date)<=90).reduce((s:number,t:any)=>s+t.amount,0);
  const atm30 = debits.filter(t=>t.category==="atm_cash"&&dAgo(t.date)<=30).length;

  const moInc = Array.from({length:12},(_,mo)=>credits.filter(t=>dAgo(t.date)>=mo*30&&dAgo(t.date)<(mo+1)*30).reduce((s:number,t:any)=>s+t.amount,0));
  const avgInc = moInc.reduce((a,b)=>a+b,0)/12||1;
  const stdInc = Math.sqrt(moInc.reduce((s,v)=>s+Math.pow(v-avgInc,2),0)/12);
  const incomeStability = 1/(1+stdInc/avgInc);

  const loanPmts = debits.filter(t=>t.category==="loan_payment").sort((a,b)=>new Date(a.date).getTime()-new Date(b.date).getTime());
  let loanReg = 0.5;
  if(loanPmts.length>=2){
    const gaps=loanPmts.slice(1).map((t,i)=>(new Date(t.date).getTime()-new Date(loanPmts[i].date).getTime())/86400000);
    const ag=gaps.reduce((a,b)=>a+b,0)/gaps.length;
    const sg=Math.sqrt(gaps.reduce((s,g)=>s+Math.pow(g-ag,2),0)/gaps.length);
    loanReg=1/(1+sg/30);
  }

  return {
    revolving_utilization: f.revolving_utilization||0.5,
    missed_payments_12m: Math.min(f.missed_payments_12m||0,12)/12,
    missed_payments_24m: Math.min(f.missed_payments_24m||0,24)/24,
    derogatory_marks: Math.min(f.derogatory_marks||0,10)/10,
    inquiries_6m: Math.min(f.inquiries_6m||0,10)/10,
    oldest_account_norm: Math.min(f.oldest_account_months||0,360)/360,
    total_accounts_norm: Math.min(f.total_accounts||5,30)/30,
    income_norm: Math.min(income,50000)/50000,
    income_verified: f.income_verified?1:0,
    employment_months_norm: Math.min(f.employment_months||0,120)/120,
    dti_ratio: Math.min((f.total_balance||0)*0.025/Math.max(income,1),2),
    income_stability: incomeStability,
    cash_flow_stress: deficits/12,
    loan_payment_regularity: loanReg,
    gambling_amount: Math.min(gambling90,5000)/5000,
    atm_frequency: Math.min(atm30,20)/20,
    spend_velocity: spend30/Math.max(spend60-spend30,1),
    macro_fed_rate: (m.fed_funds_rate||5.25)/10,
    macro_cpi: (m.cpi_yoy||3.2)/15,
    macro_unemployment: (m.unemployment_rate||3.9)/15,
    macro_sector_stress: m.sector_stress||0.2,
  };
}

function computeScore(fMap: Record<string,number>) {
  let prob = 0.15;
  for(const [cause,,direction,strength] of PRIORS){
    if(PRIORS.find(p=>p[0]===cause&&p[1]==="probability")){
      const val = fMap[cause]??0;
      prob += direction==="increases_risk" ? val*strength*0.08 : -val*strength*0.08;
    }
  }
  return Math.max(0.01,Math.min(0.99,prob));
}

function getFactors(fMap: Record<string,number>, prob: number) {
  return PRIORS
    .filter(p=>p[1]==="probability")
    .map(([cause,,direction,strength])=>{
      const val=fMap[cause]??0;
      const impact=direction==="increases_risk"?val*strength:(1-val)*strength;
      return {feature:cause,direction,causal_weight:strength,impact:Math.round(impact*1000)/1000,value:Math.round(val*1000)/1000};
    })
    .filter(f=>f.impact>0.04)
    .sort((a,b)=>b.impact-a.impact)
    .slice(0,6);
}

function getCFs(fMap: Record<string,number>, prob: number) {
  const targets: [string,number,string][] = [
    ["revolving_utilization",0.3,"Pay down credit cards to below 30% utilization"],
    ["missed_payments_12m",0,"Bring all accounts current immediately"],
    ["inquiries_6m",0,"Stop applying for new credit for 6 months"],
    ["gambling_amount",0,"Eliminate all gambling transactions"],
    ["dti_ratio",0.36,"Pay down debt to bring DTI below 36%"],
    ["loan_payment_regularity",1.0,"Set up autopay for all loan payments"],
  ];
  return targets.flatMap(([feat,target,desc])=>{
    const cur=fMap[feat]??0; if(Math.abs(cur-target)<0.02)return[];
    const prior=PRIORS.find(p=>p[0]===feat&&p[1]==="probability");
    if(!prior)return[];
    const [,,dir,str]=prior;
    const delta=dir==="increases_risk"?(cur-target)*str*0.3:(target-cur)*str*0.3;
    const newProb=Math.max(0.01,Math.min(0.99,prob-delta));
    const ns=probToScore(newProb), os=probToScore(prob);
    if(ns<=os)return[];
    return [{feature:feat,description:desc,new_score:ns,score_improvement:ns-os}];
  }).sort((a,b)=>b.score_improvement-a.score_improvement).slice(0,4);
}

function getTrajectory(prob: number, fMap: Record<string,number>) {
  const out: any = {};
  for(const h of [3,6,12]){
    const mDecay=(fMap["missed_payments_12m"]||0)*Math.pow(0.93,h);
    const histG=Math.min(1,(fMap["oldest_account_norm"]||0)+h/360);
    const incE=((fMap["income_stability"]||0.5)-0.5)*0.015*h;
    const pDelta=(fMap["missed_payments_12m"]||0-mDecay)*-0.25+incE*-0.3;
    const pNew=Math.max(0.01,Math.min(0.99,prob+pDelta));
    const ns=probToScore(pNew), os=probToScore(prob);
    out[`month_${h}`]={predicted_score:ns,score_delta:ns-os,change_direction:ns>os?"improving":"worsening"};
  }
  return out;
}

async function llmExplain(score:number,prob:number,riskType:string,cfs:any[],traj:any,key:string){
  const ac=new Anthropic({apiKey:key});
  const t12=traj["month_12"];
  const cfText=cfs.slice(0,2).map(c=>c.description).join("; ");
  try{
    const r=await ac.messages.create({
      model:"claude-haiku-4-5-20251001",max_tokens:280,
      messages:[{role:"user",content:
        `Credit score: ${score}/850. Risk type: ${riskType}. Top actions: ${cfText||"maintain behavior"}. ` +
        `12-month forecast: ${t12?.change_direction} by ${Math.abs(t12?.score_delta||0)} pts.\n\n` +
        `Write 2 short paragraphs: (1) warm plain-English explanation of this result, (2) single most impactful action. ` +
        `Never mention the word "default" or raw probability numbers.`
      }]
    });
    const text=((r.content.find(b=>b.type==="text") as any)?.text||"").split("\n\n");
    return {explanation:text[0]?.trim()||"",improvement_plan:text[1]?.trim()||""};
  }catch{
    return {
      explanation:`Your credit score of ${score} reflects your current financial standing. ${score>=700?"You are in a healthy position.":"There are concrete steps to improve."}`,
      improvement_plan:cfs[0]?.description||"Make all payments on time and reduce credit utilization."
    };
  }
}

Deno.serve(async(req:Request)=>{
  if(req.method==="OPTIONS")return new Response(null,{headers:CORS});
  const t0=Date.now();
  try{
    const body=await req.json();
    const {application_id,applicant_id,features={},macro_context={}}=body;
    if(!application_id)return new Response(JSON.stringify({error:"application_id required"}),{status:400,headers:CORS});

    const macro={fed_funds_rate:5.25,cpi_yoy:3.2,unemployment_rate:3.9,credit_spread:105,hpi_yoy:3.5,sector_stress:0.2,...macro_context};
    const fMap=encodeFeatures(features,macro);
    const probability=computeScore(fMap);
    const score=probToScore(probability);
    const factors=getFactors(fMap,probability);
    const cfs=getCFs(fMap,probability);
    const traj=getTrajectory(probability,fMap);

    const riskType=probability<0.15?"low":(fMap["cash_flow_stress"]||0)>0.4?"liquidity":(fMap["gambling_amount"]||0)>0.3?"behavioral":(fMap["macro_sector_stress"]||0)>0.5?"systemic":"structural";
    const severity=probability>0.65?"critical":probability>0.40?"high":probability>0.25?"medium":"low";
    const adverseReasons=probability>0.35?factors.filter(f=>f.direction==="increases_risk").slice(0,4).map(f=>ECOA[f.feature]||"See application").filter(Boolean):[];

    const apiKey=Deno.env.get("ANTHROPIC_API_KEY")||"";
    const {explanation,improvement_plan}=apiKey?await llmExplain(score,probability,riskType,cfs,traj,apiKey):{explanation:"",improvement_plan:""};

    const result={
      score,probability:Math.round(probability*10000)/10000,
      confidence_low:probToScore(Math.min(0.99,probability+0.07)),
      confidence_high:probToScore(Math.max(0.01,probability-0.07)),
      risk_type:riskType,risk_severity:severity,
      causal_factors:factors,counterfactuals:cfs,trajectory:traj,
      fair:probability<0.95&&probability>0.02,
      adverse_action_reasons:adverseReasons,
      explanation,improvement_plan,
      model_version:"oracle-v1.0.0",
      inference_ms:Date.now()-t0,
    };

    const sb=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    await sb.from("credit_scores").upsert({
      application_id,applicant_id,
      ...result,
      causal_factors:JSON.stringify(factors),
      counterfactuals:JSON.stringify(cfs),
      trajectory:JSON.stringify(traj),
      adverse_action_reasons:JSON.stringify(adverseReasons),
      scored_at:new Date().toISOString(),
    });

    return new Response(JSON.stringify({...result,status:"scored"}),{headers:CORS});
  }catch(e:any){
    return new Response(JSON.stringify({error:e.message}),{status:500,headers:CORS});
  }
});
