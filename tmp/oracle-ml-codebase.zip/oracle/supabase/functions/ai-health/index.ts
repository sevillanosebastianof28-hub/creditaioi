// supabase/functions/ai-health/index.ts
// Health check for ORACLE model + all AI services

const CORS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Content-Type":                 "application/json",
};

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });

  const t0 = Date.now();
  const checks: Record<string, any> = {};

  // ── Check ONNX model ────────────────────────────────────────────────────
  try {
    const { InferenceSession, Tensor } = await import("npm:onnxruntime-web@1.17.1");
    const sess   = await InferenceSession.create("./oracle_ensemble.onnx");
    const dummy  = new Tensor("float32", new Float32Array(512), [1, 512]);
    const t_infer = Date.now();
    await sess.run({ input: dummy });
    checks.onnx_runtime = { status: "ok", latency_ms: Date.now() - t_infer };
  } catch (e: any) {
    checks.onnx_runtime = { status: "degraded", error: e.message };
  }

  // ── Check Anthropic API key ──────────────────────────────────────────────
  const apiKey = Deno.env.get("ANTHROPIC_API_KEY");
  checks.anthropic_key = apiKey && apiKey.length > 10
    ? { status: "configured" }
    : { status: "missing", error: "ANTHROPIC_API_KEY not set" };

  // ── Check Supabase connection ────────────────────────────────────────────
  try {
    const { createClient } = await import("npm:@supabase/supabase-js@2");
    const sb = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );
    await sb.from("credit_scores").select("id").limit(1);
    checks.supabase = { status: "ok" };
  } catch (e: any) {
    checks.supabase = { status: "degraded", error: e.message };
  }

  // ── Read model version ───────────────────────────────────────────────────
  let version = "unknown";
  try {
    version = await Deno.readTextFile("./model_version.txt");
    version = version.trim();
  } catch {}

  const allOk = Object.values(checks).every((c: any) =>
    c.status === "ok" || c.status === "configured"
  );

  const response = {
    status:        allOk ? "ok" : "degraded",
    model_version: version,
    total_ms:      Date.now() - t0,
    checks,
    timestamp:     new Date().toISOString(),
  };

  return new Response(JSON.stringify(response, null, 2), {
    status:  allOk ? 200 : 503,
    headers: CORS,
  });
});
