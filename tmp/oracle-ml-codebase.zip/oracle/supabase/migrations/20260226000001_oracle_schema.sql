-- supabase/migrations/20260226000001_oracle_schema.sql
-- =====================================================
-- ORACLE Credit Intelligence Schema
-- Full schema for credit-ai.com
-- Run: supabase db push

-- ── Enable required extensions ─────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── Credit Applications ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS credit_applications (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  applicant_id          UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  brand_id              UUID,                        -- white-label tenant
  status                TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','processing','scored','approved','declined','review')),

  -- Application data (stored encrypted)
  stated_income         NUMERIC(12,2),
  stated_expenses       NUMERIC(12,2),
  loan_amount           NUMERIC(12,2),
  loan_purpose          TEXT,
  employment_type       TEXT,
  employment_months     INTEGER,
  application_text      TEXT,

  -- Raw features (512-dim, stored for audit + retraining)
  feature_vector        FLOAT4[],                    -- PostgreSQL float array

  -- Metadata
  ip_address            INET,
  user_agent            TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Credit Scores (ORACLE output) ──────────────────────────────────────────
-- This is the table Supabase Realtime watches.
-- Every INSERT here triggers a WebSocket push to the applicant's browser.
CREATE TABLE IF NOT EXISTS credit_scores (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  application_id        UUID NOT NULL UNIQUE REFERENCES credit_applications(id) ON DELETE CASCADE,
  applicant_id          UUID NOT NULL REFERENCES auth.users(id),
  brand_id              UUID,

  -- Core ORACLE output
  score                 INTEGER NOT NULL CHECK (score BETWEEN 300 AND 850),
  probability           NUMERIC(6,4) NOT NULL,
  confidence_low        INTEGER,
  confidence_high       INTEGER,
  risk_tier             TEXT NOT NULL CHECK (risk_tier IN ('low','medium','high','very_high')),
  risk_type             TEXT CHECK (risk_type IN ('liquidity','behavioral','systemic','mixed')),

  -- Explanation (filled async by Claude)
  explanation           TEXT,
  explanation_status    TEXT DEFAULT 'pending' CHECK (explanation_status IN ('pending','complete','failed')),
  adverse_reasons       JSONB,                       -- ECOA-compliant reasons (if declined)

  -- Detailed ORACLE data (JSON blobs)
  causal_factors        JSONB,
  counterfactuals       JSONB,
  trajectory            JSONB,

  -- Performance metadata
  latency_ms            INTEGER,
  model_version         TEXT,
  fair                  BOOLEAN DEFAULT TRUE,

  -- Outcome tracking (for model retraining)
  actual_outcome        INTEGER,                     -- 1=defaulted, 0=performed (filled later)
  outcome_recorded_at   TIMESTAMPTZ,

  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Macro Context Cache ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS macro_context (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  fed_funds_rate        NUMERIC(5,3),
  cpi_yoy               NUMERIC(5,3),
  unemployment_rate     NUMERIC(5,3),
  consumer_sentiment    NUMERIC(7,3),
  sp500_30d_return      NUMERIC(7,3),
  credit_card_delinquency_rate NUMERIC(5,3),
  valid_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at            TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '24 hours'
);

-- ── Model Registry ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS model_registry (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  version               TEXT NOT NULL UNIQUE,
  auc_roc               NUMERIC(6,4),
  ks_stat               NUMERIC(6,4),
  brier_score           NUMERIC(6,4),
  ece                   NUMERIC(6,4),
  equal_opp_diff        NUMERIC(6,4),
  n_train               INTEGER,
  n_test                INTEGER,
  deployed_at           TIMESTAMPTZ,
  retired_at            TIMESTAMPTZ,
  is_active             BOOLEAN DEFAULT FALSE,
  notes                 TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Prediction Audit Log (immutable — regulatory compliance) ───────────────
CREATE TABLE IF NOT EXISTS prediction_audit_log (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  score_id              UUID NOT NULL REFERENCES credit_scores(id),
  application_id        UUID NOT NULL,
  applicant_id          UUID NOT NULL,
  score                 INTEGER NOT NULL,
  probability           NUMERIC(6,4) NOT NULL,
  model_version         TEXT,
  feature_snapshot      FLOAT4[],                    -- features at time of prediction
  causal_factors        JSONB,
  adverse_reasons       JSONB,
  fair                  BOOLEAN,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
  -- No updates allowed on this table — audit log is immutable
);

-- ── Fairness Monitoring ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fairness_metrics (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  model_version         TEXT NOT NULL,
  brand_id              UUID,
  metric_date           DATE NOT NULL,
  n_scored              INTEGER,
  approval_rate         NUMERIC(6,4),
  disparate_impact      NUMERIC(6,4),
  equal_opp_diff        NUMERIC(6,4),
  passes_80pct_rule     BOOLEAN,
  cfpb_threshold_met    BOOLEAN,
  computed_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ════════════════════════════════════════
-- REALTIME CONFIGURATION
-- ════════════════════════════════════════

-- Enable REPLICA IDENTITY FULL on credit_scores so Realtime can push full row
ALTER TABLE credit_scores REPLICA IDENTITY FULL;
ALTER TABLE credit_applications REPLICA IDENTITY FULL;

-- Grant Realtime access to the tables
ALTER PUBLICATION supabase_realtime ADD TABLE credit_scores;
ALTER PUBLICATION supabase_realtime ADD TABLE credit_applications;

-- ════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ════════════════════════════════════════

-- credit_applications: users see only their own
ALTER TABLE credit_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "applicants_own_applications"
  ON credit_applications FOR ALL
  USING (auth.uid() = applicant_id);

CREATE POLICY "brand_admins_see_applications"
  ON credit_applications FOR SELECT
  USING (
    brand_id IN (
      SELECT brand_id FROM brand_admins WHERE user_id = auth.uid()
    )
  );

-- credit_scores: applicants see their own; brand admins see their tenant's
ALTER TABLE credit_scores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "applicants_own_scores"
  ON credit_scores FOR SELECT
  USING (auth.uid() = applicant_id);

CREATE POLICY "brand_admins_see_scores"
  ON credit_scores FOR SELECT
  USING (
    brand_id IN (
      SELECT brand_id FROM brand_admins WHERE user_id = auth.uid()
    )
  );

-- Edge functions (service role) can write scores
CREATE POLICY "service_role_write_scores"
  ON credit_scores FOR ALL
  USING (auth.role() = 'service_role');

CREATE POLICY "service_role_write_applications"
  ON credit_applications FOR ALL
  USING (auth.role() = 'service_role');

-- audit_log: read-only for admins, write-only for service role
ALTER TABLE prediction_audit_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "service_role_write_audit"
  ON prediction_audit_log FOR INSERT
  USING (auth.role() = 'service_role');

CREATE POLICY "admins_read_audit"
  ON prediction_audit_log FOR SELECT
  USING (auth.role() = 'service_role');

-- macro_context: readable by all authenticated users
ALTER TABLE macro_context ENABLE ROW LEVEL SECURITY;

CREATE POLICY "authenticated_read_macro"
  ON macro_context FOR SELECT
  TO authenticated
  USING (expires_at > NOW());

-- model_registry: readable by all authenticated
ALTER TABLE model_registry ENABLE ROW LEVEL SECURITY;

CREATE POLICY "authenticated_read_models"
  ON model_registry FOR SELECT
  TO authenticated
  USING (TRUE);

-- ════════════════════════════════════════
-- INDEXES
-- ════════════════════════════════════════

CREATE INDEX idx_credit_scores_applicant  ON credit_scores(applicant_id);
CREATE INDEX idx_credit_scores_application ON credit_scores(application_id);
CREATE INDEX idx_credit_scores_brand       ON credit_scores(brand_id);
CREATE INDEX idx_credit_scores_created     ON credit_scores(created_at DESC);
CREATE INDEX idx_applications_applicant    ON credit_applications(applicant_id);
CREATE INDEX idx_applications_brand        ON credit_applications(brand_id);
CREATE INDEX idx_applications_status       ON credit_applications(status);
CREATE INDEX idx_audit_application         ON prediction_audit_log(application_id);

-- ════════════════════════════════════════
-- TRIGGERS
-- ════════════════════════════════════════

-- Auto-update updated_at on any row change
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_credit_scores_updated_at
  BEFORE UPDATE ON credit_scores
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_applications_updated_at
  BEFORE UPDATE ON credit_applications
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto-create audit log entry when a score is inserted
CREATE OR REPLACE FUNCTION create_audit_log()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO prediction_audit_log (
    score_id, application_id, applicant_id, score, probability,
    model_version, causal_factors, adverse_reasons, fair, created_at
  ) VALUES (
    NEW.id, NEW.application_id, NEW.applicant_id, NEW.score, NEW.probability,
    NEW.model_version, NEW.causal_factors, NEW.adverse_reasons, NEW.fair, NOW()
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_audit_on_score
  AFTER INSERT ON credit_scores
  FOR EACH ROW EXECUTE FUNCTION create_audit_log();
