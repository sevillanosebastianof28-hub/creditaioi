-- supabase/migrations/20240101000000_oracle_credit_scores.sql
-- ORACLE Credit Intelligence — Database Schema
-- Run: supabase db push

-- ─── CREDIT APPLICATIONS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS credit_applications (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  applicant_id          UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  brand_id              UUID,                          -- for multi-tenant/white-label
  status                TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','scoring','scored','approved','declined','review')),

  -- Bureau data
  fico_score            INTEGER,
  total_accounts        INTEGER,
  revolving_utilization NUMERIC(5,4),
  missed_payments_12m   INTEGER DEFAULT 0,
  missed_payments_24m   INTEGER DEFAULT 0,
  derogatory_marks      INTEGER DEFAULT 0,
  inquiries_6m          INTEGER DEFAULT 0,
  oldest_account_months INTEGER,
  avg_account_age_months NUMERIC(6,1),
  total_credit_limit    NUMERIC(12,2),
  total_balance         NUMERIC(12,2),

  -- Income & employment
  stated_income         NUMERIC(10,2),
  income_verified       BOOLEAN DEFAULT FALSE,
  employment_months     INTEGER,
  employment_type       TEXT CHECK (employment_type IN ('employed','self-employed','unemployed','retired')),

  -- Loan request
  loan_amount_requested NUMERIC(12,2),
  loan_purpose          TEXT,
  stated_purpose_text   TEXT,

  -- Behavioral (optional)
  app_sessions_30d      INTEGER,
  form_completion_seconds INTEGER,

  -- Metadata
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ip_address            INET,
  user_agent            TEXT
);

-- Enable RLS
ALTER TABLE credit_applications ENABLE ROW LEVEL SECURITY;

-- Applicants see only their own applications
CREATE POLICY "applicant_own_applications" ON credit_applications
  FOR ALL USING (applicant_id = auth.uid());

-- Brand admins see their brand's applications
CREATE POLICY "brand_admin_applications" ON credit_applications
  FOR SELECT USING (
    brand_id IN (
      SELECT brand_id FROM brand_users WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- ─── CREDIT SCORES (ORACLE OUTPUT) ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS credit_scores (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id        UUID NOT NULL REFERENCES credit_applications(id) ON DELETE CASCADE,
  applicant_id          UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,

  -- Core score
  score                 INTEGER NOT NULL CHECK (score BETWEEN 300 AND 850),
  probability           NUMERIC(6,4) NOT NULL,
  confidence_low        INTEGER,
  confidence_high       INTEGER,

  -- Risk classification
  risk_type             TEXT NOT NULL DEFAULT 'structural' CHECK (risk_type IN ('liquidity','behavioral','systemic','structural','low')),
  risk_severity         TEXT NOT NULL DEFAULT 'medium' CHECK (risk_severity IN ('critical','high','medium','low')),
  fair                  BOOLEAN NOT NULL DEFAULT TRUE,

  -- Causal intelligence (JSONB for flexibility)
  causal_factors        JSONB,
  counterfactuals       JSONB,
  trajectory            JSONB,
  adverse_action_reasons JSONB,

  -- LLM explanation
  explanation           TEXT,
  improvement_plan      TEXT,

  -- Decision
  decision              TEXT CHECK (decision IN ('approved','declined','review','conditional')),
  decision_reason       TEXT,
  decision_at           TIMESTAMPTZ,
  decision_by           UUID,

  -- Metadata
  model_version         TEXT NOT NULL DEFAULT 'oracle-v1.0.0',
  inference_ms          INTEGER,
  scored_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable Realtime for instant frontend delivery
ALTER TABLE credit_scores REPLICA IDENTITY FULL;

-- Enable RLS
ALTER TABLE credit_scores ENABLE ROW LEVEL SECURITY;

-- Applicants see only their own scores
CREATE POLICY "applicant_own_scores" ON credit_scores
  FOR SELECT USING (applicant_id = auth.uid());

-- Service role can insert scores (Edge Function uses service role)
CREATE POLICY "service_role_insert_scores" ON credit_scores
  FOR INSERT WITH CHECK (TRUE);  -- Edge Function uses service role key

-- Service role can update scores
CREATE POLICY "service_role_update_scores" ON credit_scores
  FOR UPDATE USING (TRUE) WITH CHECK (TRUE);

-- Add to Supabase Realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE credit_scores;

-- ─── ORACLE AUDIT LOG ───────────────────────────────────────────────────────
-- Immutable audit trail for regulatory compliance (ECOA, FCRA)
CREATE TABLE IF NOT EXISTS oracle_audit_log (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id        UUID NOT NULL,
  score_id              UUID,
  event_type            TEXT NOT NULL, -- 'scored','decision','explanation_generated','fairness_check'
  model_version         TEXT,
  feature_snapshot      JSONB,  -- full feature vector at time of scoring
  probability           NUMERIC(6,4),
  score                 INTEGER,
  fair                  BOOLEAN,
  ecoa_reasons          JSONB,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Audit log is append-only (no updates, no deletes)
ALTER TABLE oracle_audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "no_access" ON oracle_audit_log FOR ALL USING (FALSE);  -- Only service role

-- ─── MACRO INDICATORS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS macro_indicators (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date                  DATE NOT NULL UNIQUE,
  fed_funds_rate        NUMERIC(5,2),
  cpi_yoy               NUMERIC(5,2),
  unemployment_rate     NUMERIC(5,2),
  credit_spread         NUMERIC(8,2),
  hpi_yoy               NUMERIC(5,2),
  sector_stress         NUMERIC(4,3),
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE macro_indicators ENABLE ROW LEVEL SECURITY;
CREATE POLICY "authenticated_read_macro" ON macro_indicators
  FOR SELECT TO authenticated USING (TRUE);

-- ─── BRAND / WHITE-LABEL TABLES ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS brands (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  domain      TEXT UNIQUE,
  theme       JSONB,     -- colors, logo, font preferences
  config      JSONB,     -- feature flags, scoring thresholds
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS brand_users (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id    UUID NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role        TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('admin','member','viewer')),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (brand_id, user_id)
);

ALTER TABLE brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE brand_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "brand_member_read" ON brands
  FOR SELECT USING (
    id IN (SELECT brand_id FROM brand_users WHERE user_id = auth.uid())
  );

CREATE POLICY "brand_user_read" ON brand_users
  FOR SELECT USING (user_id = auth.uid());

-- ─── INDEXES ────────────────────────────────────────────────────────────────
CREATE INDEX idx_credit_applications_applicant ON credit_applications(applicant_id);
CREATE INDEX idx_credit_applications_brand ON credit_applications(brand_id);
CREATE INDEX idx_credit_applications_status ON credit_applications(status);
CREATE INDEX idx_credit_applications_created ON credit_applications(created_at DESC);

CREATE INDEX idx_credit_scores_application ON credit_scores(application_id);
CREATE INDEX idx_credit_scores_applicant ON credit_scores(applicant_id);
CREATE INDEX idx_credit_scores_scored_at ON credit_scores(scored_at DESC);
CREATE INDEX idx_credit_scores_score ON credit_scores(score);
CREATE INDEX idx_credit_scores_risk_type ON credit_scores(risk_type);

CREATE INDEX idx_audit_log_application ON oracle_audit_log(application_id);
CREATE INDEX idx_audit_log_created ON oracle_audit_log(created_at DESC);

CREATE INDEX idx_macro_date ON macro_indicators(date DESC);

-- ─── UPDATED_AT TRIGGER ─────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_credit_applications_updated_at
  BEFORE UPDATE ON credit_applications
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ─── HELPER FUNCTION: Get latest score for application ──────────────────────
CREATE OR REPLACE FUNCTION get_latest_score(p_application_id UUID)
RETURNS TABLE(score INTEGER, risk_type TEXT, explanation TEXT, scored_at TIMESTAMPTZ)
LANGUAGE sql STABLE SECURITY DEFINER AS $$
  SELECT score, risk_type, explanation, scored_at
  FROM credit_scores
  WHERE application_id = p_application_id
  ORDER BY scored_at DESC
  LIMIT 1;
$$;

-- ─── VIEW: Applicant dashboard summary ──────────────────────────────────────
CREATE OR REPLACE VIEW applicant_dashboard AS
SELECT
  ca.id AS application_id,
  ca.applicant_id,
  ca.status,
  ca.loan_amount_requested,
  ca.loan_purpose,
  ca.created_at AS applied_at,
  cs.score,
  cs.risk_type,
  cs.risk_severity,
  cs.confidence_low,
  cs.confidence_high,
  cs.explanation,
  cs.improvement_plan,
  cs.scored_at,
  cs.counterfactuals,
  cs.trajectory
FROM credit_applications ca
LEFT JOIN LATERAL (
  SELECT * FROM credit_scores WHERE application_id = ca.id ORDER BY scored_at DESC LIMIT 1
) cs ON TRUE
WHERE ca.applicant_id = auth.uid();

COMMENT ON TABLE credit_scores IS 'ORACLE ML model output. Realtime-enabled for instant frontend delivery.';
COMMENT ON TABLE credit_applications IS 'Credit application submissions. Source of truth for all scoring.';
COMMENT ON TABLE oracle_audit_log IS 'Immutable audit trail for ECOA/FCRA regulatory compliance.';
