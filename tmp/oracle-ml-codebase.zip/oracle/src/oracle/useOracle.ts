// src/oracle/useOracle.ts
// React hook — submits application, subscribes to Realtime score delivery

import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "../lib/supabase"; // your existing supabase client

// ─── TYPES ──────────────────────────────────────────────────────────────────

export interface ApplicationFeatures {
  fico_score?: number;
  total_accounts?: number;
  revolving_utilization?: number;
  missed_payments_12m?: number;
  missed_payments_24m?: number;
  derogatory_marks?: number;
  inquiries_6m?: number;
  oldest_account_months?: number;
  avg_account_age_months?: number;
  total_credit_limit?: number;
  total_balance?: number;
  stated_income?: number;
  income_verified?: boolean;
  employment_months?: number;
  employment_type?: "employed" | "self-employed" | "unemployed" | "retired";
  loan_amount_requested?: number;
  loan_purpose?: string;
  transactions?: Transaction[];
}

export interface Transaction {
  date: string;
  amount: number;
  merchant: string;
  category: string;
  type: "debit" | "credit";
}

export interface OracleScore {
  score: number;
  probability: number;
  confidence_low: number;
  confidence_high: number;
  risk_type: "liquidity" | "behavioral" | "systemic" | "structural" | "low";
  risk_severity: "critical" | "high" | "medium" | "low";
  causal_factors: CausalFactor[];
  counterfactuals: Counterfactual[];
  trajectory: Trajectory;
  fair: boolean;
  explanation: string;
  improvement_plan: string;
  adverse_action_reasons: string[];
  inference_ms: number;
  model_version: string;
  scored_at: string;
}

export interface CausalFactor {
  feature: string;
  direction: "increases_risk" | "decreases_risk";
  causal_weight: number;
  impact: number;
  value: number;
}

export interface Counterfactual {
  feature: string;
  description: string;
  new_score: number;
  score_improvement: number;
}

export interface Trajectory {
  month_3: TrajectoryPoint;
  month_6: TrajectoryPoint;
  month_12: TrajectoryPoint;
}

export interface TrajectoryPoint {
  predicted_score: number;
  score_delta: number;
  change_direction: "improving" | "worsening";
}

type ScoringStatus = "idle" | "submitting" | "scoring" | "complete" | "error";

// ─── HOOK ────────────────────────────────────────────────────────────────────

export function useOracle() {
  const [status, setStatus] = useState<ScoringStatus>("idle");
  const [score, setScore] = useState<OracleScore | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [applicationId, setApplicationId] = useState<string | null>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Cleanup subscription on unmount
  useEffect(() => {
    return () => {
      if (channelRef.current) channelRef.current.unsubscribe();
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const subscribeToScore = useCallback((appId: string) => {
    // Unsubscribe from any previous channel
    if (channelRef.current) channelRef.current.unsubscribe();

    const channel = supabase
      .channel(`oracle-score-${appId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "credit_scores",
          filter: `application_id=eq.${appId}`,
        },
        (payload) => {
          const raw = payload.new as any;
          // Parse JSONB fields
          const result: OracleScore = {
            ...raw,
            causal_factors: typeof raw.causal_factors === "string"
              ? JSON.parse(raw.causal_factors)
              : raw.causal_factors || [],
            counterfactuals: typeof raw.counterfactuals === "string"
              ? JSON.parse(raw.counterfactuals)
              : raw.counterfactuals || [],
            trajectory: typeof raw.trajectory === "string"
              ? JSON.parse(raw.trajectory)
              : raw.trajectory || {},
            adverse_action_reasons: typeof raw.adverse_action_reasons === "string"
              ? JSON.parse(raw.adverse_action_reasons)
              : raw.adverse_action_reasons || [],
          };
          setScore(result);
          setStatus("complete");
          if (timeoutRef.current) clearTimeout(timeoutRef.current);
          channel.unsubscribe();
        }
      )
      .subscribe((status) => {
        if (status === "SUBSCRIBED") {
          console.log("[ORACLE] Realtime subscribed for", appId);
        } else if (status === "CHANNEL_ERROR") {
          setError("Realtime connection failed. Please refresh.");
          setStatus("error");
        }
      });

    channelRef.current = channel;

    // Timeout: if no score in 30s, show error
    timeoutRef.current = setTimeout(() => {
      if (status !== "complete") {
        setError("Scoring is taking longer than expected. Please wait or refresh.");
        setStatus("error");
      }
    }, 30000);
  }, []);

  const submitApplication = useCallback(async (features: ApplicationFeatures) => {
    setStatus("submitting");
    setScore(null);
    setError(null);

    try {
      // 1. Create application record in DB
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data: app, error: appError } = await supabase
        .from("credit_applications")
        .insert({
          applicant_id: user.id,
          status: "scoring",
          ...features,
          transactions: features.transactions ? JSON.stringify(features.transactions) : null,
        })
        .select("id")
        .single();

      if (appError) throw appError;
      const appId = app.id;
      setApplicationId(appId);

      // 2. Subscribe to Realtime BEFORE calling the edge function
      // (prevents race condition where score arrives before subscription)
      setStatus("scoring");
      subscribeToScore(appId);

      // 3. Call ORACLE scoring edge function
      const { error: fnError } = await supabase.functions.invoke("oracle-score", {
        body: {
          application_id: appId,
          applicant_id: user.id,
          features,
          // Optionally pass current macro context if you have it
          macro_context: {},
        },
      });

      if (fnError) throw fnError;

      // Score will arrive via Realtime — no polling needed

    } catch (e: any) {
      console.error("[ORACLE] Error:", e);
      setError(e.message || "Scoring failed. Please try again.");
      setStatus("error");
    }
  }, [subscribeToScore]);

  const reset = useCallback(() => {
    if (channelRef.current) channelRef.current.unsubscribe();
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setStatus("idle");
    setScore(null);
    setError(null);
    setApplicationId(null);
  }, []);

  return { status, score, error, applicationId, submitApplication, reset };
}
