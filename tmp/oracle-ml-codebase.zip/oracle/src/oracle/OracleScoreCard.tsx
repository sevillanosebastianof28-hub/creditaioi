// src/oracle/OracleScoreCard.tsx
// The main UI component that displays ORACLE results on credit-ai.com
// Drop this into any page: <OracleScoreCard features={...} />

import React, { useState } from "react";
import { useOracle, ApplicationFeatures, OracleScore } from "./useOracle";

// ─── SCORE GAUGE ─────────────────────────────────────────────────────────────

function ScoreGauge({ score, low, high }: { score: number; low: number; high: number }) {
  const pct = (score - 300) / 550; // 300–850 range
  const color = score >= 720 ? "#00d97e" : score >= 650 ? "#f0c040" : score >= 580 ? "#ff8c40" : "#ff4060";
  const label = score >= 720 ? "Excellent" : score >= 650 ? "Good" : score >= 580 ? "Fair" : "Poor";

  const circumference = 2 * Math.PI * 80;
  const dashOffset = circumference * (1 - pct * 0.75); // 270deg arc

  return (
    <div style={{ position: "relative", width: 200, height: 120, margin: "0 auto" }}>
      <svg width={200} height={200} viewBox="0 0 200 200" style={{ position: "absolute", top: -40 }}>
        {/* Track */}
        <circle cx={100} cy={100} r={80} fill="none" stroke="#1e2d42" strokeWidth={16}
          strokeDasharray={`${circumference * 0.75} ${circumference}`}
          strokeDashoffset={circumference * 0.125}
          style={{ transform: "rotate(-225deg)", transformOrigin: "100px 100px" }} />
        {/* Value */}
        <circle cx={100} cy={100} r={80} fill="none" stroke={color} strokeWidth={16}
          strokeLinecap="round"
          strokeDasharray={`${circumference * pct * 0.75} ${circumference}`}
          strokeDashoffset={circumference * 0.125}
          style={{ transform: "rotate(-225deg)", transformOrigin: "100px 100px", transition: "stroke-dasharray 1.2s ease" }} />
        <text x={100} y={108} textAnchor="middle" fill={color}
          style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 38, fontWeight: "bold" }}>
          {score}
        </text>
        <text x={100} y={125} textAnchor="middle" fill="#6a8aaa" style={{ fontSize: 11, letterSpacing: 2 }}>
          {label.toUpperCase()}
        </text>
        <text x={35} y={170} fill="#3a5070" style={{ fontSize: 10 }}>300</text>
        <text x={155} y={170} fill="#3a5070" style={{ fontSize: 10 }}>850</text>
      </svg>
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, textAlign: "center" }}>
        <span style={{ fontSize: 11, color: "#6a8aaa" }}>Range: {low}–{high}</span>
      </div>
    </div>
  );
}

// ─── CAUSAL FACTORS ───────────────────────────────────────────────────────────

function CausalFactorBar({ factor }: { factor: any }) {
  const isRisk = factor.direction === "increases_risk";
  const color = isRisk ? "#ff4060" : "#00d97e";
  const label = factor.feature.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());
  const pct = Math.min(100, factor.impact * 100);

  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: 12 }}>
        <span style={{ color: "#d4e4f4" }}>{label}</span>
        <span style={{ color, fontSize: 11 }}>{isRisk ? "▲ Risk" : "▼ Risk"}</span>
      </div>
      <div style={{ height: 4, background: "#1e2d42", borderRadius: 2, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: color, borderRadius: 2,
          transition: "width 0.8s ease" }} />
      </div>
    </div>
  );
}

// ─── COUNTERFACTUAL CARD ──────────────────────────────────────────────────────

function CounterfactualCard({ cf }: { cf: any }) {
  return (
    <div style={{ background: "#0d1420", border: "1px solid #1e2d42", borderRadius: 10, padding: "14px 16px",
      display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
      <div style={{ flex: 1, fontSize: 13, color: "#d4e4f4", lineHeight: 1.5 }}>{cf.description}</div>
      <div style={{ textAlign: "center", flexShrink: 0 }}>
        <div style={{ fontFamily: "monospace", fontSize: 18, color: "#00d97e", fontWeight: "bold" }}>
          +{cf.score_improvement}
        </div>
        <div style={{ fontSize: 10, color: "#6a8aaa" }}>pts</div>
      </div>
    </div>
  );
}

// ─── TRAJECTORY CHART ─────────────────────────────────────────────────────────

function TrajectoryChart({ trajectory, currentScore }: { trajectory: any; currentScore: number }) {
  const points = [
    { label: "Now", score: currentScore },
    { label: "3mo", ...trajectory.month_3 },
    { label: "6mo", ...trajectory.month_6 },
    { label: "12mo", ...trajectory.month_12 },
  ];

  const scores = points.map(p => p.score || p.predicted_score || currentScore);
  const minS = Math.min(...scores) - 20;
  const maxS = Math.max(...scores) + 20;
  const range = maxS - minS;

  const W = 280, H = 80, pad = 20;
  const xs = points.map((_, i) => pad + (i / (points.length - 1)) * (W - pad * 2));
  const ys = scores.map(s => H - ((s - minS) / range) * (H - 20) - 10);

  const path = xs.map((x, i) => `${i === 0 ? "M" : "L"} ${x} ${ys[i]}`).join(" ");

  return (
    <div>
      <svg width={W} height={H + 24} style={{ overflow: "visible" }}>
        <path d={path} fill="none" stroke="#00d97e" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p, i) => (
          <g key={i}>
            <circle cx={xs[i]} cy={ys[i]} r={4} fill="#00d97e" />
            <text x={xs[i]} y={H + 18} textAnchor="middle" fill="#6a8aaa" style={{ fontSize: 10 }}>
              {p.label}
            </text>
            <text x={xs[i]} y={ys[i] - 8} textAnchor="middle" fill="#d4e4f4" style={{ fontSize: 11 }}>
              {scores[i]}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

// ─── LOADING STATE ────────────────────────────────────────────────────────────

function ScoringLoader() {
  return (
    <div style={{ textAlign: "center", padding: "40px 24px" }}>
      <div style={{ width: 48, height: 48, borderRadius: "50%", border: "3px solid #1e2d42",
        borderTopColor: "#f0c040", animation: "spin 1s linear infinite", margin: "0 auto 16px" }} />
      <div style={{ fontFamily: "monospace", fontSize: 13, color: "#6a8aaa", letterSpacing: 2 }}>
        ORACLE SCORING
      </div>
      <div style={{ fontSize: 12, color: "#3a5070", marginTop: 8 }}>
        Analyzing causal factors...
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// ─── MAIN SCORE RESULT ───────────────────────────────────────────────────────

function OracleResult({ score }: { score: OracleScore }) {
  const [tab, setTab] = useState<"overview" | "factors" | "actions" | "trajectory">("overview");

  const riskColors = { critical: "#ff4060", high: "#ff8c40", medium: "#f0c040", low: "#00d97e" };
  const riskColor = riskColors[score.risk_severity] || "#6a8aaa";

  const styles = {
    card: { background: "#111925", border: "1px solid #1e2d42", borderRadius: 12, padding: "20px 22px", marginBottom: 12 },
    tabBar: { display: "flex", gap: 4, marginBottom: 20, background: "#0d1420", borderRadius: 8, padding: 4 },
    tab: (active: boolean): React.CSSProperties => ({
      flex: 1, padding: "7px 0", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 11,
      letterSpacing: 1, textTransform: "uppercase" as const, fontFamily: "monospace",
      background: active ? "#f0c040" : "transparent",
      color: active ? "#04060a" : "#6a8aaa",
      fontWeight: active ? 700 : 400,
    }),
  };

  return (
    <div style={{ fontFamily: "'JetBrains Mono', monospace", color: "#d4e4f4" }}>

      {/* Score gauge + header */}
      <div style={{ ...styles.card, textAlign: "center" }}>
        <ScoreGauge score={score.score} low={score.confidence_low} high={score.confidence_high} />
        <div style={{ marginTop: 60, display: "flex", justifyContent: "center", gap: 16, flexWrap: "wrap" }}>
          <span style={{ background: `${riskColor}20`, border: `1px solid ${riskColor}60`,
            color: riskColor, borderRadius: 6, padding: "3px 10px", fontSize: 11, letterSpacing: 1 }}>
            {score.risk_type.toUpperCase()} RISK
          </span>
          <span style={{ background: score.fair ? "#00d97e20" : "#ff406020",
            border: `1px solid ${score.fair ? "#00d97e60" : "#ff406060"}`,
            color: score.fair ? "#00d97e" : "#ff4060", borderRadius: 6, padding: "3px 10px", fontSize: 11, letterSpacing: 1 }}>
            {score.fair ? "✓ FAIRNESS PASSED" : "⚠ FAIRNESS REVIEW"}
          </span>
          <span style={{ color: "#6a8aaa", fontSize: 11 }}>
            {score.inference_ms}ms
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div style={styles.tabBar}>
        {(["overview","factors","actions","trajectory"] as const).map(t => (
          <button key={t} style={styles.tab(tab === t)} onClick={() => setTab(t)}>
            {t === "overview" ? "📋" : t === "factors" ? "⚡" : t === "actions" ? "🎯" : "📈"} {t}
          </button>
        ))}
      </div>

      {/* Overview tab */}
      {tab === "overview" && (
        <div>
          {score.explanation && (
            <div style={styles.card}>
              <div style={{ fontSize: 10, letterSpacing: 2, color: "#f0c040", marginBottom: 10 }}>
                ORACLE ASSESSMENT
              </div>
              <p style={{ fontSize: 14, lineHeight: 1.7, color: "#d4e4f4", margin: 0 }}>
                {score.explanation}
              </p>
            </div>
          )}
          {score.improvement_plan && (
            <div style={{ ...styles.card, borderColor: "#2a3f5c" }}>
              <div style={{ fontSize: 10, letterSpacing: 2, color: "#00d97e", marginBottom: 10 }}>
                PRIORITY ACTION
              </div>
              <p style={{ fontSize: 13, lineHeight: 1.6, color: "#d4e4f4", margin: 0 }}>
                {score.improvement_plan}
              </p>
            </div>
          )}
          {score.adverse_action_reasons?.length > 0 && (
            <div style={{ ...styles.card, borderColor: "#ff406040" }}>
              <div style={{ fontSize: 10, letterSpacing: 2, color: "#ff8c40", marginBottom: 10 }}>
                ADVERSE ACTION REASONS (ECOA)
              </div>
              {score.adverse_action_reasons.map((r, i) => (
                <div key={i} style={{ fontSize: 12, color: "#6a8aaa", marginBottom: 6, paddingLeft: 12,
                  borderLeft: "2px solid #1e2d42" }}>
                  {r}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Factors tab */}
      {tab === "factors" && (
        <div style={styles.card}>
          <div style={{ fontSize: 10, letterSpacing: 2, color: "#f0c040", marginBottom: 16 }}>
            CAUSAL RISK FACTORS
          </div>
          {score.causal_factors?.map((f, i) => (
            <CausalFactor key={i} factor={f} />
          ))}
          {(!score.causal_factors || score.causal_factors.length === 0) && (
            <p style={{ color: "#6a8aaa", fontSize: 13 }}>No significant risk factors identified.</p>
          )}
        </div>
      )}

      {/* Actions tab */}
      {tab === "actions" && (
        <div>
          <div style={styles.card}>
            <div style={{ fontSize: 10, letterSpacing: 2, color: "#f0c040", marginBottom: 16 }}>
              WHAT WOULD CHANGE YOUR SCORE
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {score.counterfactuals?.map((cf, i) => (
                <CounterfactualCard key={i} cf={cf} />
              ))}
              {(!score.counterfactuals || score.counterfactuals.length === 0) && (
                <p style={{ color: "#6a8aaa", fontSize: 13 }}>
                  Maintain your current behavior — your profile is already strong.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Trajectory tab */}
      {tab === "trajectory" && (
        <div style={styles.card}>
          <div style={{ fontSize: 10, letterSpacing: 2, color: "#f0c040", marginBottom: 16 }}>
            12-MONTH FORECAST
          </div>
          {score.trajectory && (
            <TrajectoryChart trajectory={score.trajectory} currentScore={score.score} />
          )}
          <div style={{ display: "flex", gap: 8, marginTop: 16, flexWrap: "wrap" }}>
            {Object.entries(score.trajectory || {}).map(([key, val]: [string, any]) => (
              <div key={key} style={{ flex: 1, minWidth: 70, textAlign: "center",
                background: "#0d1420", borderRadius: 8, padding: "12px 8px" }}>
                <div style={{ fontSize: 20, fontFamily: "monospace", fontWeight: "bold",
                  color: val.change_direction === "improving" ? "#00d97e" : "#ff8c40" }}>
                  {val.predicted_score}
                </div>
                <div style={{ fontSize: 10, color: "#6a8aaa", marginTop: 4 }}>
                  {key.replace("month_", "")} mo
                </div>
                <div style={{ fontSize: 10, color: val.change_direction === "improving" ? "#00d97e" : "#ff8c40" }}>
                  {val.score_delta > 0 ? "+" : ""}{val.score_delta}
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 12, fontSize: 11, color: "#3a5070", lineHeight: 1.5 }}>
            * Forecast assumes baseline behavior. Implementing recommended actions may accelerate improvement.
          </div>
        </div>
      )}

      <div style={{ fontSize: 10, color: "#3a5070", textAlign: "center", marginTop: 8 }}>
        ORACLE {score.model_version} · {new Date(score.scored_at).toLocaleString()}
      </div>
    </div>
  );
}

// ─── MAIN EXPORTED COMPONENT ─────────────────────────────────────────────────

interface OracleScoreCardProps {
  initialFeatures?: ApplicationFeatures;
  onScore?: (score: OracleScore) => void;
  compact?: boolean;
}

export function OracleScoreCard({ initialFeatures, onScore, compact = false }: OracleScoreCardProps) {
  const { status, score, error, submitApplication, reset } = useOracle();

  // If features are provided as props, auto-submit
  React.useEffect(() => {
    if (initialFeatures && status === "idle") {
      submitApplication(initialFeatures);
    }
  }, []);

  React.useEffect(() => {
    if (score && onScore) onScore(score);
  }, [score, onScore]);

  const containerStyle: React.CSSProperties = {
    background: "#04060a",
    borderRadius: 16,
    border: "1px solid #1e2d42",
    padding: compact ? 16 : 24,
    maxWidth: compact ? 400 : 560,
    fontFamily: "'JetBrains Mono', monospace",
    position: "relative",
    overflow: "hidden",
  };

  return (
    <div style={containerStyle}>
      {/* Gold top accent */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2,
        background: "linear-gradient(to right, transparent, #f0c040, transparent)" }} />

      {status === "idle" && !initialFeatures && (
        <div style={{ textAlign: "center", padding: 24, color: "#6a8aaa", fontSize: 13 }}>
          Submit an application to get your ORACLE score.
        </div>
      )}

      {(status === "submitting" || status === "scoring") && <ScoringLoader />}

      {status === "error" && (
        <div style={{ background: "#ff406015", border: "1px solid #ff406040",
          borderRadius: 10, padding: 16, textAlign: "center" }}>
          <div style={{ color: "#ff4060", marginBottom: 8, fontSize: 13 }}>{error}</div>
          <button onClick={reset} style={{ background: "#ff4060", color: "#fff",
            border: "none", borderRadius: 6, padding: "8px 16px", cursor: "pointer", fontSize: 12 }}>
            Try Again
          </button>
        </div>
      )}

      {status === "complete" && score && <OracleResult score={score} />}
    </div>
  );
}

export default OracleScoreCard;
