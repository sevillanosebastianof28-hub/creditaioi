// src/components/OracleScoreCard.tsx
// ====================================
// The realtime score display card.
// Shows: animated score dial, confidence interval, risk tier,
// causal factors, counterfactuals, and 12-month trajectory.

import React, { useState, useEffect } from "react";
import type { OracleScoreResult } from "../hooks/useOracleScore";

// ── Score color thresholds ────────────────────────────────────────────────────
function scoreColor(score: number): string {
  if (score >= 720) return "#00e5a0";
  if (score >= 650) return "#f0c040";
  if (score >= 580) return "#ff8c40";
  return "#ff4060";
}

function tierLabel(tier: string): string {
  const labels: Record<string, string> = {
    low:       "Excellent",
    medium:    "Good",
    high:      "Fair",
    very_high: "Poor",
  };
  return labels[tier] ?? tier;
}

// ── Animated Counter ──────────────────────────────────────────────────────────
function AnimatedScore({ target, duration = 1200 }: { target: number; duration?: number }) {
  const [display, setDisplay] = useState(300);

  useEffect(() => {
    const start     = Date.now();
    const startVal  = 300;
    const frame = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // cubic ease-out
      setDisplay(Math.round(startVal + (target - startVal) * eased));
      if (progress < 1) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  }, [target, duration]);

  return <>{display}</>;
}

// ── Score Arc SVG ──────────────────────────────────────────────────────────────
function ScoreArc({ score, color }: { score: number; color: string }) {
  const pct        = (score - 300) / 550; // 0–1
  const radius     = 80;
  const cx         = 100;
  const cy         = 100;
  const startAngle = -220 * (Math.PI / 180);
  const endAngle   = startAngle + (pct * 260 * Math.PI / 180);
  const trackEnd   = startAngle + (260 * Math.PI / 180);

  const arcPath = (from: number, to: number, r: number) => {
    const x1 = cx + r * Math.cos(from);
    const y1 = cy + r * Math.sin(from);
    const x2 = cx + r * Math.cos(to);
    const y2 = cy + r * Math.sin(to);
    const large = (to - from) > Math.PI ? 1 : 0;
    return `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`;
  };

  return (
    <svg width="200" height="200" viewBox="0 0 200 200" style={{ overflow: "visible" }}>
      {/* Track */}
      <path
        d={arcPath(startAngle, trackEnd, radius)}
        fill="none" stroke="#1e2d42" strokeWidth="12" strokeLinecap="round"
      />
      {/* Score arc */}
      <path
        d={arcPath(startAngle, endAngle, radius)}
        fill="none" stroke={color} strokeWidth="12" strokeLinecap="round"
        style={{ filter: `drop-shadow(0 0 8px ${color}80)` }}
      />
      {/* Score label */}
      <text x={cx} y={cy - 8} textAnchor="middle"
        fontFamily="'JetBrains Mono', monospace" fontSize="36" fontWeight="700"
        fill={color}>
        <AnimatedScore target={score} />
      </text>
      <text x={cx} y={cy + 18} textAnchor="middle"
        fontFamily="'JetBrains Mono', monospace" fontSize="11" fill="#6a8aaa"
        letterSpacing="3">
        OUT OF 850
      </text>
    </svg>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

interface Props {
  result:      OracleScoreResult;
  explanation: string;
  latencyMs:   number | null;
  isComplete:  boolean;
}

export function OracleScoreCard({ result, explanation, latencyMs, isComplete }: Props) {
  const [activeTab, setActiveTab] = useState<"overview" | "factors" | "actions" | "forecast">("overview");
  const color = scoreColor(result.score);

  const tabs = [
    { id: "overview",  label: "Score" },
    { id: "factors",   label: "Why" },
    { id: "actions",   label: "Improve" },
    { id: "forecast",  label: "Forecast" },
  ] as const;

  return (
    <div style={{
      background:   "#0d1420",
      border:       `1px solid ${color}30`,
      borderRadius: "16px",
      overflow:     "hidden",
      fontFamily:   "'JetBrains Mono', monospace",
      boxShadow:    `0 0 40px ${color}15`,
    }}>
      {/* Header */}
      <div style={{
        background:    "#111925",
        borderBottom:  `1px solid #1e2d42`,
        padding:       "16px 24px",
        display:       "flex",
        alignItems:    "center",
        justifyContent:"space-between",
      }}>
        <div style={{ fontSize: "11px", letterSpacing: "3px", color: color, textTransform: "uppercase" }}>
          ORACLE ASSESSMENT
        </div>
        <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
          {latencyMs && (
            <span style={{ fontSize: "10px", color: "#3a5070" }}>
              scored in {latencyMs}ms
            </span>
          )}
          <span style={{
            fontSize: "10px", padding: "3px 10px", borderRadius: "20px",
            background: `${color}18`, color, border: `1px solid ${color}40`,
            fontWeight: "700", letterSpacing: "1px",
          }}>
            {tierLabel(result.risk_tier)}
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "1px solid #1e2d42" }}>
        {tabs.map(tab => (
          <button key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              flex:           1,
              padding:        "12px",
              background:     "none",
              border:         "none",
              borderBottom:   activeTab === tab.id ? `2px solid ${color}` : "2px solid transparent",
              color:          activeTab === tab.id ? color : "#3a5070",
              fontSize:       "11px",
              letterSpacing:  "1px",
              textTransform:  "uppercase",
              cursor:         "pointer",
              transition:     "all 0.2s",
              fontFamily:     "inherit",
            }}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ padding: "24px", minHeight: "280px" }}>

        {/* ── OVERVIEW TAB ── */}
        {activeTab === "overview" && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "20px" }}>
            <ScoreArc score={result.score} color={color} />

            {/* Confidence interval */}
            <div style={{
              display: "flex", gap: "16px", fontSize: "12px", color: "#6a8aaa",
              background: "#080c12", borderRadius: "8px", padding: "10px 20px",
              border: "1px solid #1e2d42",
            }}>
              <span>95% CI:</span>
              <span style={{ color: "#d4e4f4" }}>
                {result.confidence_low} – {result.confidence_high}
              </span>
            </div>

            {/* Probability */}
            <div style={{ fontSize: "12px", color: "#6a8aaa" }}>
              Default probability:{" "}
              <span style={{ color: "#d4e4f4" }}>{(result.probability * 100).toFixed(1)}%</span>
            </div>

            {/* Explanation */}
            {explanation ? (
              <div style={{
                background:   "#080c12",
                border:       "1px solid #1e2d42",
                borderLeft:   `3px solid ${color}`,
                borderRadius: "8px",
                padding:      "16px",
                fontSize:     "13px",
                color:        "#d4e4f4",
                lineHeight:   "1.7",
                width:        "100%",
              }}>
                {explanation}
              </div>
            ) : (
              <div style={{ fontSize: "12px", color: "#3a5070", fontStyle: "italic" }}>
                <span style={{ animation: "pulse 1.5s infinite" }}>Generating explanation…</span>
              </div>
            )}

            {/* Fairness flag */}
            {!result.fair && (
              <div style={{
                background: "rgba(255,140,64,0.1)", border: "1px solid rgba(255,140,64,0.3)",
                borderRadius: "8px", padding: "10px 16px", fontSize: "12px",
                color: "#ff8c40", width: "100%",
              }}>
                ⚠ This assessment has been flagged for manual fairness review.
              </div>
            )}
          </div>
        )}

        {/* ── FACTORS TAB ── */}
        {activeTab === "factors" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <div style={{ fontSize: "11px", color: "#3a5070", letterSpacing: "2px", marginBottom: "8px" }}>
              CAUSAL FACTORS (WHY THIS SCORE)
            </div>
            {result.causal_factors.length === 0 ? (
              <div style={{ color: "#3a5070", fontSize: "12px" }}>Detailed factors loading…</div>
            ) : (
              result.causal_factors.slice(0, 6).map((f, i) => (
                <div key={i} style={{
                  background:   "#080c12",
                  border:       "1px solid #1e2d42",
                  borderRadius: "8px",
                  padding:      "12px 14px",
                  display:      "flex",
                  alignItems:   "center",
                  gap:          "12px",
                }}>
                  <div style={{
                    width:     "28px", height: "28px", borderRadius: "50%",
                    background: f.direction === "increases_risk"
                      ? "rgba(255,64,96,0.15)" : "rgba(0,229,160,0.15)",
                    color:     f.direction === "increases_risk" ? "#ff4060" : "#00e5a0",
                    display:   "flex", alignItems: "center", justifyContent: "center",
                    fontSize:  "14px", flexShrink: 0,
                  }}>
                    {f.direction === "increases_risk" ? "↑" : "↓"}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "13px", color: "#d4e4f4", marginBottom: "2px" }}>
                      {f.label}
                    </div>
                    <div style={{ fontSize: "11px", color: "#3a5070" }}>
                      magnitude: {(f.magnitude * 100).toFixed(0)}%
                    </div>
                  </div>
                  {/* Magnitude bar */}
                  <div style={{ width: "80px", height: "4px", background: "#1e2d42", borderRadius: "2px", flexShrink: 0 }}>
                    <div style={{
                      height: "100%", borderRadius: "2px",
                      width: `${Math.min(f.magnitude * 100, 100)}%`,
                      background: f.direction === "increases_risk" ? "#ff4060" : "#00e5a0",
                    }} />
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* ── ACTIONS TAB ── */}
        {activeTab === "actions" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <div style={{ fontSize: "11px", color: "#3a5070", letterSpacing: "2px", marginBottom: "8px" }}>
              ACTIONABLE IMPROVEMENTS
            </div>
            {result.counterfactuals.length === 0 ? (
              <div style={{ color: "#3a5070", fontSize: "12px" }}>Loading recommendations…</div>
            ) : (
              result.counterfactuals.map((cf, i) => (
                <div key={i} style={{
                  background: "#080c12", border: "1px solid #1e2d42",
                  borderRadius: "10px", padding: "16px",
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "8px" }}>
                    <div style={{
                      fontSize: "11px", padding: "2px 8px", borderRadius: "4px",
                      background: "rgba(0,229,160,0.1)", color: "#00e5a0",
                      border: "1px solid rgba(0,229,160,0.3)", fontWeight: "700",
                    }}>
                      +{cf.delta} pts
                    </div>
                    <div style={{ fontSize: "10px", color: "#3a5070" }}>{cf.timeframe}</div>
                  </div>
                  <div style={{ fontSize: "13px", color: "#d4e4f4", lineHeight: "1.6" }}>
                    {cf.action}
                  </div>
                  <div style={{ marginTop: "8px", fontSize: "11px", color: "#6a8aaa" }}>
                    Feasibility:{" "}
                    <span style={{ color: cf.feasibility === "high" ? "#00e5a0" : cf.feasibility === "medium" ? "#f0c040" : "#ff8c40" }}>
                      {cf.feasibility.toUpperCase()}
                    </span>
                  </div>
                </div>
              ))
            )}

            {/* Adverse reasons if declined */}
            {result.risk_tier === "very_high" && result.adverse_reasons.length > 0 && (
              <div style={{
                background: "rgba(255,64,96,0.06)", border: "1px solid rgba(255,64,96,0.2)",
                borderRadius: "10px", padding: "16px", marginTop: "8px",
              }}>
                <div style={{ fontSize: "11px", color: "#ff4060", letterSpacing: "2px", marginBottom: "8px" }}>
                  ADVERSE ACTION REASONS (ECOA)
                </div>
                {result.adverse_reasons.map((r, i) => (
                  <div key={i} style={{ fontSize: "12px", color: "#6a8aaa", marginBottom: "4px" }}>
                    {i + 1}. {r}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── FORECAST TAB ── */}
        {activeTab === "forecast" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            <div style={{ fontSize: "11px", color: "#3a5070", letterSpacing: "2px", marginBottom: "8px" }}>
              12-MONTH SCORE TRAJECTORY
            </div>

            {Object.keys(result.trajectory).length === 0 ? (
              <div style={{ color: "#3a5070", fontSize: "12px" }}>Loading forecast…</div>
            ) : (
              <>
                {/* Current */}
                <div style={{
                  display: "flex", alignItems: "center", gap: "16px",
                  padding: "12px 16px", background: "#080c12",
                  border: `1px solid ${color}40`, borderRadius: "10px",
                }}>
                  <div style={{ fontSize: "28px", fontWeight: "700", color, width: "60px" }}>
                    {result.score}
                  </div>
                  <div>
                    <div style={{ fontSize: "11px", color: "#3a5070", letterSpacing: "1px" }}>TODAY</div>
                    <div style={{ fontSize: "12px", color: "#6a8aaa" }}>Current score</div>
                  </div>
                </div>

                {/* Forecasts */}
                {(["month_3", "month_6", "month_12"] as const).map((key) => {
                  const pt = result.trajectory[key];
                  if (!pt) return null;
                  const months  = key === "month_3" ? "3 months" : key === "month_6" ? "6 months" : "12 months";
                  const fColor  = pt.trend === "improving" ? "#00e5a0" : pt.trend === "deteriorating" ? "#ff4060" : "#f0c040";
                  const arrow   = pt.trend === "improving" ? "↑" : pt.trend === "deteriorating" ? "↓" : "→";
                  return (
                    <div key={key} style={{
                      display: "flex", alignItems: "center", gap: "16px",
                      padding: "12px 16px", background: "#080c12",
                      border: "1px solid #1e2d42", borderRadius: "10px",
                    }}>
                      <div style={{ fontSize: "28px", fontWeight: "700", color: fColor, width: "60px" }}>
                        {pt.predicted_score}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: "11px", color: "#3a5070", letterSpacing: "1px" }}>
                          {months.toUpperCase()}
                        </div>
                        <div style={{ fontSize: "12px", color: fColor }}>
                          {arrow} {Math.abs(pt.score_delta)} pts {pt.trend}
                        </div>
                        {pt.key_drivers.map((d, i) => (
                          <div key={i} style={{ fontSize: "11px", color: "#3a5070", marginTop: "2px" }}>
                            · {d}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{
        borderTop: "1px solid #1e2d42", padding: "10px 24px",
        display: "flex", justifyContent: "space-between",
        fontSize: "10px", color: "#3a5070",
      }}>
        <span>Model: {result.model_version}</span>
        <span>Fair: {result.fair ? "✓ Passed" : "⚠ Review"}</span>
        <span>ORACLE v1.0 · credit-ai.com</span>
      </div>
    </div>
  );
}
