// src/services/featureBuilder.ts
// ================================
// Converts frontend form data + transaction history into the
// 512-dimensional float32 feature vector that ORACLE expects.
//
// This is the TypeScript port of oracle/features.py.
// Runs in the browser — no server round-trip needed.

import { supabase } from "../lib/supabase";

// ── Types ─────────────────────────────────────────────────────────────────────

export interface ApplicationFormData {
  // Bureau snapshot
  fico_score?:              number;
  total_accounts?:          number;
  open_accounts?:           number;
  derogatory_marks?:        number;
  inquiries_6mo?:           number;
  inquiries_12mo?:          number;
  oldest_account_months?:   number;
  avg_account_age_months?:  number;
  revolving_utilization?:   number;    // 0-1
  installment_balance?:     number;
  revolving_balance?:       number;
  collections?:             number;
  bankruptcies?:            number;
  tax_liens?:               number;

  // Income & application
  stated_income?:           number;
  stated_expenses?:         number;
  loan_amount_requested?:   number;
  loan_purpose?:            string;
  employment_months?:       number;
  employment_type?:         string;
  application_text?:        string;
}

export interface Transaction {
  date:        string;    // YYYY-MM-DD
  amount:      number;
  description: string;
  category:    string;
  merchant:    string;
  type:        "debit" | "credit";
}

export interface PaymentRecord {
  due_date:  string;
  paid_date: string | null;
  amount:    number;
  status:    "on_time" | "late_30" | "late_60" | "late_90" | "missed";
}

// ── Feature Builder ───────────────────────────────────────────────────────────

export async function buildFeatureVector(
  formData: ApplicationFormData,
): Promise<number[]> {
  const { data: { user } } = await supabase.auth.getUser();

  // Fetch transaction history from Supabase (last 24 months)
  let transactions: Transaction[] = [];
  let paymentHistory: PaymentRecord[] = [];

  if (user) {
    const cutoff = new Date();
    cutoff.setMonth(cutoff.getMonth() - 24);

    const [{ data: txns }, { data: payments }] = await Promise.all([
      supabase
        .from("user_transactions")
        .select("*")
        .eq("user_id", user.id)
        .gte("date", cutoff.toISOString().split("T")[0])
        .order("date", { ascending: false }),
      supabase
        .from("payment_history")
        .select("*")
        .eq("user_id", user.id)
        .gte("due_date", cutoff.toISOString().split("T")[0])
        .order("due_date", { ascending: false }),
    ]);

    transactions   = txns    ?? [];
    paymentHistory = payments ?? [];
  }

  const features = new Array(512).fill(0);

  // ── [0:50] Bureau features ─────────────────────────────────────────────
  features[0]  = scale(formData.fico_score ?? 300, 300, 850);
  features[1]  = scale(formData.total_accounts ?? 0, 0, 50);
  features[2]  = scale(formData.open_accounts ?? 0, 0, 30);
  features[3]  = Math.min((formData.derogatory_marks ?? 0) / 10, 1);
  features[4]  = Math.min((formData.inquiries_6mo ?? 0) / 10, 1);
  features[5]  = Math.min((formData.inquiries_12mo ?? 0) / 15, 1);
  features[6]  = scale(formData.oldest_account_months ?? 0, 0, 360);
  features[7]  = scale(formData.avg_account_age_months ?? 0, 0, 240);
  features[8]  = Math.min(formData.revolving_utilization ?? 0, 1);
  features[9]  = scale(formData.installment_balance ?? 0, 0, 200000);
  features[10] = scale(formData.revolving_balance ?? 0, 0, 50000);
  features[11] = (formData.collections ?? 0) > 0 ? 1 : 0;
  features[12] = Math.min(formData.bankruptcies ?? 0, 1);
  features[13] = Math.min(formData.tax_liens ?? 0, 1);
  features[14] = scale(formData.stated_income ?? 0, 0, 500000);
  features[15] = scale(formData.stated_expenses ?? 0, 0, 20000);
  features[16] = scale(formData.loan_amount_requested ?? 0, 0, 100000);

  // DTI ratio
  const monthlyIncome = (formData.stated_income ?? 1) / 12;
  const dti = (formData.stated_expenses ?? 0) / Math.max(monthlyIncome, 1);
  features[17] = Math.min(dti / 3, 1);

  // Loan-to-income ratio
  features[18] = Math.min((formData.loan_amount_requested ?? 0) / Math.max(formData.stated_income ?? 1, 1) / 5, 1);

  // Employment
  features[19] = scale(formData.employment_months ?? 0, 0, 120);
  const empTypeMap: Record<string, number> = {
    employed: 0.9, self_employed: 0.6, contractor: 0.5, unemployed: 0, retired: 0.7
  };
  features[20] = empTypeMap[formData.employment_type ?? "employed"] ?? 0.5;

  // Loan purpose risk
  const purposeMap: Record<string, number> = {
    debt_consolidation: 0.6, home_improvement: 0.3, business: 0.7,
    personal: 0.5, auto: 0.4, education: 0.2
  };
  features[21] = purposeMap[formData.loan_purpose ?? "personal"] ?? 0.5;

  // Interactions
  features[22] = features[8] * features[4];   // utilization × inquiries
  features[23] = features[3] * (1 - features[7]); // derogatory × recency
  features[24] = (formData.total_accounts ?? 0) < 3 ? 1 : 0; // thin file

  // ── [50:150] Velocity features ─────────────────────────────────────────
  const today = new Date();
  const windows = [30, 60, 90, 180];
  windows.forEach((days, i) => {
    const cutoff = new Date(today.getTime() - days * 86400000);
    const periodTxns = transactions.filter(t => new Date(t.date) > cutoff);
    const debits  = periodTxns.filter(t => t.type === "debit").map(t => t.amount);
    const credits = periodTxns.filter(t => t.type === "credit").map(t => t.amount);
    const totalSpend  = debits.reduce((a, b) => a + b, 0);
    const totalIncome = credits.reduce((a, b) => a + b, 0);

    const base = 50 + i * 20;
    features[base]   = scale(totalSpend, 0, 50000);
    features[base+1] = scale(totalIncome, 0, 50000);
    features[base+2] = Math.min(totalSpend / Math.max(totalIncome, 1) / 3, 1);
    features[base+3] = scale(debits.length, 0, 500);
    features[base+4] = scale(debits.length > 0 ? mean(debits) : 0, 0, 5000);
    features[base+5] = scale(debits.length > 1 ? stddev(debits) : 0, 0, 3000);
  });

  // ── [150:200] Entropy features ─────────────────────────────────────────
  if (transactions.length > 0) {
    const categories = transactions.map(t => t.category);
    const catCounts = countBy(categories);
    features[150] = Math.min(shannonEntropy(catCounts) / 5, 1);

    const merchants = transactions.map(t => t.merchant);
    const mCounts = countBy(merchants);
    const mTotal = merchants.length;
    const hhi = Object.values(mCounts).reduce((a, c) => a + (c / mTotal) ** 2, 0);
    features[151] = hhi;

    const txns30 = transactions.filter(t => daysDiff(today, new Date(t.date)) <= 30);
    const txns90 = transactions.filter(t => daysDiff(today, new Date(t.date)) <= 90);
    features[154] = Math.min(shannonEntropy(countBy(txns30.map(t => t.category))) / 5, 1);
    features[155] = Math.min(shannonEntropy(countBy(txns90.map(t => t.category))) / 5, 1);
    features[156] = features[155] > 0
      ? (features[155] - features[154]) / features[155]
      : 0;
  }

  // ── [200:260] Payment features ──────────────────────────────────────────
  if (paymentHistory.length > 0) {
    const total    = paymentHistory.length;
    const onTime   = paymentHistory.filter(p => p.status === "on_time").length;
    const late30   = paymentHistory.filter(p => p.status === "late_30").length;
    const late60   = paymentHistory.filter(p => p.status === "late_60").length;
    const late90   = paymentHistory.filter(p => p.status === "late_90").length;
    const missed   = paymentHistory.filter(p => p.status === "missed").length;

    features[200] = onTime / total;
    features[201] = late30 / total;
    features[202] = late60 / total;
    features[203] = late90 / total;
    features[204] = missed / total;

    const weightedBad = (late30 + late60 * 2 + late90 * 4 + missed * 8) / (total * 8);
    features[205] = 1 - Math.min(weightedBad, 1);

    // Timing jitter
    const delays: number[] = [];
    paymentHistory.forEach(p => {
      if (p.paid_date && p.due_date) {
        delays.push(daysDiff(new Date(p.paid_date), new Date(p.due_date)));
      }
    });
    if (delays.length > 0) {
      features[206] = scale(mean(delays), -30, 30);
      features[207] = Math.min(stddev(delays) / 30, 1);
    }

    // Recency weighting
    const recent = paymentHistory.slice(-6).filter(p => p.status !== "on_time").length;
    const mid    = paymentHistory.slice(-12, -6).filter(p => p.status !== "on_time").length;
    const old    = paymentHistory.slice(-24, -12).filter(p => p.status !== "on_time").length;
    features[210] = Math.min((recent * 1 + mid * 0.6 + old * 0.3) / (total * 1), 1);
  }

  return features;
}

// ── Macro Context ─────────────────────────────────────────────────────────────

export async function getCurrentMacroContext(): Promise<Record<string, number>> {
  const defaults = {
    fed_funds_rate:               5.25,
    cpi_yoy:                      3.1,
    unemployment_rate:            3.9,
    consumer_sentiment:           70.0,
    sp500_30d_return:             2.0,
    credit_card_delinquency_rate: 2.8,
  };

  try {
    const { data } = await supabase
      .from("macro_context")
      .select("*")
      .gt("expires_at", new Date().toISOString())
      .order("valid_at", { ascending: false })
      .limit(1)
      .single();

    if (data) return { ...defaults, ...data };
  } catch {}

  return defaults;
}

// ── Utilities ─────────────────────────────────────────────────────────────────

function scale(value: number, lo: number, hi: number): number {
  return Math.max(0, Math.min(1, (value - lo) / Math.max(hi - lo, 1e-8)));
}

function mean(arr: number[]): number {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function stddev(arr: number[]): number {
  const m = mean(arr);
  return Math.sqrt(arr.reduce((a, b) => a + (b - m) ** 2, 0) / arr.length);
}

function countBy<T>(arr: T[]): Record<string, number> {
  return arr.reduce((acc, v) => {
    const k = String(v);
    acc[k] = (acc[k] ?? 0) + 1;
    return acc;
  }, {} as Record<string, number>);
}

function shannonEntropy(counts: Record<string, number>): number {
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  return -Object.values(counts).reduce((acc, c) => {
    const p = c / total;
    return acc + (p > 0 ? p * Math.log2(p) : 0);
  }, 0);
}

function daysDiff(a: Date, b: Date): number {
  return Math.round((a.getTime() - b.getTime()) / 86400000);
}
