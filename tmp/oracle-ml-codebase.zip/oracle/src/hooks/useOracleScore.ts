// src/hooks/useOracleScore.ts
// ============================
// React hook that:
//   1. Submits a credit application → calls oracle-score edge function
//   2. Subscribes to Supabase Realtime for score delivery
//   3. Updates UI state as score + explanation arrive (separate events)
//
// Usage:
//   const { submit, score, explanation, status, error } = useOracleScore();
//   await submit(formData);

import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "../lib/supabase";
import { buildFeatureVector } from "../services/featureBuilder";
import { getCurrentMacroContext } from "../services/macroService";

// ── Types ─────────────────────────────────────────────────────────────────────

export type ScoreStatus =
  | "idle"
  | "building_features"
  | "scoring"
  | "scored"
  | "generating_explanation"
  | "complete"
  | "error";

export interface OracleScoreResult {
  score:            number;
  probability:      number;
  confidence_low:   number;
  confidence_high:  number;
  risk_tier:        "low" | "medium" | "high" | "very_high";
  risk_type:        string;
  causal_factors:   CausalFactor[];
  counterfactuals:  Counterfactual[];
  trajectory:       TrajectoryData;
  explanation:      string;
  adverse_reasons:  string[];
  fair:             boolean;
  latency_ms:       number;
  model_version:    string;
}

export interface CausalFactor {
  factor:         string;
  label:          string;
  direction:      "increases_risk" | "decreases_risk";
  magnitude:      number;
  feature_value:  number;
}

export interface Counterfactual {
  factor:       string;
  action:       string;
  new_score:    number;
  delta:        number;
  feasibility:  "high" | "medium" | "low";
  timeframe:    string;
  priority:     number;
}

export interface TrajectoryData {
  month_3:  TrajectoryPoint;
  month_6:  TrajectoryPoint;
  month_12: TrajectoryPoint;
}

export interface TrajectoryPoint {
  predicted_score: number;
  predicted_prob:  number;
  score_delta:     number;
  key_drivers:     string[];
  trend:           "improving" | "deteriorating" | "stable";
}

// ── Hook ─────────────────────────────────────────────────────────────────────

export function useOracleScore() {
  const [status,      setStatus]      = useState<ScoreStatus>("idle");
  const [score,       setScore]       = useState<OracleScoreResult | null>(null);
  const [explanation, setExplanation] = useState<string>("");
  const [error,       setError]       = useState<string | null>(null);
  const [latencyMs,   setLatencyMs]   = useState<number | null>(null);

  const channelRef      = useRef<any>(null);
  const applicationIdRef = useRef<string | null>(null);

  // ── Cleanup on unmount ──────────────────────────────────────────────────
  useEffect(() => {
    return () => {
      if (channelRef.current) {
        channelRef.current.unsubscribe();
        channelRef.current = null;
      }
    };
  }, []);

  // ── Subscribe to Realtime for this application ──────────────────────────
  const subscribeToScore = useCallback((applicationId: string) => {
    // Unsubscribe from any previous subscription
    if (channelRef.current) {
      channelRef.current.unsubscribe();
    }

    const channel = supabase
      .channel(`oracle_score:${applicationId}`)
      .on(
        "postgres_changes",
        {
          event:  "INSERT",
          schema: "public",
          table:  "credit_scores",
          filter: `application_id=eq.${applicationId}`,
        },
        (payload) => {
          const row = payload.new as any;
          console.log("Score received via Realtime:", row.score);

          setScore({
            score:           row.score,
            probability:     row.probability,
            confidence_low:  row.confidence_low  ?? row.score - 18,
            confidence_high: row.confidence_high ?? row.score + 18,
            risk_tier:       row.risk_tier,
            risk_type:       row.risk_type ?? "mixed",
            causal_factors:  row.causal_factors  ?? [],
            counterfactuals: row.counterfactuals ?? [],
            trajectory:      row.trajectory      ?? {},
            explanation:     row.explanation     ?? "",
            adverse_reasons: row.adverse_reasons ?? [],
            fair:            row.fair            ?? true,
            latency_ms:      row.latency_ms,
            model_version:   row.model_version,
          });

          setLatencyMs(row.latency_ms);

          if (row.explanation_status === "complete") {
            setExplanation(row.explanation ?? "");
            setStatus("complete");
          } else {
            setStatus("generating_explanation");
          }
        }
      )
      .on(
        "postgres_changes",
        {
          event:  "UPDATE",
          schema: "public",
          table:  "credit_scores",
          filter: `application_id=eq.${applicationId}`,
        },
        (payload) => {
          const row = payload.new as any;
          // Explanation arrived
          if (row.explanation_status === "complete" && row.explanation) {
            console.log("Explanation received via Realtime");
            setExplanation(row.explanation);
            setScore((prev) => prev ? { ...prev, explanation: row.explanation } : prev);
            setStatus("complete");
          }
        }
      )
      .subscribe((subscribeStatus) => {
        if (subscribeStatus === "SUBSCRIBED") {
          console.log(`Realtime subscribed for ${applicationId}`);
        } else if (subscribeStatus === "CHANNEL_ERROR") {
          console.error("Realtime subscription error");
          // Retry after 3s
          setTimeout(() => subscribeToScore(applicationId), 3000);
        }
      });

    channelRef.current = channel;
  }, []);

  // ── Main submit function ────────────────────────────────────────────────
  const submit = useCallback(async (formData: Record<string, any>) => {
    try {
      setStatus("building_features");
      setError(null);
      setScore(null);
      setExplanation("");

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // ── 1. Build 512-dim feature vector from form data ───────────────
      const [features, macroContext] = await Promise.all([
        buildFeatureVector(formData),
        getCurrentMacroContext(),
      ]);

      // ── 2. Create application record in DB ────────────────────────────
      const { data: application, error: appError } = await supabase
        .from("credit_applications")
        .insert({
          applicant_id:      user.id,
          status:            "processing",
          stated_income:     formData.stated_income,
          stated_expenses:   formData.stated_expenses,
          loan_amount:       formData.loan_amount_requested,
          loan_purpose:      formData.loan_purpose,
          employment_type:   formData.employment_type,
          employment_months: formData.employment_months,
          feature_vector:    features,
        })
        .select("id")
        .single();

      if (appError || !application) {
        throw new Error(appError?.message ?? "Failed to create application");
      }

      const applicationId = application.id;
      applicationIdRef.current = applicationId;

      // ── 3. Subscribe to Realtime BEFORE calling edge function ─────────
      // (subscribe first so we don't miss the event)
      subscribeToScore(applicationId);

      setStatus("scoring");

      // ── 4. Call ORACLE edge function ──────────────────────────────────
      const { data, error: fnError } = await supabase.functions.invoke("oracle-score", {
        body: {
          application_id: applicationId,
          applicant_id:   user.id,
          features,
          macro_context:  macroContext,
        },
      });

      if (fnError) throw new Error(fnError.message ?? "Scoring function failed");

      console.log(`Edge function returned in ${data?.latency_ms}ms, score: ${data?.score}`);
      // Note: actual UI update comes via Realtime (DB write → push)
      // This response is just confirmation the function ran.

      // Safety fallback: if Realtime hasn't fired after 8s, use edge function response
      setTimeout(() => {
        if (status === "scoring" && data?.score) {
          console.warn("Realtime timeout — using edge function response as fallback");
          setScore({
            score:           data.score,
            probability:     data.probability,
            confidence_low:  data.score - 18,
            confidence_high: data.score + 18,
            risk_tier:       data.risk_tier,
            risk_type:       "mixed",
            causal_factors:  [],
            counterfactuals: [],
            trajectory:      {} as TrajectoryData,
            explanation:     "",
            adverse_reasons: [],
            fair:            true,
            latency_ms:      data.latency_ms,
            model_version:   data.model_version,
          });
          setStatus("generating_explanation");
        }
      }, 8000);

    } catch (err: any) {
      console.error("useOracleScore error:", err);
      setError(err.message ?? "An unexpected error occurred");
      setStatus("error");
    }
  }, [subscribeToScore, status]);

  const reset = useCallback(() => {
    setStatus("idle");
    setScore(null);
    setExplanation("");
    setError(null);
    setLatencyMs(null);
    if (channelRef.current) {
      channelRef.current.unsubscribe();
      channelRef.current = null;
    }
  }, []);

  return {
    submit,
    reset,
    status,
    score,
    explanation,
    error,
    latencyMs,
    isLoading: status === "building_features" || status === "scoring",
    isScored:  status === "scored" || status === "generating_explanation" || status === "complete",
    isComplete: status === "complete",
  };
}
