"""
oracle/model.py
===============
ORACLE Core Model — Main inference entry point.
Combines all sub-systems into a single .score() call.

Usage:
    from oracle.model import OracleModel
    model = OracleModel(model_dir="models/")
    result = model.score(features, macro_context, applicant_id)
"""

from __future__ import annotations
import time
import logging
import numpy as np
from dataclasses import dataclass, field, asdict
from typing import Optional
from pathlib import Path
import json
import pickle

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# OUTPUT DATA CLASS
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class OracleScore:
    """
    Complete output of a single ORACLE inference pass.
    Every field is serializable to JSON for the Supabase DB write.
    """
    # Core score
    score:            float          # 300–850 normalized
    probability:      float          # P(default within 12 months)
    confidence_low:   float          # 95% conformal interval lower bound
    confidence_high:  float          # 95% conformal interval upper bound

    # Risk classification
    risk_tier:        str            # "low" | "medium" | "high" | "very_high"
    risk_type:        str            # "liquidity" | "behavioral" | "systemic" | "mixed"

    # Causal attribution (why is the score what it is)
    causal_factors:   list[dict]     # [{"factor": str, "direction": +/-, "magnitude": float}]

    # Actionable explanation
    counterfactuals:  list[dict]     # [{"change": str, "new_score": int, "delta": int}]
    explanation:      str            # LLM-generated plain-English narrative
    adverse_reasons:  list[str]      # ECOA-compliant adverse action reasons (if declined)

    # Future trajectory
    trajectory:       dict           # {"month_3": {...}, "month_6": {...}, "month_12": {...}}

    # Fairness & metadata
    fair:             bool           # passed adversarial fairness check
    latency_ms:       int            # total inference time
    model_version:    str            # deployed model hash
    application_id:   str

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


# ─────────────────────────────────────────────────────────────────────────────
# MAIN MODEL CLASS
# ─────────────────────────────────────────────────────────────────────────────

class OracleModel:
    """
    ORACLE: Omni-modal Reasoning & Causal Learning Engine.

    The first credit model combining:
      1. Causal graph inference (Neural Granger + SCM)
      2. Transaction-text semantic encoding (fine-tuned FinBERT)
      3. Macro-economic context conditioning
      4. Multi-objective ensemble (XGBoost + LGBM + Neural Net)
      5. Adversarial fairness (trained-in, not patched-on)
      6. Conformal prediction intervals
      7. Counterfactual explanation generation
      8. 12-month trajectory forecasting
      9. Continual online learning (EWC)

    All inference runs in < 80ms via ONNX Runtime at the Supabase edge.
    """

    # ── scoring band thresholds (300–850) ──────────────────────────────────
    SCORE_BANDS = {
        "very_high": (300, 579),
        "high":      (580, 649),
        "medium":    (650, 719),
        "low":       (720, 850),
    }

    def __init__(self, model_dir: str = "models/"):
        self.model_dir   = Path(model_dir)
        self.model_version = self._read_version()
        self._loaded     = False

    # ── lazy loading ───────────────────────────────────────────────────────
    def _load(self):
        if self._loaded:
            return
        import onnxruntime as ort
        from oracle.causal_graph  import CausalCreditGraph
        from oracle.fairness      import AdversarialFairnessLayer
        from oracle.uncertainty   import ConformalPredictor
        from oracle.explainer     import CounterfactualExplainer
        from oracle.trajectory    import TrajectoryForecaster
        from oracle.features      import FeaturePipeline

        logger.info("Loading ORACLE model components...")
        t0 = time.time()

        self.ort_session = ort.InferenceSession(
            str(self.model_dir / "oracle_ensemble.onnx"),
            providers=["CPUExecutionProvider"]
        )
        self.causal_graph  = CausalCreditGraph.load(self.model_dir / "causal_graph.json")
        self.fairness      = AdversarialFairnessLayer.load(self.model_dir / "fairness_adversary.pkl")
        self.conformal     = ConformalPredictor.load(self.model_dir / "conformal_calibration.pkl")
        self.explainer     = CounterfactualExplainer(self.ort_session)
        self.forecaster    = TrajectoryForecaster(self.causal_graph)
        self.features      = FeaturePipeline.load(self.model_dir / "feature_pipeline.pkl")

        self._loaded = True
        logger.info(f"ORACLE loaded in {(time.time()-t0)*1000:.0f}ms")

    # ── main inference ─────────────────────────────────────────────────────
    def score(
        self,
        raw_features: dict,
        macro_context: dict,
        application_id: str,
        explain: bool = True,
    ) -> OracleScore:
        """
        Full inference pass. Returns OracleScore with all fields populated.

        Args:
            raw_features:   dict of applicant features (see features.py for schema)
            macro_context:  dict of current macro indicators (fed_rate, cpi, etc.)
            application_id: unique application UUID
            explain:        if True, generate counterfactuals + narrative (adds ~20ms)

        Returns:
            OracleScore with every field populated
        """
        self._load()
        t0 = time.time()

        # ── 1. Feature engineering ──────────────────────────────────────
        X = self.features.transform(raw_features, macro_context)  # → (1, 512) float32

        # ── 2. Ensemble inference ───────────────────────────────────────
        probability = self._ensemble_predict(X)

        # ── 3. Conformal prediction interval ───────────────────────────
        ci_low, ci_high = self.conformal.predict_interval(X, alpha=0.05)

        # ── 4. Causal attribution ───────────────────────────────────────
        causal_factors = self.causal_graph.attribute(X, probability)

        # ── 5. Risk classification ──────────────────────────────────────
        risk_tier = self._classify_tier(probability)
        risk_type = self._classify_type(causal_factors)

        # ── 6. Adversarial fairness check ───────────────────────────────
        fair = self.fairness.check(X, probability)
        if not fair:
            logger.warning(f"Fairness flag on application {application_id}")

        # ── 7. Score normalization (probability → 300–850) ──────────────
        score = self._prob_to_score(probability)
        ci_score_low  = self._prob_to_score(float(ci_high))  # high prob → low score
        ci_score_high = self._prob_to_score(float(ci_low))

        # ── 8. Counterfactuals + explanation ────────────────────────────
        counterfactuals = []
        explanation     = ""
        adverse_reasons = []

        if explain:
            counterfactuals = self.explainer.generate(X, probability, score, n=4)
            adverse_reasons = self.fairness.ecoa_reasons(counterfactuals)
            explanation     = self.explainer.narrative(
                score, probability, causal_factors, counterfactuals,
                macro_context, risk_tier
            )

        # ── 9. Trajectory forecast ──────────────────────────────────────
        trajectory = self.forecaster.forecast(X, horizons=[3, 6, 12])

        latency_ms = int((time.time() - t0) * 1000)
        logger.info(f"ORACLE scored {application_id}: {score:.0f} in {latency_ms}ms | fair={fair}")

        return OracleScore(
            score            = round(score),
            probability      = round(float(probability), 4),
            confidence_low   = round(ci_score_low),
            confidence_high  = round(ci_score_high),
            risk_tier        = risk_tier,
            risk_type        = risk_type,
            causal_factors   = causal_factors,
            counterfactuals  = counterfactuals,
            explanation      = explanation,
            adverse_reasons  = adverse_reasons,
            trajectory       = trajectory,
            fair             = fair,
            latency_ms       = latency_ms,
            model_version    = self.model_version,
            application_id   = application_id,
        )

    # ── ensemble inference ─────────────────────────────────────────────────
    def _ensemble_predict(self, X: np.ndarray) -> float:
        """
        Run ONNX ensemble and return blended default probability.
        The ONNX model is a meta-learner trained on top of:
          - XGBoost base model predictions
          - LightGBM base model predictions
          - Neural net base model predictions
        """
        inp_name  = self.ort_session.get_inputs()[0].name
        out_name  = self.ort_session.get_outputs()[0].name
        result    = self.ort_session.run([out_name], {inp_name: X.astype(np.float32)})
        return float(np.clip(result[0][0], 1e-6, 1 - 1e-6))

    # ── helpers ────────────────────────────────────────────────────────────
    def _prob_to_score(self, prob: float) -> float:
        """Map default probability to 300–850 score range."""
        # Logistic scaling: low prob → high score, high prob → low score
        # Calibrated so median applicant maps to ~680
        import math
        log_odds = math.log(max(prob, 1e-6) / max(1 - prob, 1e-6))
        score = 680 - (log_odds * 55)
        return float(np.clip(score, 300, 850))

    def _classify_tier(self, prob: float) -> str:
        if prob < 0.05:  return "low"
        if prob < 0.15:  return "medium"
        if prob < 0.35:  return "high"
        return "very_high"

    def _classify_type(self, causal_factors: list[dict]) -> str:
        """Determine which risk type dominates from causal attribution."""
        type_map = {
            "utilization_velocity": "liquidity",
            "payment_timing_jitter": "behavioral",
            "income_volatility": "liquidity",
            "spending_entropy_drop": "behavioral",
            "macro_rate_sensitivity": "systemic",
            "inquiry_burst": "behavioral",
            "revolving_balance_growth": "liquidity",
        }
        type_counts: dict[str, float] = {}
        for f in causal_factors:
            t = type_map.get(f.get("factor",""), "mixed")
            type_counts[t] = type_counts.get(t, 0) + abs(f.get("magnitude", 0))

        if not type_counts:
            return "mixed"
        dominant = max(type_counts, key=type_counts.get)
        total = sum(type_counts.values())
        if type_counts[dominant] / total > 0.6:
            return dominant
        return "mixed"

    def _read_version(self) -> str:
        version_file = self.model_dir / "version.txt"
        if version_file.exists():
            return version_file.read_text().strip()
        return "unknown"

    # ── online learning ────────────────────────────────────────────────────
    def update(self, X: np.ndarray, y: np.ndarray, application_id: str):
        """
        Elastic Weight Consolidation (EWC) continual online update.
        Called after a loan outcome is confirmed (default/no-default).
        Updates the neural sub-model only — XGBoost/LGBM updated in batch.
        """
        from oracle.trainer import EWCUpdater
        updater = EWCUpdater.load(self.model_dir / "ewc_state.pkl")
        updater.update_step(X, y)
        updater.save(self.model_dir / "ewc_state.pkl")
        logger.info(f"Online update applied from outcome: {application_id}")

    # ── health check ───────────────────────────────────────────────────────
    def health(self) -> dict:
        """Returns model health status dict for /ai-health endpoint."""
        try:
            self._load()
            # Run a tiny synthetic inference to verify runtime is alive
            dummy = np.zeros((1, 512), dtype=np.float32)
            inp   = self.ort_session.get_inputs()[0].name
            out   = self.ort_session.get_outputs()[0].name
            t0    = time.time()
            self.ort_session.run([out], {inp: dummy})
            ping  = int((time.time() - t0) * 1000)
            return {
                "status":       "ok",
                "model_version": self.model_version,
                "ping_ms":      ping,
                "components": {
                    "onnx_runtime":   "ok",
                    "causal_graph":   "ok",
                    "fairness_layer": "ok",
                    "conformal":      "ok",
                }
            }
        except Exception as e:
            return {"status": "degraded", "error": str(e)}
