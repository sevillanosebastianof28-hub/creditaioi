"""
oracle/causal_graph.py
======================
Neural Granger Causality + Structural Causal Model for credit risk.

The key insight: correlation-based models fail when the economy shifts
because they've learned proxies, not causes. A causal model understands
that income_shock → missed_payment, not just that they co-occur.

This module:
  1. Learns Granger-causal relationships from longitudinal transaction data
  2. Maintains an explicit Structural Causal Model (SCM) of credit dynamics
  3. Provides causal attribution: WHY is the score what it is?
  4. Simulates interventions: what WOULD HAPPEN if X changes?
  5. Forecasts 3/6/12 month score trajectories via causal simulation
"""

from __future__ import annotations
import json
import numpy as np
import math
from pathlib import Path
from typing import Optional
import pickle


# ─────────────────────────────────────────────────────────────────────────────
# CAUSAL GRAPH STRUCTURE
# Hard-coded domain knowledge + data-discovered edges
# ─────────────────────────────────────────────────────────────────────────────

DOMAIN_CAUSAL_EDGES = [
    # (cause, effect, direction, strength_prior)
    # + means cause increases effect, - means decreases
    ("income_volatility",         "payment_missed_prob",    "+", 0.72),
    ("utilization_velocity",      "payment_missed_prob",    "+", 0.65),
    ("spending_entropy_drop",     "income_stress_prob",     "+", 0.58),
    ("income_stress_prob",        "payment_missed_prob",    "+", 0.81),
    ("inquiry_burst",             "credit_seeking_signal",  "+", 0.77),
    ("credit_seeking_signal",     "payment_missed_prob",    "+", 0.43),
    ("payment_timing_jitter",     "financial_disorg_signal","+", 0.61),
    ("financial_disorg_signal",   "payment_missed_prob",    "+", 0.55),
    ("employment_instability",    "income_volatility",      "+", 0.69),
    ("macro_rate_shock",          "installment_stress",     "+", 0.48),
    ("installment_stress",        "payment_missed_prob",    "+", 0.52),
    ("revolving_balance_growth",  "utilization_velocity",   "+", 0.73),
    ("thin_file",                 "model_uncertainty",      "+", 0.60),
    # Protective paths (negative = reduces risk)
    ("income_growth",             "payment_missed_prob",    "-", 0.64),
    ("payment_consistency",       "payment_missed_prob",    "-", 0.78),
    ("spending_diversity",        "income_stress_prob",     "-", 0.41),
    ("long_credit_history",       "payment_missed_prob",    "-", 0.45),
]

# Feature name → causal variable mapping
FEATURE_TO_CAUSAL = {
    "income_volatility":        [20, 21],      # feature indices
    "utilization_velocity":     [8, 22],
    "spending_entropy_drop":    [6],
    "inquiry_burst":            [4, 5],
    "payment_timing_jitter":    [7],
    "employment_instability":   [19, 20],
    "revolving_balance_growth": [10],
    "thin_file":                [24],
    "income_growth":            [14, 50, 70],
    "payment_consistency":      [0, 6],         # payment feature indices (200+)
    "spending_diversity":       [0, 2],          # entropy feature indices (150+)
    "long_credit_history":      [6, 7],
}


# ─────────────────────────────────────────────────────────────────────────────
# NEURAL GRANGER MODULE (PyTorch-free, numpy-based for ONNX portability)
# ─────────────────────────────────────────────────────────────────────────────

class NeuralGrangerModule:
    """
    Granger causality via variance decomposition in time-series feature space.

    For feature X to Granger-cause Y:
      - A model using [X_history + Y_history] must predict Y better than
        a model using [Y_history] alone.

    We use numpy-based ARIMA residuals as the "model" for portability.
    In training, replaced by full LSTM Granger (see trainer.py).
    """

    def __init__(self, feature_names: list[str], n_lags: int = 6):
        self.feature_names = feature_names
        self.n_lags        = n_lags
        self.causality_matrix: Optional[np.ndarray] = None  # (n_features, n_features)

    def fit(self, time_series: np.ndarray):
        """
        Fit Granger causality matrix on a (T, n_features) time series.
        time_series: T timesteps × n_features (one row per month)
        """
        T, n = time_series.shape
        matrix = np.zeros((n, n), dtype=float)

        for target_idx in range(n):
            y = time_series[:, target_idx]
            # Reduced model: AR on y alone
            res_reduced = self._ar_residuals(y, self.n_lags)
            mse_reduced = np.mean(res_reduced**2)

            for cause_idx in range(n):
                if cause_idx == target_idx:
                    continue
                X = time_series[:, cause_idx]
                # Full model: AR on y + lagged X
                res_full = self._ar_with_exog_residuals(y, X, self.n_lags)
                mse_full = np.mean(res_full**2)
                # F-statistic proxy: improvement ratio
                improvement = max(0, (mse_reduced - mse_full) / max(mse_reduced, 1e-8))
                matrix[cause_idx, target_idx] = improvement

        self.causality_matrix = matrix
        return self

    def _ar_residuals(self, y: np.ndarray, lags: int) -> np.ndarray:
        """Simple AR model residuals."""
        T = len(y)
        if T <= lags:
            return np.zeros(1)
        X_ar = np.column_stack([y[i:T-lags+i] for i in range(lags)])
        y_ar = y[lags:]
        try:
            coeffs, _, _, _ = np.linalg.lstsq(
                np.column_stack([np.ones(len(y_ar)), X_ar]),
                y_ar, rcond=None
            )
            pred = np.column_stack([np.ones(len(y_ar)), X_ar]) @ coeffs
            return y_ar - pred
        except:
            return np.zeros(len(y_ar))

    def _ar_with_exog_residuals(self, y: np.ndarray, X: np.ndarray, lags: int) -> np.ndarray:
        """AR model with exogenous variable residuals."""
        T = len(y)
        if T <= lags:
            return np.zeros(1)
        y_ar = y[lags:]
        X_ar = np.column_stack([
            *[y[i:T-lags+i] for i in range(lags)],
            *[X[i:T-lags+i] for i in range(lags)],
        ])
        try:
            coeffs, _, _, _ = np.linalg.lstsq(
                np.column_stack([np.ones(len(y_ar)), X_ar]),
                y_ar, rcond=None
            )
            pred = np.column_stack([np.ones(len(y_ar)), X_ar]) @ coeffs
            return y_ar - pred
        except:
            return np.zeros(len(y_ar))


# ─────────────────────────────────────────────────────────────────────────────
# STRUCTURAL CAUSAL MODEL
# ─────────────────────────────────────────────────────────────────────────────

class CausalCreditGraph:
    """
    Structural Causal Model for credit risk.

    Combines:
    - Domain-knowledge causal edges (DOMAIN_CAUSAL_EDGES)
    - Data-discovered edges from NeuralGrangerModule
    - Intervention simulation for counterfactuals
    - Forward trajectory simulation for score forecasting
    """

    def __init__(self):
        self.edges           = DOMAIN_CAUSAL_EDGES.copy()
        self.edge_weights: dict[tuple, float] = {}
        self.granger_module  = None
        self._build_adjacency()

    def _build_adjacency(self):
        """Build adjacency dict from edge list."""
        self.adjacency: dict[str, list[dict]] = {}
        for cause, effect, direction, strength in self.edges:
            if cause not in self.adjacency:
                self.adjacency[cause] = []
            self.adjacency[cause].append({
                "effect":    effect,
                "direction": direction,
                "strength":  strength,
            })
            self.edge_weights[(cause, effect)] = strength * (1 if direction == "+" else -1)

    # ── causal attribution ────────────────────────────────────────────────
    def attribute(self, X: np.ndarray, probability: float) -> list[dict]:
        """
        Return top causal factors driving this prediction.

        Returns list of dicts:
          [{"factor": str, "label": str, "direction": str,
            "magnitude": float, "feature_value": float}]
        """
        X_flat = X.flatten()
        attributions = []

        for causal_var, feat_indices in FEATURE_TO_CAUSAL.items():
            # Get the feature values that represent this causal variable
            vals = []
            for idx in feat_indices:
                if idx < len(X_flat):
                    vals.append(float(X_flat[idx]))

            if not vals:
                continue

            avg_val = float(np.mean(vals))

            # Find how this variable connects to payment_missed_prob
            edge_path = self._find_path(causal_var, "payment_missed_prob")
            if not edge_path:
                continue

            # Compute combined path strength
            path_strength = 1.0
            path_direction = 1
            for seg in edge_path:
                path_strength  *= seg["strength"]
                path_direction *= (1 if seg["direction"] == "+" else -1)

            # Magnitude = feature activation × path strength
            magnitude = avg_val * path_strength

            if magnitude < 0.05:  # filter noise
                continue

            attributions.append({
                "factor":        causal_var,
                "label":         self._human_label(causal_var),
                "direction":     "increases_risk" if path_direction > 0 else "decreases_risk",
                "magnitude":     round(magnitude, 3),
                "feature_value": round(avg_val, 3),
                "path":          " → ".join([causal_var] + [s["effect"] for s in edge_path]),
            })

        # Sort by magnitude descending
        attributions.sort(key=lambda x: x["magnitude"], reverse=True)
        return attributions[:8]  # top 8 causal factors

    def _find_path(self, source: str, target: str, max_depth: int = 4) -> list[dict]:
        """BFS to find causal path from source to target."""
        if source == target:
            return []
        queue = [(source, [])]
        visited = {source}
        while queue:
            node, path = queue.pop(0)
            for edge in self.adjacency.get(node, []):
                effect = edge["effect"]
                new_path = path + [edge]
                if effect == target:
                    return new_path
                if effect not in visited and len(new_path) < max_depth:
                    visited.add(effect)
                    queue.append((effect, new_path))
        return []

    def _human_label(self, var: str) -> str:
        labels = {
            "income_volatility":        "Income instability",
            "utilization_velocity":     "Rapidly increasing credit card usage",
            "spending_entropy_drop":    "Sudden spending pattern change",
            "inquiry_burst":            "Multiple credit applications recently",
            "payment_timing_jitter":    "Inconsistent payment timing",
            "employment_instability":   "Employment history gaps",
            "revolving_balance_growth": "Growing revolving balances",
            "thin_file":                "Limited credit history",
            "income_growth":            "Growing income",
            "payment_consistency":      "Consistent on-time payments",
            "spending_diversity":       "Diverse, stable spending patterns",
            "long_credit_history":      "Long established credit history",
        }
        return labels.get(var, var.replace("_", " ").title())

    # ── intervention simulation ───────────────────────────────────────────
    def simulate_intervention(
        self,
        X: np.ndarray,
        intervention: dict,  # {"feature_idx": int, "new_value": float}
        base_probability: float,
    ) -> float:
        """
        Simulate the causal effect of changing a single feature.
        Uses do-calculus: do(X_i = v) and propagate through the graph.

        Returns: new probability after intervention.
        """
        X_new = X.copy().flatten()
        idx = intervention["feature_idx"]
        old_val = X_new[idx]
        new_val = float(intervention["new_value"])
        X_new[idx] = new_val

        # Propagate causal effect through graph
        delta_input = new_val - old_val

        # Find which causal variable this feature maps to
        causal_var = None
        for var, indices in FEATURE_TO_CAUSAL.items():
            if idx in indices:
                causal_var = var
                break

        if causal_var is None:
            # No known causal path — use linear approximation
            return float(np.clip(base_probability + delta_input * 0.1, 0.01, 0.99))

        # Find path to outcome and compute effect magnitude
        path = self._find_path(causal_var, "payment_missed_prob")
        if not path:
            return base_probability

        path_strength  = 1.0
        path_direction = 1
        for seg in path:
            path_strength  *= seg["strength"]
            path_direction *= (1 if seg["direction"] == "+" else -1)

        # Total causal effect on probability
        effect = delta_input * path_strength * path_direction * 0.5  # scale factor
        new_prob = float(np.clip(base_probability + effect, 0.01, 0.99))
        return new_prob

    # ── trajectory forecasting ────────────────────────────────────────────
    def forecast_trajectory(
        self,
        X: np.ndarray,
        base_probability: float,
        horizons: list[int] = [3, 6, 12],
    ) -> dict:
        """
        Simulate score trajectory over horizons (in months).

        Models natural mean-reversion + behavioral momentum + macro trend.
        Returns dict: {"month_3": {...}, "month_6": {...}, "month_12": {...}}
        """
        X_flat    = X.flatten()
        result    = {}
        prob      = base_probability

        # Behavioral momentum (is the applicant improving or deteriorating?)
        # Proxied by payment consistency (feature ~200) and spending entropy (feature ~150)
        payment_trend   = float(X_flat[200]) if len(X_flat) > 200 else 0.5
        entropy_trend   = float(X_flat[156]) if len(X_flat) > 156 else 0.5
        income_trend    = float(X_flat[54])  if len(X_flat) > 54  else 0.5

        # Monthly drift rate (positive = improving, negative = deteriorating)
        # Calibrated so median applicant mean-reverts at ~2pts/month
        monthly_drift = (
            (payment_trend - 0.5) * -0.015 +  # good payment = reduces risk
            (entropy_trend - 0.5) * -0.008 +  # stable spending = reduces risk
            (income_trend - 0.5)  * -0.010    # income growth = reduces risk
        )

        running_prob = prob
        for h in horizons:
            # Compound drift over h months with mean reversion
            mean_reversion_rate = 0.03
            for _ in range(h):
                running_prob = (running_prob
                                + monthly_drift
                                + mean_reversion_rate * (0.1 - running_prob))  # pull toward 10% base
                running_prob = float(np.clip(running_prob, 0.01, 0.99))

            from oracle.model import OracleModel
            # Convert back to score
            log_odds = math.log(max(running_prob, 1e-6) / max(1 - running_prob, 1e-6))
            forecast_score = float(np.clip(680 - (log_odds * 55), 300, 850))

            # Top 3 drivers of change at this horizon
            drivers = []
            if payment_trend > 0.6:
                drivers.append("Continued on-time payment history")
            elif payment_trend < 0.4:
                drivers.append("Payment delinquency risk increasing")
            if income_trend > 0.6:
                drivers.append("Income growth supporting stability")
            if entropy_trend < 0.4:
                drivers.append("Spending pattern volatility")

            result[f"month_{h}"] = {
                "predicted_score":    round(forecast_score),
                "predicted_prob":     round(running_prob, 4),
                "score_delta":        round(forecast_score - (680 - (math.log(max(prob,1e-6)/max(1-prob,1e-6)) * 55))),
                "key_drivers":        drivers[:2],
                "trend":              "improving" if running_prob < prob else "deteriorating"
                                       if running_prob > prob * 1.1 else "stable",
            }

        return result

    # ── save / load ───────────────────────────────────────────────────────
    def save(self, path: Path):
        state = {
            "edges": self.edges,
            "edge_weights": {str(k): v for k, v in self.edge_weights.items()},
        }
        with open(path, "w") as f:
            json.dump(state, f, indent=2)

    @classmethod
    def load(cls, path: Path) -> "CausalCreditGraph":
        g = cls()
        if Path(path).exists():
            with open(path, "r") as f:
                state = json.load(f)
            if "edges" in state:
                g.edges = state["edges"]
                g._build_adjacency()
        return g
