"""
oracle/fairness.py
==================
Adversarial Debiasing Layer + ECOA Compliance Engine.

The problem with post-hoc fairness:
  "We'll check for bias after training" still means the model LEARNED the bias.
  Post-hoc corrections reduce bias at the cost of accuracy.

ORACLE's solution: adversarial training.
  - A dedicated "adversary" network tries to predict protected attribute proxies
    from the main model's intermediate representations.
  - The main model is penalized when the adversary succeeds.
  - Result: the main model CANNOT learn protected-attribute proxies —
    because doing so hurts its own loss.

Protected attribute proxies detected (legally, we can never use protected
attributes directly, so we detect their proxies):
  1. ZIP code clusters (income/race proxy)
  2. Employer SIC code clusters (occupation → gender proxy)  
  3. Seasonal payment patterns (cultural calendar proxy)
  4. Name entropy (national origin proxy — never stored, only used in adversary)
  5. Area code clusters (geography → race proxy)

ECOA Adverse Action Codes:
  ORACLE auto-generates ECOA-compliant adverse action reasons from
  counterfactuals. These are legally defensible and auditable.
"""

from __future__ import annotations
import numpy as np
import pickle
from pathlib import Path
from typing import Optional


# ─────────────────────────────────────────────────────────────────────────────
# ECOA-COMPLIANT REASON CODE MAPPING
# Maps internal feature/counterfactual names → official ECOA reason codes
# ─────────────────────────────────────────────────────────────────────────────

ECOA_REASON_CODES = {
    # Payment history
    "payment_timing_jitter":      ("01", "Delinquent past or present credit obligations with others"),
    "payment_consistency":        ("01", "Delinquent past or present credit obligations with others"),
    "missed_payment":             ("01", "Delinquent past or present credit obligations with others"),

    # Utilization / balances
    "utilization_velocity":       ("02", "Level of delinquency on accounts"),
    "revolving_balance_growth":   ("03", "Number of accounts with delinquency"),
    "revolving_utilization":      ("07", "Too many accounts with balances"),

    # Credit history length
    "long_credit_history":        ("08", "Length of time accounts have been established"),
    "thin_file":                  ("08", "Length of time accounts have been established"),
    "oldest_account_months":      ("08", "Length of time accounts have been established"),

    # Inquiries
    "inquiry_burst":              ("09", "Too many recent inquiries in the last 12 months"),
    "credit_seeking_signal":      ("09", "Too many recent inquiries in the last 12 months"),

    # Income / capacity
    "income_volatility":          ("14", "Insufficient length of employment"),
    "employment_instability":     ("14", "Insufficient length of employment"),
    "income_to_debt_ratio":       ("18", "Insufficient income"),

    # Spending patterns
    "spending_entropy_drop":      ("20", "Account payment history too new to rate"),
    "financial_disorg_signal":    ("21", "Insufficient account information"),

    # Macro
    "macro_rate_shock":           ("22", "Too many open revolving credit accounts"),
    "installment_stress":         ("22", "Too many open revolving credit accounts"),
}

# Human-readable versions for user-facing explanations
USER_FACING_REASONS = {
    "payment_timing_jitter":      "Payment history shows inconsistent or late payments",
    "payment_consistency":        "Recent payment delinquencies on accounts",
    "utilization_velocity":       "Credit card balances are too high relative to limits",
    "revolving_balance_growth":   "Revolving account balances have been increasing",
    "thin_file":                  "Limited credit history — not enough data to fully assess",
    "inquiry_burst":              "Too many recent credit applications (hard inquiries)",
    "income_volatility":          "Income appears inconsistent or insufficient",
    "employment_instability":     "Employment history is too short or inconsistent",
    "spending_entropy_drop":      "Unusual change in spending patterns",
    "income_to_debt_ratio":       "Monthly debt obligations too high relative to income",
    "revolving_utilization":      "Credit utilization ratio is too high",
    "long_credit_history":        "Credit accounts are too new",
}


# ─────────────────────────────────────────────────────────────────────────────
# FAIRNESS CHECKER (inference-time check)
# ─────────────────────────────────────────────────────────────────────────────

class AdversarialFairnessLayer:
    """
    At inference: checks whether the current prediction is "fair" —
    meaning an adversary cannot reconstruct protected-class proxies
    from the feature vector + score.

    At training: the adversary is trained adversarially (see trainer.py).
    The inference check uses the trained adversary's confidence as a signal.

    Fairness threshold: adversary confidence < 0.65 (near-random = 0.5 for
    binary, ~0.33 for 3-class). We allow slight above-random to account
    for genuinely correlated financial patterns.
    """

    FAIRNESS_THRESHOLD = 0.65  # adversary max confidence for "fair" prediction

    def __init__(self):
        self.adversary_weights: Optional[np.ndarray] = None  # logistic adversary
        self.adversary_bias:    Optional[np.ndarray] = None
        self.n_protected_classes = 8
        self._calibrated = False

    def check(self, X: np.ndarray, score_prob: float) -> bool:
        """
        Returns True if the prediction passes the fairness check.
        Fast check — runs in < 1ms.
        """
        if not self._calibrated or self.adversary_weights is None:
            return True  # if no adversary loaded, pass (training mode)

        # Augment with score probability as additional signal
        X_aug = np.concatenate([X.flatten(), [score_prob]])

        # Forward pass through logistic adversary
        logits = X_aug @ self.adversary_weights + self.adversary_bias
        probs  = self._softmax(logits)
        max_confidence = float(np.max(probs))

        return max_confidence < self.FAIRNESS_THRESHOLD

    def ecoa_reasons(self, counterfactuals: list[dict]) -> list[str]:
        """
        Convert counterfactuals into ECOA-compliant adverse action reasons.
        Returns up to 4 reason strings (ECOA requires max 4).

        Reasons are derived from what WOULD change the outcome —
        which makes them accurate, actionable, and legally defensible.
        """
        reasons = []
        seen_codes = set()

        for cf in counterfactuals:
            factor = cf.get("factor", "")
            if factor in ECOA_REASON_CODES:
                code, text = ECOA_REASON_CODES[factor]
                if code not in seen_codes:
                    reasons.append(text)
                    seen_codes.add(code)
            if len(reasons) >= 4:
                break

        # Fallback if no counterfactuals map
        if not reasons:
            reasons = ["Insufficient credit history or information"]

        return reasons

    def user_reasons(self, counterfactuals: list[dict]) -> list[str]:
        """
        User-facing version of adverse action reasons.
        Plain English, not the formal ECOA legal text.
        """
        reasons = []
        for cf in counterfactuals:
            factor = cf.get("factor", "")
            if factor in USER_FACING_REASONS:
                reasons.append(USER_FACING_REASONS[factor])
            if len(reasons) >= 4:
                break

        if not reasons:
            reasons = ["Limited credit history available for assessment"]
        return reasons

    def demographic_parity_report(
        self,
        predictions: np.ndarray,
        protected_groups: np.ndarray,  # integer group labels
    ) -> dict:
        """
        Compute demographic parity metrics.
        Called periodically (not per-inference) for monitoring.

        Returns:
            dict with approval rates by group and Equal Opportunity Difference.
        """
        report = {}
        groups = np.unique(protected_groups)

        approval_rates = {}
        for g in groups:
            mask = protected_groups == g
            group_preds = predictions[mask]
            # "Approved" = score >= 640 (probability-based threshold)
            approval_rate = float(np.mean(group_preds < 0.2))  # prob < 0.2 = approved
            approval_rates[int(g)] = round(approval_rate, 4)

        max_rate = max(approval_rates.values())
        min_rate = min(approval_rates.values())
        disparate_impact = min_rate / max(max_rate, 1e-8)

        report["approval_rates_by_group"] = approval_rates
        report["disparate_impact_ratio"]  = round(disparate_impact, 4)
        report["equal_opportunity_diff"]  = round(max_rate - min_rate, 4)
        report["passes_80pct_rule"]       = disparate_impact >= 0.8
        report["cfpb_threshold_met"]      = (max_rate - min_rate) <= 0.05

        return report

    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        x = x - np.max(x)
        e = np.exp(x)
        return e / e.sum()

    def save(self, path: Path):
        state = {
            "weights":     self.adversary_weights,
            "bias":        self.adversary_bias,
            "n_protected": self.n_protected_classes,
            "calibrated":  self._calibrated,
        }
        with open(path, "wb") as f:
            pickle.dump(state, f)

    @classmethod
    def load(cls, path: Path) -> "AdversarialFairnessLayer":
        layer = cls()
        if Path(path).exists():
            with open(path, "rb") as f:
                state = pickle.load(f)
            layer.adversary_weights     = state.get("weights")
            layer.adversary_bias        = state.get("bias")
            layer.n_protected_classes   = state.get("n_protected", 8)
            layer._calibrated           = state.get("calibrated", False)
        return layer
