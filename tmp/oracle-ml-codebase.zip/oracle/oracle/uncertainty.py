"""
oracle/uncertainty.py — Conformal Prediction Intervals
oracle/trajectory.py  — Score Trajectory Forecaster (combined for brevity)
"""

from __future__ import annotations
import numpy as np
import pickle
import math
from pathlib import Path


# ─────────────────────────────────────────────────────────────────────────────
# CONFORMAL PREDICTOR
# Provides calibrated prediction intervals WITHOUT distributional assumptions.
# "Score: 720 ± 18 (95% CI)" — every output has honest uncertainty.
# ─────────────────────────────────────────────────────────────────────────────

class ConformalPredictor:
    """
    Inductive Conformal Prediction for probability intervals.

    Calibrated on a held-out calibration set: we know the model's
    nonconformity scores (how "surprising" each prediction was),
    and we use those to set a threshold for new predictions.

    Coverage guarantee: 95% of true labels will fall within the interval
    (distribution-free, no normality assumptions).
    """

    def __init__(self, alpha: float = 0.05):
        self.alpha               = alpha
        self.calibration_scores: np.ndarray | None = None  # nonconformity scores from cal set
        self._fitted             = False

    def fit(self, probabilities: np.ndarray, true_labels: np.ndarray):
        """
        Fit on calibration set.
        probabilities: (n_cal,) float32 predicted probabilities
        true_labels:   (n_cal,) binary int
        """
        # Nonconformity score: how wrong was the prediction?
        # For binary classification: 1 - P(true class)
        scores = np.where(
            true_labels == 1,
            1.0 - probabilities,
            probabilities,
        )
        self.calibration_scores = np.sort(scores)
        self._fitted = True
        return self

    def predict_interval(
        self,
        X: np.ndarray,
        model_prob: float | None = None,
        alpha: float | None = None,
    ) -> tuple[float, float]:
        """
        Returns (lower_prob, upper_prob) for the given feature vector.

        If model_prob is provided, uses it; otherwise assumes external call.
        alpha: significance level (default: self.alpha = 0.05 → 95% CI)
        """
        if not self._fitted or self.calibration_scores is None:
            # Not calibrated — return wide interval as safe fallback
            if model_prob is not None:
                margin = 0.15
                return (
                    float(np.clip(model_prob - margin, 0.01, 0.99)),
                    float(np.clip(model_prob + margin, 0.01, 0.99)),
                )
            return (0.01, 0.99)

        a = alpha if alpha is not None else self.alpha
        n = len(self.calibration_scores)
        q_idx = math.ceil((n + 1) * (1 - a)) - 1
        q_idx = max(0, min(q_idx, n - 1))
        threshold = float(self.calibration_scores[q_idx])

        if model_prob is None:
            return (0.0, threshold)

        lower = float(np.clip(model_prob - threshold, 0.01, 0.99))
        upper = float(np.clip(model_prob + threshold, 0.01, 0.99))
        return (lower, upper)

    def coverage_report(
        self,
        probabilities: np.ndarray,
        true_labels: np.ndarray,
    ) -> dict:
        """Verify empirical coverage on a test set."""
        results = []
        for prob, label in zip(probabilities, true_labels):
            lo, hi = self.predict_interval(None, model_prob=prob)
            covered = (label >= lo and label <= hi)  # noqa
            results.append(covered)
        coverage = float(np.mean(results))
        return {
            "empirical_coverage": round(coverage, 4),
            "target_coverage":    1.0 - self.alpha,
            "coverage_met":       coverage >= (1.0 - self.alpha - 0.02),
        }

    def save(self, path: Path):
        with open(path, "wb") as f:
            pickle.dump({
                "calibration_scores": self.calibration_scores,
                "alpha": self.alpha,
                "_fitted": self._fitted,
            }, f)

    @classmethod
    def load(cls, path: Path) -> "ConformalPredictor":
        cp = cls()
        if Path(path).exists():
            with open(path, "rb") as f:
                state = pickle.load(f)
            cp.calibration_scores = state.get("calibration_scores")
            cp.alpha              = state.get("alpha", 0.05)
            cp._fitted            = state.get("_fitted", False)
        return cp


# ─────────────────────────────────────────────────────────────────────────────
# TRAJECTORY FORECASTER
# Thin wrapper around CausalCreditGraph.forecast_trajectory
# ─────────────────────────────────────────────────────────────────────────────

class TrajectoryForecaster:
    """
    Wraps CausalCreditGraph trajectory simulation.
    Produces the 3/6/12-month score forecasts shown on the UI.
    """

    def __init__(self, causal_graph):
        self.causal_graph = causal_graph

    def forecast(
        self,
        X: np.ndarray,
        base_prob: float | None = None,
        horizons: list[int] | None = None,
    ) -> dict:
        """
        Forecast score trajectory.

        If base_prob not provided, a neutral 0.10 probability is used.
        Horizons default to [3, 6, 12] months.
        """
        if horizons is None:
            horizons = [3, 6, 12]
        if base_prob is None:
            base_prob = 0.10

        return self.causal_graph.forecast_trajectory(
            X=X,
            base_probability=base_prob,
            horizons=horizons,
        )
