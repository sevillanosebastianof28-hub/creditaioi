"""
ORACLE — Omni-modal Reasoning & Causal Learning Engine
Credit Intelligence Model for credit-ai.com

Package structure:
  oracle/model.py          — Main OracleModel class (inference)
  oracle/trainer.py        — Training loop (multi-objective)
  oracle/features.py       — Feature engineering pipeline
  oracle/causal_graph.py   — Neural Granger + SCM
  oracle/fairness.py       — Adversarial debiasing layer
  oracle/explainer.py      — Counterfactual + narrative explainer
  oracle/uncertainty.py    — Conformal prediction / calibration
  oracle/trajectory.py     — 3/6/12mo score forecast
  oracle/export.py         — ONNX export utilities
"""

__version__ = "1.0.0"
__author__  = "credit-ai.com"
