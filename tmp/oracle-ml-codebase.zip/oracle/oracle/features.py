"""
oracle/features.py
==================
512-dimensional feature engineering pipeline.

Takes raw applicant data (transactions, bureau data, application fields,
macro context) and produces a normalized float32 vector for ORACLE inference.

Feature categories:
  [0:50]    Bureau snapshot features
  [50:150]  Transaction velocity & ratio features (30/60/90d windows)
  [150:200] Spending entropy & diversity features
  [200:260] Payment timing & consistency features
  [260:320] Transaction text embedding (PCA of FinBERT output)
  [320:380] Behavioral biometric features
  [380:440] Graph-based spending pattern features
  [440:490] Temporal seasonality decomposition
  [490:512] Macro-economic context features
"""

from __future__ import annotations
import numpy as np
import pickle
import hashlib
from datetime import datetime, timedelta
from collections import Counter
from pathlib import Path
from typing import Optional
import math


# ─────────────────────────────────────────────────────────────────────────────
# INPUT SCHEMA
# ─────────────────────────────────────────────────────────────────────────────

REQUIRED_FIELDS = [
    # Bureau snapshot
    "fico_score",            # int 300–850 (use 0 if thin file)
    "total_accounts",        # int
    "open_accounts",         # int
    "derogatory_marks",      # int
    "inquiries_6mo",         # int
    "inquiries_12mo",        # int
    "oldest_account_months", # int
    "avg_account_age_months",# int
    "revolving_utilization", # float 0–1
    "installment_balance",   # float USD
    "revolving_balance",     # float USD
    "collections",           # int
    "bankruptcies",          # int (0 or 1)
    "tax_liens",             # int

    # Income & application
    "stated_income",         # float annual USD
    "stated_expenses",       # float monthly USD
    "loan_amount_requested", # float USD
    "loan_purpose",          # str: "debt_consolidation"|"home_improvement"|"business"|"personal"|"auto"|"education"
    "employment_months",     # int
    "employment_type",       # str: "employed"|"self_employed"|"contractor"|"unemployed"|"retired"

    # Transactions (list of dicts, last 24 months)
    # Each: {"date": "YYYY-MM-DD", "amount": float, "description": str,
    #        "category": str, "merchant": str, "type": "debit"|"credit"}
    "transactions",

    # Payment history (list of dicts, last 24 months)
    # Each: {"due_date": "YYYY-MM-DD", "paid_date": "YYYY-MM-DD"|null,
    #        "amount": float, "status": "on_time"|"late_30"|"late_60"|"late_90"|"missed"}
    "payment_history",
]

OPTIONAL_FIELDS = [
    "behavioral_signals",    # dict: {"avg_session_minutes": float, "login_frequency_weekly": float, "form_completion_rate": float}
    "application_text",      # str: free-text about loan purpose (processed by NLP encoder)
]

MACRO_FIELDS = [
    "fed_funds_rate",        # float %
    "cpi_yoy",               # float % year-over-year
    "unemployment_rate",     # float %
    "consumer_sentiment",    # float index 0–150 (UMich)
    "sp500_30d_return",      # float %
    "credit_card_delinquency_rate", # float % national average
]


# ─────────────────────────────────────────────────────────────────────────────
# FEATURE PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

class FeaturePipeline:
    """
    Transforms raw applicant data into a 512-dim float32 vector.
    All features are normalized to [0,1] or [-1,1] via fitted scalers.
    """

    FEATURE_DIM = 512

    def __init__(self):
        self.scaler          = None   # StandardScaler fitted on training data
        self.text_encoder    = None   # lightweight text embedding (TF-IDF or ONNX FinBERT)
        self.category_maps   = {}     # categorical → int mappings
        self._fitted         = False

    # ── inference transform ─────────────────────────────────────────────
    def transform(self, raw: dict, macro: dict) -> np.ndarray:
        """
        Transform a single applicant's raw data into a 512-dim feature vector.

        Returns:
            np.ndarray of shape (1, 512) dtype float32
        """
        parts = []

        # [0:50] Bureau features
        parts.append(self._bureau_features(raw))

        # [50:150] Transaction velocity features
        parts.append(self._velocity_features(raw.get("transactions", [])))

        # [150:200] Spending entropy features
        parts.append(self._entropy_features(raw.get("transactions", [])))

        # [200:260] Payment behavior features
        parts.append(self._payment_features(raw.get("payment_history", [])))

        # [260:320] Text embedding (transaction descriptions)
        parts.append(self._text_features(raw.get("transactions", []),
                                          raw.get("application_text", "")))

        # [320:380] Behavioral signals
        parts.append(self._behavioral_features(raw.get("behavioral_signals", {})))

        # [380:440] Spending graph features
        parts.append(self._graph_features(raw.get("transactions", [])))

        # [440:490] Seasonality decomposition
        parts.append(self._seasonality_features(raw.get("transactions", [])))

        # [490:512] Macro context
        parts.append(self._macro_features(macro))

        X = np.concatenate(parts).astype(np.float32)

        # Pad or truncate to exactly FEATURE_DIM
        if len(X) < self.FEATURE_DIM:
            X = np.pad(X, (0, self.FEATURE_DIM - len(X)))
        else:
            X = X[:self.FEATURE_DIM]

        if self._fitted and self.scaler is not None:
            X = self.scaler.transform(X.reshape(1, -1))
        else:
            X = X.reshape(1, -1)

        return X  # shape (1, 512)

    # ── bureau features [0:50] ──────────────────────────────────────────
    def _bureau_features(self, raw: dict) -> np.ndarray:
        f = np.zeros(50, dtype=np.float32)
        f[0]  = self._scale(raw.get("fico_score", 300), 300, 850)
        f[1]  = self._scale(raw.get("total_accounts", 0), 0, 50)
        f[2]  = self._scale(raw.get("open_accounts", 0), 0, 30)
        f[3]  = min(raw.get("derogatory_marks", 0) / 10.0, 1.0)
        f[4]  = min(raw.get("inquiries_6mo", 0) / 10.0, 1.0)
        f[5]  = min(raw.get("inquiries_12mo", 0) / 15.0, 1.0)
        f[6]  = self._scale(raw.get("oldest_account_months", 0), 0, 360)
        f[7]  = self._scale(raw.get("avg_account_age_months", 0), 0, 240)
        f[8]  = float(raw.get("revolving_utilization", 0))              # already 0–1
        f[9]  = self._scale(raw.get("installment_balance", 0), 0, 200000)
        f[10] = self._scale(raw.get("revolving_balance", 0), 0, 50000)
        f[11] = 1.0 if raw.get("collections", 0) > 0 else 0.0
        f[12] = float(raw.get("bankruptcies", 0))
        f[13] = float(min(raw.get("tax_liens", 0), 1))
        f[14] = self._scale(raw.get("stated_income", 0), 0, 500000)
        f[15] = self._scale(raw.get("stated_expenses", 0), 0, 20000)
        f[16] = self._scale(raw.get("loan_amount_requested", 0), 0, 100000)
        # Debt-to-income ratio
        monthly_income = raw.get("stated_income", 1) / 12
        dti = raw.get("stated_expenses", 0) / max(monthly_income, 1)
        f[17] = min(dti, 3.0) / 3.0
        # Loan-to-income ratio
        f[18] = min(raw.get("loan_amount_requested", 0) / max(raw.get("stated_income", 1), 1), 5) / 5
        # Employment stability
        f[19] = self._scale(raw.get("employment_months", 0), 0, 120)
        # Employment type encoding
        emp_types = {"employed": 0.9, "self_employed": 0.6, "contractor": 0.5,
                     "unemployed": 0.0, "retired": 0.7}
        f[20] = emp_types.get(raw.get("employment_type", "employed"), 0.5)
        # Loan purpose risk encoding
        purpose_risk = {"debt_consolidation": 0.6, "home_improvement": 0.3,
                        "business": 0.7, "personal": 0.5, "auto": 0.4, "education": 0.2}
        f[21] = purpose_risk.get(raw.get("loan_purpose", "personal"), 0.5)
        # Utilization × inquiries interaction
        f[22] = f[8] * f[4]
        # Derogatory × recency interaction
        f[23] = f[3] * (1.0 - f[7])  # old derogs less risky
        # Thin file indicator
        f[24] = 1.0 if raw.get("total_accounts", 0) < 3 else 0.0
        return f

    # ── velocity features [50:150] ──────────────────────────────────────
    def _velocity_features(self, txns: list) -> np.ndarray:
        """Rolling spend/income ratios over 30/60/90/180d windows."""
        f = np.zeros(100, dtype=np.float32)
        if not txns:
            return f

        today = datetime.today()
        windows = [30, 60, 90, 180]

        for i, days in enumerate(windows):
            cutoff = today - timedelta(days=days)
            period_txns = [t for t in txns
                          if self._parse_date(t.get("date","")) > cutoff]

            debits  = [t["amount"] for t in period_txns if t.get("type","debit")=="debit"]
            credits = [t["amount"] for t in period_txns if t.get("type","")=="credit"]

            total_spend  = sum(debits)
            total_income = sum(credits)

            base = i * 20
            f[base+0]  = self._scale(total_spend,  0, 50000)
            f[base+1]  = self._scale(total_income, 0, 50000)
            f[base+2]  = min(total_spend / max(total_income, 1), 3.0) / 3.0  # spend/income ratio
            f[base+3]  = self._scale(len(debits), 0, 500)                     # transaction count
            f[base+4]  = self._scale(np.mean(debits) if debits else 0, 0, 5000)  # avg txn size
            f[base+5]  = self._scale(np.std(debits) if len(debits) > 1 else 0, 0, 3000)  # spend volatility
            # Month-over-month velocity ratio (acceleration of spending)
            if i > 0:
                prev_days  = windows[i-1]
                prev_cutoff = today - timedelta(days=prev_days)
                prev_txns   = [t for t in txns
                               if self._parse_date(t.get("date","")) > prev_cutoff]
                prev_spend  = sum(t["amount"] for t in prev_txns if t.get("type","debit")=="debit")
                daily_curr  = total_spend / max(days, 1)
                daily_prev  = prev_spend / max(prev_days, 1)
                f[base+6]   = min(daily_curr / max(daily_prev, 0.01), 5.0) / 5.0
            f[base+7]  = self._scale(max(debits) if debits else 0, 0, 20000)  # max single spend
            # Night-time spending ratio (behavioral signal)
            # (We can't know hours from dates alone; proxy via description keywords)
            late_keywords = ["uber eats","doordash","grubhub","bar","club","lyft night"]
            late_spend = sum(t["amount"] for t in period_txns
                            if any(k in t.get("description","").lower() for k in late_keywords))
            f[base+8]  = min(late_spend / max(total_spend, 1), 1.0)
            # Essential spend ratio (rent+groceries+utilities as % of total)
            essential = {"rent","mortgage","grocery","groceries","utilities","electric","gas utility","water"}
            ess_spend  = sum(t["amount"] for t in period_txns
                            if any(e in t.get("category","").lower() for e in essential))
            f[base+9]  = min(ess_spend / max(total_spend, 1), 1.0)

        return f[:100]

    # ── entropy features [150:200] ──────────────────────────────────────
    def _entropy_features(self, txns: list) -> np.ndarray:
        """
        Spending diversity entropy.
        High entropy = diverse spending across many categories = stability signal.
        Sudden entropy drop = stress signal.
        """
        f = np.zeros(50, dtype=np.float32)
        if not txns:
            return f

        categories = [t.get("category","unknown") for t in txns]
        merchants  = [t.get("merchant","unknown") for t in txns]
        amounts    = [t.get("amount", 0) for t in txns if t.get("type","debit")=="debit"]

        # Shannon entropy of category distribution
        cat_counts  = Counter(categories)
        total_cats  = sum(cat_counts.values())
        cat_entropy = -sum((c/total_cats) * math.log2(c/total_cats)
                          for c in cat_counts.values() if c > 0)
        f[0] = min(cat_entropy / 5.0, 1.0)  # normalize by max reasonable entropy

        # Merchant concentration (HHI — high concentration = risky)
        merch_counts = Counter(merchants)
        merch_total  = sum(merch_counts.values())
        hhi = sum((c/merch_total)**2 for c in merch_counts.values())
        f[1] = float(hhi)

        # Number of unique categories / total transactions
        f[2] = min(len(cat_counts) / max(len(txns), 1) * 10, 1.0)

        # Spending Gini coefficient (inequality in transaction amounts)
        if len(amounts) > 1:
            arr  = np.sort(np.array(amounts, dtype=float))
            n    = len(arr)
            gini = (2 * np.sum(np.arange(1, n+1) * arr) - (n+1) * np.sum(arr)) / (n * np.sum(arr))
            f[3] = float(np.clip(gini, 0, 1))

        # Category entropy 30d vs 90d (entropy drop = stress signal)
        today  = datetime.today()
        txns_30 = [t for t in txns if self._parse_date(t.get("date","")) > today - timedelta(30)]
        txns_90 = [t for t in txns if self._parse_date(t.get("date","")) > today - timedelta(90)]

        def entropy(tlist):
            if not tlist: return 0
            cc = Counter(t.get("category","") for t in tlist)
            tot = sum(cc.values())
            return -sum((c/tot)*math.log2(c/tot) for c in cc.values() if c > 0)

        ent_30 = entropy(txns_30)
        ent_90 = entropy(txns_90)
        f[4] = min(ent_30 / 5.0, 1.0)
        f[5] = min(ent_90 / 5.0, 1.0)
        f[6] = (ent_90 - ent_30) / max(ent_90, 0.01)  # entropy drop ratio (key stress signal)

        # Subscription detection (recurring charges = stable spending pattern)
        desc_list = [t.get("description","").lower() for t in txns]
        sub_keywords = ["netflix","spotify","amazon prime","hulu","apple","gym","subscription",
                        "membership","monthly","annual fee"]
        sub_count = sum(1 for d in desc_list if any(k in d for k in sub_keywords))
        f[7] = min(sub_count / 20.0, 1.0)

        # Food delivery over-indexing (impulsive spending proxy)
        food_keywords = ["uber eats","doordash","grubhub","postmates","seamless","delivery"]
        food_spend = sum(t.get("amount",0) for t in txns
                        if any(k in t.get("description","").lower() for k in food_keywords))
        total_spend = sum(t.get("amount",0) for t in txns if t.get("type","debit")=="debit")
        f[8] = min(food_spend / max(total_spend, 1), 1.0)

        return f

    # ── payment behavior features [200:260] ────────────────────────────
    def _payment_features(self, history: list) -> np.ndarray:
        """
        Payment timing, consistency, and pattern analysis.
        Key insight: HOW LATE you pay matters more than IF you pay late.
        """
        f = np.zeros(60, dtype=np.float32)
        if not history:
            return f

        total = len(history)
        on_time = sum(1 for p in history if p.get("status") == "on_time")
        late_30 = sum(1 for p in history if p.get("status") == "late_30")
        late_60 = sum(1 for p in history if p.get("status") == "late_60")
        late_90 = sum(1 for p in history if p.get("status") == "late_90")
        missed  = sum(1 for p in history if p.get("status") == "missed")

        f[0] = on_time / total                              # on-time rate
        f[1] = late_30 / total
        f[2] = late_60 / total
        f[3] = late_90 / total
        f[4] = missed / total

        # Weighted payment score (worse lates penalized more)
        weighted_bad = (late_30*1 + late_60*2 + late_90*4 + missed*8) / (total * 8)
        f[5] = 1.0 - min(weighted_bad, 1.0)

        # Payment timing jitter (std dev of days early/late → consistency signal)
        delays = []
        for p in history:
            if p.get("paid_date") and p.get("due_date"):
                try:
                    due  = datetime.strptime(p["due_date"], "%Y-%m-%d")
                    paid = datetime.strptime(p["paid_date"], "%Y-%m-%d")
                    delays.append((paid - due).days)
                except:
                    pass

        if delays:
            f[6]  = self._scale(np.mean(delays), -30, 30)   # avg days early(neg) / late(pos)
            f[7]  = min(np.std(delays) / 30.0, 1.0)          # timing jitter (key signal)
            f[8]  = 1.0 if min(delays) < -7 else 0.0         # ever paid 1+ week early?
            f[9]  = 1.0 if max(delays) > 30 else 0.0         # ever paid 30+ days late?

        # Recency weighting: recent lates matter more than old lates
        # Weight exponentially: last 6mo × 1.0, 6-12mo × 0.6, 12-24mo × 0.3
        recent_bad  = sum(1 for p in history[-6:]  if p.get("status") != "on_time")
        mid_bad     = sum(1 for p in history[-12:-6] if p.get("status") != "on_time")
        old_bad     = sum(1 for p in history[-24:-12] if p.get("status") != "on_time")
        f[10] = min((recent_bad*1.0 + mid_bad*0.6 + old_bad*0.3) / (len(history) * 1.0), 1.0)

        # Payment amount coverage ratio (partial payments = stress signal)
        for i, p in enumerate(history[:20]):
            # Simplified: 1.0 if full payment, 0.5 if partial (status proxy)
            f[20+i] = 0.0 if p.get("status") in ("late_90","missed") else 1.0

        return f

    # ── text features [260:320] ──────────────────────────────────────────
    def _text_features(self, txns: list, app_text: str) -> np.ndarray:
        """
        Lightweight text features from transaction descriptions.
        In production: replaced by PCA(60) of FinBERT embeddings.
        Here: TF-IDF proxy with behavioral keyword scoring.
        """
        f = np.zeros(60, dtype=np.float32)

        # Behavioral keyword groups — each maps to a financial meaning
        keyword_groups = {
            "stability":    ["rent","mortgage","insurance","utilities","subscription","gym"],
            "impulsive":    ["casino","gambling","bet","lottery","uber eats","doordash","nightclub"],
            "stress":       ["payday loan","cash advance","overdraft","nsf fee","late fee","collection"],
            "growth":       ["investment","stocks","401k","savings","brokerage","ira"],
            "luxury":       ["luxury","designer","jewelry","hotel","resort","first class","business class"],
            "essentials":   ["grocery","groceries","pharmacy","doctor","hospital","school","childcare"],
            "debt_service": ["loan payment","student loan","car payment","credit card payment","minimum payment"],
        }

        all_descs = " ".join(t.get("description","").lower() for t in txns) + " " + app_text.lower()

        for i, (group, keywords) in enumerate(keyword_groups.items()):
            count = sum(all_descs.count(k) for k in keywords)
            f[i] = min(count / 50.0, 1.0)

        # Total transactions as text signal richness
        f[10] = min(len(txns) / 500.0, 1.0)

        # Application text length (more detailed application = lower fraud risk)
        f[11] = min(len(app_text) / 500.0, 1.0)

        # Stress keyword density in application text
        stress_words = ["desperate","urgent","emergency","behind","struggling","overdue"]
        f[12] = min(sum(1 for w in stress_words if w in app_text.lower()) / len(stress_words), 1.0)

        return f

    # ── behavioral signals [320:380] ────────────────────────────────────
    def _behavioral_features(self, signals: dict) -> np.ndarray:
        f = np.zeros(60, dtype=np.float32)
        if not signals:
            return f
        f[0] = min(signals.get("avg_session_minutes", 0) / 30.0, 1.0)
        f[1] = min(signals.get("login_frequency_weekly", 0) / 14.0, 1.0)
        f[2] = float(signals.get("form_completion_rate", 0))
        f[3] = min(signals.get("typing_speed_wpm", 40) / 120.0, 1.0)
        f[4] = min(signals.get("corrections_count", 0) / 20.0, 1.0)  # many corrections = uncertain
        f[5] = float(signals.get("used_autofill", 0))
        f[6] = min(signals.get("days_since_last_login", 0) / 365.0, 1.0)
        f[7] = min(signals.get("total_sessions_30d", 0) / 60.0, 1.0)
        return f

    # ── graph features [380:440] ─────────────────────────────────────────
    def _graph_features(self, txns: list) -> np.ndarray:
        """
        Spending as a graph: categories are nodes, co-occurrence in same week = edge.
        Graph structural features capture spending "lifestyle" patterns.
        """
        f = np.zeros(60, dtype=np.float32)
        if len(txns) < 5:
            return f

        categories = list({t.get("category","unknown") for t in txns})
        n = len(categories)
        f[0] = min(n / 30.0, 1.0)  # number of unique spending categories

        # Category transition matrix entropy
        cat_idx = {c: i for i, c in enumerate(categories)}
        today   = datetime.today()

        # Group by week
        weekly: dict[int, list] = {}
        for t in txns:
            d = self._parse_date(t.get("date",""))
            week = (today - d).days // 7
            if week not in weekly:
                weekly[week] = []
            weekly[week].append(t.get("category","unknown"))

        # Co-occurrence edges
        edges: dict[tuple, int] = {}
        for week_cats in weekly.values():
            unique_cats = list(set(week_cats))
            for i in range(len(unique_cats)):
                for j in range(i+1, len(unique_cats)):
                    key = tuple(sorted([unique_cats[i], unique_cats[j]]))
                    edges[key] = edges.get(key, 0) + 1

        f[1]  = min(len(edges) / 200.0, 1.0)   # graph density
        f[2]  = min(np.mean(list(edges.values())) / 20.0 if edges else 0, 1.0)  # avg edge weight
        f[3]  = min(len(weekly) / 52.0, 1.0)   # temporal coverage (weeks represented)

        return f

    # ── seasonality [440:490] ────────────────────────────────────────────
    def _seasonality_features(self, txns: list) -> np.ndarray:
        """STL-proxy: monthly spend Z-scores to detect spending spikes."""
        f = np.zeros(50, dtype=np.float32)
        if not txns:
            return f

        # Monthly spending totals
        monthly: dict[str, float] = {}
        for t in txns:
            if t.get("type","debit") != "debit":
                continue
            d = self._parse_date(t.get("date",""))
            key = d.strftime("%Y-%m")
            monthly[key] = monthly.get(key, 0) + t.get("amount",0)

        if len(monthly) < 3:
            return f

        values = np.array(list(monthly.values()), dtype=float)
        mean_m = np.mean(values)
        std_m  = np.std(values) + 1e-8

        # Z-scores of last 12 months
        sorted_months = sorted(monthly.keys())[-12:]
        for i, m in enumerate(sorted_months[:12]):
            z = (monthly[m] - mean_m) / std_m
            f[i] = float(np.clip(z, -3, 3)) / 3.0   # normalize z to [-1,1]

        # Holiday spending spike (Nov-Dec ratio vs annual avg)
        nov_dec = [monthly[k] for k in monthly if k.endswith("-11") or k.endswith("-12")]
        if nov_dec and mean_m > 0:
            f[12] = min(np.mean(nov_dec) / mean_m, 3.0) / 3.0

        # Trend: is spending increasing? (linear regression slope)
        if len(values) >= 6:
            x    = np.arange(len(values), dtype=float)
            slope = np.polyfit(x, values, 1)[0]
            f[13] = float(np.clip(slope / max(mean_m, 1), -1, 1))  # normalized slope

        return f

    # ── macro features [490:512] ─────────────────────────────────────────
    def _macro_features(self, macro: dict) -> np.ndarray:
        f = np.zeros(22, dtype=np.float32)
        f[0]  = self._scale(macro.get("fed_funds_rate", 3.0), 0, 10)
        f[1]  = self._scale(macro.get("cpi_yoy", 3.0), -2, 15)
        f[2]  = self._scale(macro.get("unemployment_rate", 4.0), 2, 15)
        f[3]  = self._scale(macro.get("consumer_sentiment", 90), 40, 140)
        f[4]  = self._scale(macro.get("sp500_30d_return", 0), -20, 20)
        f[5]  = self._scale(macro.get("credit_card_delinquency_rate", 2.5), 0, 10)
        # High-stress macro indicator (composite)
        stress = (
            (macro.get("fed_funds_rate", 3.0) / 10) * 0.3 +
            (macro.get("unemployment_rate", 4.0) / 15) * 0.4 +
            ((15 - max(macro.get("cpi_yoy", 3.0), 0)) / 15) * 0.3
        )
        f[6] = float(np.clip(stress, 0, 1))
        return f

    # ── utilities ────────────────────────────────────────────────────────
    @staticmethod
    def _scale(value, lo, hi):
        """Min-max scale to [0,1]."""
        return float(np.clip((value - lo) / max(hi - lo, 1e-8), 0.0, 1.0))

    @staticmethod
    def _parse_date(date_str: str) -> datetime:
        try:
            return datetime.strptime(date_str, "%Y-%m-%d")
        except:
            return datetime(2000, 1, 1)

    # ── fit / save / load ─────────────────────────────────────────────────
    def fit(self, X_raw: list[dict], macro_list: list[dict]):
        """Fit the scaler on training data."""
        from sklearn.preprocessing import StandardScaler
        vectors = np.vstack([self.transform(r, m) for r, m in zip(X_raw, macro_list)])
        self.scaler = StandardScaler()
        self.scaler.fit(vectors)
        self._fitted = True
        return self

    def save(self, path: Path):
        with open(path, "wb") as f:
            pickle.dump({"scaler": self.scaler,
                         "category_maps": self.category_maps,
                         "_fitted": self._fitted}, f)

    @classmethod
    def load(cls, path: Path) -> "FeaturePipeline":
        fp = cls()
        if Path(path).exists():
            with open(path, "rb") as f:
                state = pickle.load(f)
            fp.scaler       = state.get("scaler")
            fp.category_maps = state.get("category_maps", {})
            fp._fitted      = state.get("_fitted", False)
        return fp
