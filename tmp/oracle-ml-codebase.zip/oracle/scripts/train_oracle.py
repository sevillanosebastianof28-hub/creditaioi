"""
ORACLE Training Script
scripts/train_oracle.py

Full training pipeline. Run with:
    python scripts/train_oracle.py --data datasets/credit_applications.parquet --output models/
"""

import argparse, json, logging, os, pickle, time
import numpy as np
import pandas as pd
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
logger = logging.getLogger("oracle.train")


def get_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data",            default="datasets/credit_applications.parquet")
    p.add_argument("--macro-data",      default="datasets/macro_indicators.csv")
    p.add_argument("--output",          default="models/")
    p.add_argument("--epochs",          type=int,   default=100)
    p.add_argument("--fairness-lambda", type=float, default=0.5)
    p.add_argument("--seed",            type=int,   default=42)
    p.add_argument("--skip-sft",        action="store_true")
    p.add_argument("--skip-causal",     action="store_true")
    return p.parse_args()


def load_data(data_path: str, macro_path: str) -> dict:
    logger.info(f"Loading {data_path}")
    df = pd.read_parquet(data_path) if data_path.endswith(".parquet") else pd.read_csv(data_path)
    logger.info(f"Loaded {len(df):,} rows")
    df = df.sort_values("application_date").reset_index(drop=True)

    macro_df = pd.read_csv(macro_path, parse_dates=["date"]) if os.path.exists(macro_path) else None

    n = len(df)
    n_test, n_calib = int(n * 0.15), int(n * 0.10)
    return {
        "df_train": df.iloc[:n - n_test - n_calib],
        "df_calib": df.iloc[n - n_test - n_calib:n - n_test],
        "df_test":  df.iloc[n - n_test:],
        "macro_df": macro_df,
    }


def get_macro_context(date, macro_df) -> dict:
    defaults = {"fed_funds_rate": 5.25, "cpi_yoy": 3.2, "unemployment_rate": 3.9,
                "credit_spread": 105.0, "hpi_yoy": 3.5, "sector_stress": 0.2}
    if macro_df is None or date is None:
        return defaults
    try:
        dt = pd.to_datetime(date)
        row = macro_df.iloc[(macro_df["date"] - dt).abs().argsort().iloc[0]]
        return {k: float(row.get(k, defaults[k])) for k in defaults}
    except Exception:
        return defaults


def df_to_features(df: pd.DataFrame, macro_df) -> tuple[np.ndarray, np.ndarray, list]:
    import sys; sys.path.insert(0, str(Path(__file__).parent.parent))
    from ai.config.feature_encoder import FeatureEncoder

    enc = FeatureEncoder(scaler_params=None, feature_names=[])
    rows, labels = [], []
    for _, row in df.iterrows():
        txns = row.get("transactions", [])
        if isinstance(txns, str):
            try: txns = json.loads(txns)
            except: txns = []
        raw = {k: row.get(k) for k in [
            "fico_score","total_accounts","revolving_utilization",
            "missed_payments_12m","missed_payments_24m","derogatory_marks",
            "inquiries_6m","oldest_account_months","avg_account_age_months",
            "total_credit_limit","total_balance","stated_income","income_verified",
            "employment_months","employment_type","loan_amount_requested",
            "loan_purpose","app_sessions_30d","form_completion_seconds",
        ]}
        raw["transactions"] = txns
        macro = get_macro_context(row.get("application_date"), macro_df)
        X_row, feat_names = enc.encode(raw, macro)
        rows.append(X_row[0])
        labels.append(int(row["defaulted_12m"]))

    X = np.array(rows, dtype=np.float32)
    y = np.array(labels, dtype=np.float32)
    logger.info(f"Features: {X.shape}, default rate: {y.mean():.3f}")
    return X, y, feat_names


def oversample(X, y, seed=42):
    try:
        from imblearn.over_sampling import SMOTE
        X_r, y_r = SMOTE(random_state=seed).fit_resample(X, y)
        logger.info(f"SMOTE: {X_r.shape}")
        return X_r.astype(np.float32), y_r.astype(np.float32)
    except ImportError:
        logger.warning("imbalanced-learn not installed. Skipping SMOTE.")
        return X, y


def discover_causal(X, feature_names, output_dir):
    logger.info("Causal discovery...")
    try:
        from causallearn.search.ConstraintBased.PC import pc
        from causallearn.utils.cit import fisherz
        idx = np.random.choice(len(X), min(5000, len(X)), replace=False)
        cg = pc(X[idx], alpha=0.05, indep_test=fisherz, show_progress=False)
        edges = []
        for i, j in zip(*np.where(cg.G.graph != 0)):
            if i < j < len(feature_names):
                edges.append({"cause": feature_names[i], "effect": feature_names[j],
                              "strength": float(abs(np.corrcoef(X[:,i], X[:,j])[0,1]))})
        logger.info(f"Found {len(edges)} causal edges")
    except ImportError:
        edges = []
        logger.warning("causal-learn not installed. Using expert priors only.")

    granger = {feature_names[i]: round(abs(float(np.corrcoef(X[:-1,i], X[1:,-1])[0,1])), 4)
               for i in range(min(50, len(feature_names))) if len(X) > 10}

    from ai.config.causal_graph import CREDIT_CAUSAL_PRIORS
    with open(f"{output_dir}/causal_graph.json", "w") as f:
        json.dump({"priors": CREDIT_CAUSAL_PRIORS, "learned_edges": edges, "granger_weights": granger}, f, indent=2)
    logger.info(f"Saved causal graph")


def train_ensemble(X_tr, y_tr, X_val, y_val, output_dir, epochs=100):
    import xgboost as xgb
    import lightgbm as lgb
    import torch, torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
    from sklearn.linear_model import LogisticRegression

    # ── XGBoost
    logger.info("Training XGBoost...")
    xgb_m = xgb.XGBClassifier(n_estimators=500, max_depth=6, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, eval_metric="auc", early_stopping_rounds=30,
        scale_pos_weight=float((y_tr==0).sum()/max(1,(y_tr==1).sum())), random_state=42, tree_method="hist")
    xgb_m.fit(X_tr, y_tr, eval_set=[(X_val, y_val)], verbose=False)

    # ── LightGBM
    logger.info("Training LightGBM...")
    lgb_m = lgb.LGBMClassifier(n_estimators=500, max_depth=8, learning_rate=0.05,
        num_leaves=63, subsample=0.8, colsample_bytree=0.8, class_weight="balanced",
        random_state=42, verbose=-1)
    lgb_m.fit(X_tr, y_tr, eval_set=[(X_val, y_val)], callbacks=[lgb.early_stopping(30, verbose=False)])

    # ── Neural Net with Adversarial Fairness
    logger.info("Training Neural Net + Adversarial Fairness...")

    class CreditNet(nn.Module):
        def __init__(self, d):
            super().__init__()
            self.encoder = nn.Sequential(
                nn.Linear(d, 512), nn.GELU(), nn.BatchNorm1d(512), nn.Dropout(0.3),
                nn.Linear(512, 256), nn.GELU(), nn.BatchNorm1d(256), nn.Dropout(0.2),
                nn.Linear(256, 128), nn.GELU(), nn.Dropout(0.1),
            )
            self.head = nn.Linear(128, 1)
        def forward(self, x):
            emb = self.encoder(x)
            return torch.sigmoid(self.head(emb)).squeeze(1), emb

    class Adversary(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(nn.Linear(129, 64), nn.ReLU(), nn.Dropout(0.3), nn.Linear(64, 8))
        def forward(self, emb, prob):
            return self.net(torch.cat([emb, prob.unsqueeze(1)], dim=1))

    net = CreditNet(X_tr.shape[1])
    adv = Adversary()
    pos_w = torch.tensor([(y_tr==0).sum()/max(1,(y_tr==1).sum())])
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_w)
    opt_main = torch.optim.AdamW(net.parameters(), lr=1e-3, weight_decay=1e-4)
    opt_adv  = torch.optim.Adam(adv.parameters(), lr=2e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt_main, T_max=epochs)

    ds = TensorDataset(torch.from_numpy(X_tr), torch.from_numpy(y_tr))
    loader = DataLoader(ds, batch_size=256, shuffle=True)

    best_loss, patience = float("inf"), 0
    for epoch in range(epochs):
        net.train(); adv.train()
        for Xb, yb in loader:
            # Adversary step
            with torch.no_grad():
                prob, emb = net(Xb)
            adv_logits = adv(emb, prob)
            adv_loss = nn.CrossEntropyLoss()(adv_logits, torch.zeros(len(Xb), dtype=torch.long))
            opt_adv.zero_grad(); adv_loss.backward(); opt_adv.step()

            # Main model step (credit loss - fairness penalty)
            prob, emb = net(Xb)
            logits = net.head(emb).squeeze(1)
            credit_loss = criterion(logits, yb)
            adv_logits = adv(emb, prob)
            fairness_penalty = -nn.CrossEntropyLoss()(adv_logits, torch.zeros(len(Xb), dtype=torch.long))
            total = credit_loss + 0.5 * fairness_penalty
            opt_main.zero_grad(); total.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt_main.step()
        sched.step()

        net.eval()
        with torch.no_grad():
            vp, _ = net(torch.from_numpy(X_val))
            val_loss = float(((vp.numpy() - y_val)**2).mean())
        if val_loss < best_loss:
            best_loss = val_loss; patience = 0
            torch.save(net.state_dict(), f"{output_dir}/neural_best.pt")
        else:
            patience += 1
            if patience > 15: logger.info(f"Early stop epoch {epoch}"); break

    net.load_state_dict(torch.load(f"{output_dir}/neural_best.pt"))
    torch.save(adv.state_dict(), f"{output_dir}/adversary.pt")

    # ── Meta-learner
    net.eval()
    with torch.no_grad():
        vp_xgb = xgb_m.predict_proba(X_val)[:,1]
        vp_lgb = lgb_m.predict_proba(X_val)[:,1]
        vp_nn, _ = net(torch.from_numpy(X_val))
        vp_nn = vp_nn.numpy()
    meta_X = np.column_stack([vp_xgb, vp_lgb, vp_nn])
    meta = LogisticRegression(C=1.0, random_state=42).fit(meta_X, y_val)
    weights = meta.coef_[0].tolist()
    logger.info(f"Meta weights XGB={weights[0]:.3f} LGB={weights[1]:.3f} NN={weights[2]:.3f}")

    return {"xgb": xgb_m, "lgb": lgb_m, "net": net, "meta": meta, "weights": weights}


def export_onnx(models, X_sample, output_dir):
    import torch
    logger.info("Exporting to ONNX...")
    net = models["net"]; net.eval()
    dummy = torch.from_numpy(X_sample[:1]).float()

    class NetWrapper(torch.nn.Module):
        def __init__(self, m): super().__init__(); self.m = m
        def forward(self, x):
            prob, _ = self.m(x)
            return prob

    torch.onnx.export(NetWrapper(net), dummy, f"{output_dir}/oracle_ensemble.onnx",
        export_params=True, opset_version=17, do_constant_folding=True,
        input_names=["input"], output_names=["output"],
        dynamic_axes={"input": {0: "batch_size"}, "output": {0: "batch_size"}})

    models["xgb"].save_model(f"{output_dir}/xgb_model.json")
    models["lgb"].booster_.save_model(f"{output_dir}/lgb_model.txt")
    with open(f"{output_dir}/meta_weights.json","w") as f:
        json.dump({"weights": models["weights"]}, f)
    logger.info("ONNX export complete")


def run_evaluation(models, X_test, y_test) -> dict:
    import torch
    from sklearn.metrics import roc_auc_score, brier_score_loss
    from sklearn.calibration import calibration_curve

    models["net"].eval()
    with torch.no_grad():
        pp_xgb = models["xgb"].predict_proba(X_test)[:,1]
        pp_lgb = models["lgb"].predict_proba(X_test)[:,1]
        pp_nn, _ = models["net"](torch.from_numpy(X_test))
        pp_nn = pp_nn.numpy()

    w = models["weights"]
    pp = np.clip((w[0]*pp_xgb + w[1]*pp_lgb + w[2]*pp_nn) / sum(w), 0, 1)

    auc = roc_auc_score(y_test, pp)
    brier = brier_score_loss(y_test, pp)
    frac_pos, mean_pred = calibration_curve(y_test, pp, n_bins=10)
    ace = float(np.mean(np.abs(frac_pos - mean_pred)))

    metrics = {"auc_roc": round(float(auc), 4), "brier_score": round(float(brier), 4),
               "avg_calibration_error": round(ace, 4), "n_test": len(y_test),
               "default_rate": round(float(y_test.mean()), 4), "model_version": "oracle-v1.0.0"}
    logger.info(f"AUC={metrics['auc_roc']} Brier={metrics['brier_score']} ACE={metrics['avg_calibration_error']}")
    return metrics


def main():
    args = get_args()
    np.random.seed(args.seed)
    os.makedirs(args.output, exist_ok=True)
    t0 = time.time()
    logger.info("ORACLE Training Pipeline Starting")

    data = load_data(args.data, args.macro_data)
    X_tr, y_tr, feat_names = df_to_features(data["df_train"], data["macro_df"])
    X_cal, y_cal, _         = df_to_features(data["df_calib"], data["macro_df"])
    X_te, y_te, _           = df_to_features(data["df_test"],  data["macro_df"])

    with open(f"{args.output}/feature_names.json","w") as f: json.dump(feat_names, f)
    with open(f"{args.output}/scaler_params.json","w") as f:
        json.dump({"mean": X_tr.mean(0).tolist(), "std": X_tr.std(0).tolist()}, f)

    X_tr_bal, y_tr_bal = oversample(X_tr, y_tr, args.seed)

    if not args.skip_causal:
        discover_causal(X_tr, feat_names, args.output)

    models = train_ensemble(X_tr_bal, y_tr_bal, X_cal, y_cal, args.output, args.epochs)

    # Conformal calibration
    import torch
    from ai.config.counterfactual import ConformalPredictor
    models["net"].eval()
    with torch.no_grad():
        cp, _ = models["net"](torch.from_numpy(X_cal))
    conformal = ConformalPredictor.calibrate(cp.numpy(), y_cal)
    conformal.save(f"{args.output}/conformal_calibration.pkl")

    # Risk classifier
    from sklearn.ensemble import RandomForestClassifier
    risk_labels = np.zeros(len(y_tr), dtype=int)
    risk_labels[X_tr[:,2] > 0.6] = 0  # liquidity proxy
    risk_labels[X_tr[:,0] > 0.7] = 3  # structural proxy
    rf = RandomForestClassifier(100, random_state=args.seed).fit(X_tr, risk_labels)
    with open(f"{args.output}/risk_classifier.pkl","wb") as f: pickle.dump(rf, f)

    export_onnx(models, X_tr, args.output)
    metrics = run_evaluation(models, X_te, y_te)
    metrics["training_seconds"] = round(time.time()-t0, 1)

    with open("AI_EVALUATION_REPORT.json","w") as f: json.dump(metrics, f, indent=2)
    logger.info(f"Done in {metrics['training_seconds']}s. Models → {args.output}")


if __name__ == "__main__":
    main()
