# ORACLE — Credit Intelligence Model
## Embedded in credit-ai.com

**ORACLE** (Omni-modal Reasoning & Causal Learning Engine) is the ML backbone of credit-ai.com.

---

## What Makes ORACLE Different

| Capability | Standard Credit Model | ORACLE |
|---|---|---|
| Prediction basis | Correlation in data | **Causal graph reasoning** |
| Explainability | SHAP values | **Counterfactual narratives** |
| Retraining | Batch every 3-6 months | **Continual online learning (EWC)** |
| Macro sensitivity | Static | **Real-time macro conditioning** |
| Fairness | Post-hoc audit | **Adversarial training** |
| Uncertainty | Single score | **95% conformal intervals** |
| Text understanding | None | **Transaction NLP (FinBERT)** |
| Future projection | None | **3/6/12 month trajectory** |
| Inference speed | 200-2000ms | **< 80ms (ONNX at edge)** |

---

## Quick Start

### 1. Clone & install
```bash
git clone https://github.com/sevillanosebastianof28-hub/creditaioi.git
cd creditaioi
pip install -r requirements.txt
npm install
```

### 2. Copy environment
```bash
cp .env.example .env
# Fill in your Supabase URL, anon key, and service role key
```

### 3. Run database migration
```bash
supabase db push
```

### 4. Train the model (on synthetic data if no real data yet)
```bash
python scripts/train_oracle.py
```

### 5. Export to ONNX
```bash
python scripts/export_onnx.py
```

### 6. Deploy edge functions
```bash
supabase secrets set ANTHROPIC_API_KEY=your_key_here
supabase secrets set CLAUDE_MODEL=claude-haiku-4-5-20251001
supabase functions deploy oracle-score
supabase functions deploy ai-health
supabase functions deploy claude-chat
```

### 7. Start frontend
```bash
npm run dev
```

---

## Repository Structure

```
oracle/                    ← Python ML package
  __init__.py
  model.py                 ← Main OracleModel class
  features.py              ← 512-dim feature engineering
  causal_graph.py          ← Neural Granger + SCM
  fairness.py              ← Adversarial debiasing + ECOA
  explainer.py             ← Counterfactual + narrative
  uncertainty.py           ← Conformal prediction
  trainer.py               ← Multi-objective training
  export.py                ← ONNX export

scripts/
  train_oracle.py          ← Training entrypoint
  export_onnx.py           ← ONNX export script
  evaluate_fairness.py     ← Fairness evaluation

models/                    ← Trained model artifacts
  oracle_ensemble.onnx     ← Main inference model
  causal_graph.json        ← SCM structure
  conformal_calibration.pkl
  fairness_adversary.pkl
  feature_pipeline.pkl
  version.txt

supabase/
  functions/
    oracle-score/          ← Scoring edge function
    ai-health/             ← Health check
    claude-chat/           ← Claude AI assistant
  migrations/
    ..._oracle_schema.sql  ← Full DB schema

src/
  hooks/useOracleScore.ts  ← React hook (submit + realtime)
  services/featureBuilder.ts  ← Feature vector builder
  components/OracleScoreCard.tsx  ← Score display UI
```

---

## Required GitHub Secrets

Set these in your repo: Settings → Secrets → Actions

| Secret | Description |
|---|---|
| `SUPABASE_URL` | Your Supabase project URL |
| `SUPABASE_ANON_KEY` | Supabase anon/public key |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase service role key (edge functions) |
| `SUPABASE_ACCESS_TOKEN` | Supabase CLI token (for CI deploy) |
| `SUPABASE_PROJECT_ID` | Supabase project ref |
| `ANTHROPIC_API_KEY` | From console.anthropic.com (free $10 credit) |

---

## How the Realtime Pipeline Works

```
User submits form
       ↓
buildFeatureVector() → 512 float32 values
       ↓
supabase.functions.invoke('oracle-score')
       ↓
Edge Function: ONNX inference → P(default)
       ↓
INSERT into credit_scores table
       ↓
Supabase Realtime fires WebSocket event
       ↓
useOracleScore hook receives event
       ↓
OracleScoreCard renders score + explanation
       ↓
Claude Haiku generates explanation async
       ↓
UPDATE credit_scores.explanation
       ↓
Realtime UPDATE event → explanation appears
```

Total time from submit → score on screen: **< 1 second**
Total time from submit → explanation: **< 5 seconds**

---

## Model Quality Gates (CI enforced)

| Metric | Minimum | Description |
|---|---|---|
| AUC-ROC | ≥ 0.82 | Discriminative power |
| KS Statistic | ≥ 0.40 | Separation of good/bad |
| Brier Score | ≤ 0.18 | Probability calibration |
| Equal Opp. Diff | ≤ 0.05 | CFPB fairness (per-group) |
| Disparate Impact | ≥ 0.80 | 80% rule compliance |

CI fails and blocks deployment if any gate is breached.

---

## License

MIT — credit-ai.com
