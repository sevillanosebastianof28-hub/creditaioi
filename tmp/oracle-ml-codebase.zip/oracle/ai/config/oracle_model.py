"""
ORACLE — Omni-modal Reasoning & Causal Learning Engine
ai/config/oracle_model.py

Main model class. Orchestrates the full pipeline:
  encoding → causal graph → ensemble scoring →
  fairness check → uncertainty quantification →
  counterfactual generation → trajectory forecast
"""

from __future__ import annotations
import time
import json
import logging
import numpy as np
from dataclasses import dataclass, field, asdict
from typing import Optional

import onnxruntime as ort

from .feature_encoder import FeatureEncoder
from .causal_graph import CausalCreditGraph
from .fairness_layer import AdversarialFairnessLayer
from .uncertainty import ConformalPredictor
from .counterfactual import CounterfactualExplainer
from .risk_classifier import RiskTypeClassifier

logger = logging.getLogger("oracle")


# ─────────────────────────────────────────────────────────────
# OUTPUT DATA CLASS
# ─────────────────────────────────────────────────────────────

@dataclass
class OracleScore:
    """Full ORACLE prediction output. Every field is populated before delivery."""

    # Core score
    score: int                        # 300–850 normalized
    probability: float                # P(default within 12 months)
    confidence_low: float             # 95% conformal interval lower bound
    confidence_high: float            # 95% conformal interval upper bound

    # Risk classification
    risk_type: str                    # "liquidity" | "behavioral" | "systemic" | "low"
    risk_severity: str                # "critical" | "high" | "medium" | "low"

    # Causal attribution
    causal_factors: list[dict]        # [{"factor": str, "direction": str, "weight": float}]
    causal_chain: list[str]           # Human-readable causal chain narrative

    # Counterfactuals
    counterfactuals: list[dict]       # [{"change": str, "new_score": int, "impact": float}]

    # Trajectory forecast
    trajectory: dict                  # {"month_3": {...}, "month_6": {...}, "month_12": {...}}

    # Fairness
    fair: bool                        # Passed adversarial fairness check
    fairness_confidence: float        # How confident the fairness check is (0-1)

    # ECOA-compliant adverse action reasons (if declined)
    adverse_action_reasons: list[str]

    # Explanation (filled async by LLM layer)
    explanation: str
    improvement_plan: str

    # Metadata
    model_version: str
    inference_ms: int
    feature_count: int
    scored_at: str

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


# ─────────────────────────────────────────────────────────────
# MAIN ORACLE MODEL
# ─────────────────────────────────────────────────────────────

class OracleModel:
    """
    ORACLE: Omni-modal Reasoning & Causal Learning Engine

    The first credit intelligence model combining:
    - Temporal causal graph reasoning (Neural Granger + SCM)
    - Behavioral transaction language model (FinBERT variant)
    - Real-time macroeconomic conditioning
    - Adversarial fairness (trained-in, not patched-in)
    - Conformal prediction uncertainty quantification
    - Counterfactual explanation generation
    - 12-month trajectory forecasting
    - Continual online learning (EWC)

    Usage:
        model = OracleModel(model_dir="models/")
        result = model.score(features, macro_context, applicant_id="uuid")
        print(result.score)        # e.g. 724
        print(result.explanation)  # LLM narrative
    """

    MODEL_VERSION = "oracle-v1.0.0"

    def __init__(self, model_dir: str = "models/"):
        self.model_dir = model_dir
        logger.info(f"Loading ORACLE {self.MODEL_VERSION} from {model_dir}")
        t0 = time.time()

        # ── ONNX Ensemble (XGBoost + LightGBM + Neural net fused)
        self.ensemble_session = ort.InferenceSession(
            f"{model_dir}/oracle_ensemble.onnx",
            providers=["CPUExecutionProvider"],
        )
        self.ensemble_input_name = self.ensemble_session.get_inputs()[0].name

        # ── Feature encoder (standardization, embeddings, temporal features)
        self.encoder = FeatureEncoder.load(f"{model_dir}/feature_encoder.pkl")

        # ── Causal graph (SCM + Neural Granger)
        self.causal_graph = CausalCreditGraph.load(f"{model_dir}/causal_graph.json")

        # ── Adversarial fairness layer
        self.fairness = AdversarialFairnessLayer.load(
            f"{model_dir}/fairness_adversary.onnx"
        )

        # ── Conformal predictor (calibrated uncertainty)
        self.conformal = ConformalPredictor.load(
            f"{model_dir}/conformal_calibration.pkl"
        )

        # ── Counterfactual explainer
        self.explainer = CounterfactualExplainer(
            ensemble_session=self.ensemble_session,
            encoder=self.encoder,
            feature_constraints=self._load_feature_constraints(),
        )

        # ── Risk type classifier
        self.risk_classifier = RiskTypeClassifier.load(
            f"{model_dir}/risk_classifier.pkl"
        )

        logger.info(f"ORACLE loaded in {(time.time()-t0)*1000:.0f}ms")

    # ─── PRIMARY SCORING ENTRY POINT ───────────────────────────

    def score(
        self,
        raw_features: dict,
        macro_context: dict,
        applicant_id: str,
        generate_counterfactuals: bool = True,
    ) -> OracleScore:
        """
        Full ORACLE scoring pipeline.

        Args:
            raw_features: Raw applicant feature dict (see FeatureEncoder for schema)
            macro_context: Current macro indicators (fed_rate, cpi, unemployment, etc.)
            applicant_id: UUID string for audit logging
            generate_counterfactuals: Set False for batch scoring to save time

        Returns:
            OracleScore with all fields populated
        """
        t_start = time.time()

        # ── 1. Encode features ──────────────────────────────────
        X, feature_names = self.encoder.encode(raw_features, macro_context)
        # X shape: (1, n_features) float32 numpy array

        # ── 2. Ensemble prediction ──────────────────────────────
        ort_input = {self.ensemble_input_name: X.astype(np.float32)}
        raw_output = self.ensemble_session.run(None, ort_input)
        probability = float(np.clip(raw_output[0][0], 0.001, 0.999))

        # ── 3. Conformal uncertainty interval ───────────────────
        low, high = self.conformal.predict_interval(X, alpha=0.05)
        score_val = self._prob_to_score(probability)
        score_low = self._prob_to_score(float(high))   # high prob → low score
        score_high = self._prob_to_score(float(low))

        # ── 4. Causal attribution ────────────────────────────────
        causal_factors = self.causal_graph.attribute(
            X, feature_names, probability
        )
        causal_chain = self.causal_graph.explain_chain(causal_factors)

        # ── 5. Risk type classification ──────────────────────────
        risk_type, risk_severity = self.risk_classifier.classify(
            X, causal_factors, probability
        )

        # ── 6. Adversarial fairness check ────────────────────────
        fair, fairness_confidence = self.fairness.check(X, probability)

        # ── 7. Counterfactuals ───────────────────────────────────
        counterfactuals = []
        if generate_counterfactuals:
            counterfactuals = self.explainer.generate(
                X, feature_names, raw_features, probability, n=4
            )

        # ── 8. Trajectory forecast ───────────────────────────────
        trajectory = self.causal_graph.forecast_trajectory(
            X, feature_names, horizons=[3, 6, 12]
        )

        # ── 9. ECOA adverse action reasons ───────────────────────
        adverse_reasons = []
        if probability > 0.35:
            adverse_reasons = self.fairness.ecoa_reasons(
                causal_factors, counterfactuals
            )

        inference_ms = int((time.time() - t_start) * 1000)

        return OracleScore(
            score=score_val,
            probability=probability,
            confidence_low=score_low,
            confidence_high=score_high,
            risk_type=risk_type,
            risk_severity=risk_severity,
            causal_factors=causal_factors,
            causal_chain=causal_chain,
            counterfactuals=counterfactuals,
            trajectory=trajectory,
            fair=fair,
            fairness_confidence=fairness_confidence,
            adverse_action_reasons=adverse_reasons,
            explanation="",       # filled async by LLM edge function
            improvement_plan="",  # filled async by LLM edge function
            model_version=self.MODEL_VERSION,
            inference_ms=inference_ms,
            feature_count=X.shape[1],
            scored_at=self._now_iso(),
        )

    # ─── BATCH SCORING ──────────────────────────────────────────

    def score_batch(
        self,
        batch: list[dict],
        macro_context: dict,
    ) -> list[OracleScore]:
        """Score a batch of applicants. Skips counterfactuals for speed."""
        results = []
        for item in batch:
            try:
                r = self.score(
                    item["features"],
                    macro_context,
                    item["applicant_id"],
                    generate_counterfactuals=False,
                )
                results.append(r)
            except Exception as e:
                logger.error(f"Batch score error for {item.get('applicant_id')}: {e}")
        return results

    # ─── ONLINE LEARNING ────────────────────────────────────────

    def update_online(self, outcome: dict) -> None:
        """
        Elastic Weight Consolidation online update.
        Called when a loan outcome is known (paid off or defaulted).
        Updates the model without catastrophic forgetting of old patterns.

        Args:
            outcome: {"applicant_id": str, "defaulted": bool, "features": dict}
        """
        logger.info(f"Online update for {outcome['applicant_id']}")
        # EWC update — implemented in scripts/online_learner.py
        # Here we just log for async processing
        self._queue_online_update(outcome)

    # ─── HELPERS ────────────────────────────────────────────────

    def _prob_to_score(self, prob: float) -> int:
        """Map default probability to 300–850 score range (inverse)."""
        # logit-linear mapping calibrated on bureau score distributions
        log_odds = np.log(prob / (1 - prob + 1e-9))
        # Calibrated to match bureau score statistics
        raw = 580 - (log_odds * 80)
        return int(np.clip(raw, 300, 850))

    def _load_feature_constraints(self) -> dict:
        """Load which features can be changed in counterfactuals (vs. immutable)."""
        with open(f"{self.model_dir}/feature_constraints.json") as f:
            return json.load(f)

    def _queue_online_update(self, outcome: dict) -> None:
        """Write outcome to Supabase for async EWC processing."""
        import os, json
        # In production: write to supabase via service role key
        # Here: write to local queue file for the EWC worker to pick up
        queue_path = f"{self.model_dir}/online_queue.jsonl"
        with open(queue_path, "a") as f:
            f.write(json.dumps(outcome) + "\n")

    @staticmethod
    def _now_iso() -> str:
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).isoformat()


# ─────────────────────────────────────────────────────────────
# SINGLETON LOADER (for edge function warm start)
# ─────────────────────────────────────────────────────────────

_oracle_instance: Optional[OracleModel] = None


def get_oracle(model_dir: str = "models/") -> OracleModel:
    """
    Returns singleton OracleModel. Safe to call on every request.
    First call loads all models into memory (~500ms).
    Subsequent calls return cached instance (<1ms).
    """
    global _oracle_instance
    if _oracle_instance is None:
        _oracle_instance = OracleModel(model_dir=model_dir)
    return _oracle_instance
