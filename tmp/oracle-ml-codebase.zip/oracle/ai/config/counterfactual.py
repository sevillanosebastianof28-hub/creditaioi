"""
ORACLE Counterfactual Explainer + Conformal Uncertainty
ai/config/counterfactual.py + ai/config/uncertainty.py
"""

from __future__ import annotations
import pickle
import numpy as np
import onnxruntime as ort
from typing import Optional
import logging

logger = logging.getLogger("oracle.explain")


# ─────────────────────────────────────────────────────────────
# COUNTERFACTUAL EXPLAINER
# ─────────────────────────────────────────────────────────────

# Features that CAN be changed (actionable counterfactuals)
MUTABLE_FEATURES = {
    "revolving_utilization":        {"min": 0.0, "max": 1.0, "preferred": 0.3,  "display": "credit card utilization"},
    "missed_payments_12m":          {"min": 0.0, "max": 1.0, "preferred": 0.0,  "display": "missed payments"},
    "inquiries_6m":                 {"min": 0.0, "max": 1.0, "preferred": 0.0,  "display": "new credit applications"},
    "gambling_amount_90d":          {"min": 0.0, "max": 1.0, "preferred": 0.0,  "display": "gambling spending"},
    "atm_frequency_30d":            {"min": 0.0, "max": 1.0, "preferred": 0.0,  "display": "cash withdrawal frequency"},
    "dti_ratio":                    {"min": 0.0, "max": 2.0, "preferred": 0.36, "display": "debt-to-income ratio"},
    "loan_payment_regularity":      {"min": 0.0, "max": 1.0, "preferred": 1.0,  "display": "on-time loan payments"},
    "income_norm":                  {"min": 0.0, "max": 1.0, "preferred": None, "display": "monthly income"},
    "spend_velocity_change_30_60":  {"min": 0.0, "max": 3.0, "preferred": 1.0, "display": "spending rate"},
    "active_subscriptions":         {"min": 0.0, "max": 1.0, "preferred": 0.3, "display": "subscription services"},
}

# Features that CANNOT be changed (immutable — don't suggest these)
IMMUTABLE_FEATURES = {
    "oldest_account_months_norm",
    "avg_account_age_months_norm",
    "employment_months_norm",
    "macro_fed_rate", "macro_cpi", "macro_unemployment",
    "macro_credit_spread", "macro_sector_stress",
}

# Human-readable counterfactual templates
CF_TEMPLATES = {
    "revolving_utilization":   "Pay down credit card balances to below {target}% utilization",
    "missed_payments_12m":     "Bring all accounts current and maintain {target} missed payments",
    "inquiries_6m":            "Avoid applying for new credit for the next 6 months",
    "gambling_amount_90d":     "Reduce or eliminate gambling transactions",
    "atm_frequency_30d":       "Reduce cash withdrawals and use card payments instead",
    "dti_ratio":               "Pay down debts to bring debt-to-income ratio below {target}%",
    "loan_payment_regularity": "Set up autopay to achieve consistent on-time payments",
    "income_norm":             "Increase or verify monthly income above ${target}",
    "spend_velocity_change_30_60": "Stabilize monthly spending levels",
    "active_subscriptions":    "Reduce recurring subscription services",
}


class CounterfactualExplainer:
    """
    Generates actionable counterfactual explanations.
    "The minimal change to your application that would result in approval."

    Algorithm: Greedy feature perturbation guided by causal ordering.
    For each mutable feature, compute score improvement per unit change.
    Select top-k highest-impact, lowest-effort changes.
    """

    def __init__(
        self,
        ensemble_session: ort.InferenceSession,
        encoder,
        feature_constraints: dict,
    ):
        self.session = ensemble_session
        self.encoder = encoder
        self.feature_constraints = feature_constraints
        self.input_name = ensemble_session.get_inputs()[0].name

    def generate(
        self,
        X: np.ndarray,
        feature_names: list[str],
        raw_features: dict,
        original_prob: float,
        n: int = 4,
    ) -> list[dict]:
        """
        Generate n actionable counterfactuals.
        Each counterfactual shows: what to change, by how much, and the new score.
        """
        counterfactuals = []
        feature_idx = {name: i for i, name in enumerate(feature_names)}

        for feature, config in MUTABLE_FEATURES.items():
            if feature in IMMUTABLE_FEATURES:
                continue
            if feature not in feature_idx:
                continue

            idx = feature_idx[feature]
            current_val = float(X[0, idx])
            preferred_val = config.get("preferred")

            if preferred_val is None:
                continue

            # Skip if already at preferred value
            if abs(current_val - preferred_val) < 0.02:
                continue

            # Compute score impact of moving to preferred value
            X_cf = X.copy()
            X_cf[0, idx] = preferred_val

            try:
                output = self.session.run(None, {self.input_name: X_cf.astype(np.float32)})
                cf_prob = float(np.clip(output[0][0], 0.001, 0.999))
            except Exception as e:
                logger.error(f"Counterfactual inference error: {e}")
                continue

            prob_delta = original_prob - cf_prob  # positive = improvement
            if prob_delta < 0.02:
                continue  # Less than 2% improvement — not worth showing

            # Convert to score delta
            orig_score = int(np.clip(580 - (np.log(original_prob/(1-original_prob+1e-9)) * 80), 300, 850))
            cf_score = int(np.clip(580 - (np.log(cf_prob/(1-cf_prob+1e-9)) * 80), 300, 850))
            score_delta = cf_score - orig_score

            # Format human-readable description
            description = self._format_description(
                feature, current_val, preferred_val, raw_features, config
            )

            counterfactuals.append({
                "feature": feature,
                "description": description,
                "current_value": round(current_val, 4),
                "target_value": round(preferred_val, 4),
                "new_score": cf_score,
                "score_improvement": score_delta,
                "probability_reduction": round(prob_delta, 4),
                "effort": self._estimate_effort(feature, current_val, preferred_val),
            })

        # Sort by score improvement, return top n
        counterfactuals.sort(key=lambda x: x["score_improvement"], reverse=True)
        return counterfactuals[:n]

    def _format_description(
        self, feature: str, current: float, target: float, raw: dict, config: dict
    ) -> str:
        template = CF_TEMPLATES.get(feature, f"Improve your {config.get('display', feature)}")
        # Format target values for display
        if feature == "revolving_utilization":
            target_pct = int(target * 100)
            return template.format(target=target_pct)
        elif feature == "dti_ratio":
            target_pct = int(target * 100)
            return template.format(target=target_pct)
        elif feature == "income_norm":
            target_income = int(target * 50000)
            return template.format(target=f"{target_income:,}")
        elif feature == "missed_payments_12m":
            return template.format(target=0)
        return template.format(target=round(target, 2)) if "{target}" in template else template

    def _estimate_effort(self, feature: str, current: float, target: float) -> str:
        """Classify how hard this counterfactual is to achieve."""
        effort_levels = {
            "gambling_amount_90d": "medium",
            "inquiries_6m": "easy",
            "loan_payment_regularity": "easy",
            "spend_velocity_change_30_60": "easy",
            "active_subscriptions": "easy",
            "revolving_utilization": "medium",
            "atm_frequency_30d": "medium",
            "dti_ratio": "hard",
            "income_norm": "hard",
            "missed_payments_12m": "medium",
        }
        return effort_levels.get(feature, "medium")


# ─────────────────────────────────────────────────────────────
# CONFORMAL PREDICTOR (Uncertainty Quantification)
# ─────────────────────────────────────────────────────────────

class ConformalPredictor:
    """
    Inductive Conformal Prediction for calibrated uncertainty intervals.
    Every ORACLE score comes with a statistically valid confidence interval.

    Training: calibrate on held-out calibration set using nonconformity scores.
    Inference: compute prediction interval at target coverage (1-alpha).

    Example output:
        score: 720, interval: [695, 742] at 95% confidence
    This means: there is a 95% probability the true risk falls in this range.
    """

    def __init__(self, nonconformity_scores: np.ndarray, alpha_grid: dict):
        """
        nonconformity_scores: calibration set |predicted_prob - actual_prob|
        alpha_grid: precomputed quantile thresholds {alpha: quantile}
        """
        self.nonconformity_scores = nonconformity_scores
        self.alpha_grid = alpha_grid

    @classmethod
    def load(cls, path: str) -> "ConformalPredictor":
        with open(path, "rb") as f:
            state = pickle.load(f)
        return cls(
            nonconformity_scores=state["nonconformity_scores"],
            alpha_grid=state["alpha_grid"],
        )

    def save(self, path: str) -> None:
        with open(path, "wb") as f:
            pickle.dump({
                "nonconformity_scores": self.nonconformity_scores,
                "alpha_grid": self.alpha_grid,
            }, f)

    def predict_interval(
        self,
        X: np.ndarray,
        alpha: float = 0.05,
    ) -> tuple[float, float]:
        """
        Returns (lower_prob, upper_prob) — calibrated probability interval.
        alpha=0.05 → 95% coverage guarantee on calibration distribution.
        """
        # Get precomputed quantile for this alpha level
        quantile = self.alpha_grid.get(str(alpha), self._compute_quantile(alpha))
        return max(0.0, quantile[0]), min(1.0, quantile[1])

    def _compute_quantile(self, alpha: float) -> tuple[float, float]:
        """Compute conformal quantile from nonconformity scores."""
        n = len(self.nonconformity_scores)
        threshold = np.quantile(
            self.nonconformity_scores,
            np.ceil((n + 1) * (1 - alpha)) / n
        )
        # Return symmetric interval around median score
        median_score = np.median(self.nonconformity_scores)
        return (median_score - threshold, median_score + threshold)

    @classmethod
    def calibrate(
        cls,
        predicted_probs: np.ndarray,
        true_labels: np.ndarray,
        alpha_levels: list[float] = [0.01, 0.05, 0.10, 0.20],
    ) -> "ConformalPredictor":
        """
        Calibrate conformal predictor on held-out calibration set.
        Call this during training (scripts/train_oracle.py).
        """
        nonconformity = np.abs(predicted_probs - true_labels)
        alpha_grid = {}
        n = len(nonconformity)

        for alpha in alpha_levels:
            threshold = float(np.quantile(
                nonconformity,
                np.ceil((n + 1) * (1 - alpha)) / n
            ))
            median = float(np.median(predicted_probs))
            alpha_grid[str(alpha)] = (
                max(0.0, median - threshold),
                min(1.0, median + threshold),
            )

        return cls(nonconformity_scores=nonconformity, alpha_grid=alpha_grid)


# ─────────────────────────────────────────────────────────────
# RISK TYPE CLASSIFIER
# ─────────────────────────────────────────────────────────────

class RiskTypeClassifier:
    """
    Classifies the TYPE of credit risk, not just the probability.
    This enables different interventions for different risk profiles.

    Risk types:
    - "liquidity": short-term cash flow problems (temporary, recoverable)
    - "behavioral": spending/lifestyle patterns that drive chronic stress
    - "systemic": macroeconomic / industry forces (external to applicant)
    - "structural": deep credit damage (derogatory marks, long-term history)
    - "low": minimal risk, no significant drivers
    """

    RISK_TYPES = ["liquidity", "behavioral", "systemic", "structural", "low"]

    def __init__(self, classifier):
        self.classifier = classifier

    @classmethod
    def load(cls, path: str) -> "RiskTypeClassifier":
        with open(path, "rb") as f:
            clf = pickle.load(f)
        return cls(classifier=clf)

    def classify(
        self,
        X: np.ndarray,
        causal_factors: list[dict],
        probability: float,
    ) -> tuple[str, str]:
        """Returns (risk_type, risk_severity)."""
        if probability < 0.15:
            return "low", "low"

        # Severity
        if probability > 0.65:
            severity = "critical"
        elif probability > 0.40:
            severity = "high"
        elif probability > 0.25:
            severity = "medium"
        else:
            severity = "low"

        # Type: derive from dominant causal factors
        factor_features = {f["feature"] for f in causal_factors}

        liquidity_features = {"cash_flow_stress_ratio", "atm_frequency_30d", "monthly_deficit_count", "eom_small_txns"}
        behavioral_features = {"gambling_amount_90d", "night_spend_ratio", "spend_velocity_change_30_60", "merchant_entropy"}
        systemic_features = {"macro_sector_stress", "macro_credit_spread", "macro_unemployment"}
        structural_features = {"derogatory_marks", "missed_payments_12m", "missed_payments_24m", "oldest_account_months_norm"}

        scores = {
            "liquidity": len(factor_features & liquidity_features),
            "behavioral": len(factor_features & behavioral_features),
            "systemic": len(factor_features & systemic_features),
            "structural": len(factor_features & structural_features),
        }

        risk_type = max(scores, key=lambda k: scores[k])
        if scores[risk_type] == 0:
            risk_type = "structural"  # default

        return risk_type, severity
