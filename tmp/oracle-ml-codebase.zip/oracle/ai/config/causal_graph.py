"""
ORACLE Causal Credit Graph
ai/config/causal_graph.py

Combines:
  - Neural Granger Causality (learned from data)
  - Structural Causal Model (expert-defined financial domain knowledge)
  - Trajectory forecasting (simulate 3/6/12 months forward)
  - Intervention simulation (what-if counterfactuals)

This is the core innovation: credit scoring through causal reasoning,
not correlation. We know WHY someone is a credit risk, not just THAT they are.
"""

from __future__ import annotations
import json
import numpy as np
from dataclasses import dataclass
from typing import Optional
import logging

logger = logging.getLogger("oracle.causal")


# ─────────────────────────────────────────────────────────────
# CAUSAL GRAPH STRUCTURE
# ─────────────────────────────────────────────────────────────

# Expert-defined causal DAG for credit risk
# Format: (cause, effect, direction, strength)
# direction: "increases_risk" | "decreases_risk"
CREDIT_CAUSAL_PRIORS = [
    # Income shocks → spending behavior → credit stress
    ("income_stability",        "cash_flow_stress_ratio",   "decreases_risk",  0.82),
    ("income_norm",             "revolving_utilization",    "decreases_risk",  0.71),
    ("income_norm",             "dti_ratio",                "decreases_risk",  0.78),
    ("employment_months_norm",  "income_stability",         "decreases_risk",  0.65),

    # Credit behavior → score
    ("revolving_utilization",   "missed_payments_12m",      "increases_risk",  0.69),
    ("missed_payments_12m",     "derogatory_marks",         "increases_risk",  0.85),
    ("derogatory_marks",        "probability",              "increases_risk",  0.91),
    ("revolving_utilization",   "probability",              "increases_risk",  0.74),

    # Spending behavior → financial stress
    ("gambling_amount_90d",     "cash_flow_stress_ratio",   "increases_risk",  0.61),
    ("atm_frequency_30d",       "cash_flow_stress_ratio",   "increases_risk",  0.54),
    ("spend_velocity_change_30_60", "cash_flow_stress_ratio", "increases_risk", 0.48),
    ("cash_flow_stress_ratio",  "missed_payments_12m",      "increases_risk",  0.77),

    # Positive signals → lower risk
    ("merchant_entropy",        "income_stability",         "decreases_risk",  0.42),
    ("loan_payment_regularity", "probability",              "decreases_risk",  0.68),
    ("oldest_account_months_norm", "probability",           "decreases_risk",  0.55),

    # Macro context → individual risk amplification
    ("macro_credit_spread",     "probability",              "increases_risk",  0.38),
    ("macro_unemployment",      "income_stability",         "decreases_risk",  0.35),
    ("macro_sector_stress",     "probability",              "increases_risk",  0.44),

    # Behavioral signals
    ("night_spend_ratio",       "cash_flow_stress_ratio",   "increases_risk",  0.31),
    ("timing_consistency",      "loan_payment_regularity",  "decreases_risk",  0.58),
]

# Human-readable factor names for explanations
FACTOR_DISPLAY_NAMES = {
    "revolving_utilization":     "Credit card utilization",
    "missed_payments_12m":       "Recent missed payments",
    "missed_payments_24m":       "Missed payments (2 years)",
    "derogatory_marks":          "Derogatory marks",
    "inquiries_6m":              "Recent credit inquiries",
    "income_norm":               "Monthly income",
    "income_stability":          "Income stability",
    "cash_flow_stress_ratio":    "Cash flow stress",
    "dti_ratio":                 "Debt-to-income ratio",
    "employment_months_norm":    "Employment tenure",
    "gambling_amount_90d":       "Gambling transactions",
    "atm_frequency_30d":         "Cash withdrawal frequency",
    "merchant_entropy":          "Spending diversity",
    "loan_payment_regularity":   "Loan payment consistency",
    "oldest_account_months_norm": "Credit history length",
    "timing_consistency":        "Transaction timing consistency",
    "spend_velocity_change_30_60": "Recent spending acceleration",
    "macro_sector_stress":       "Industry economic stress",
    "total_accounts_norm":       "Number of credit accounts",
}


@dataclass
class CausalFactor:
    feature: str
    display_name: str
    direction: str          # "increases_risk" | "decreases_risk"
    causal_weight: float    # learned causal strength 0-1
    feature_value: float    # actual value (for display)
    granger_score: float    # data-driven Granger causality score


class CausalCreditGraph:
    """
    Structural Causal Model for credit risk reasoning.
    Combines expert priors with learned Granger causality scores.
    """

    def __init__(self, priors: list, granger_weights: dict):
        self.priors = priors
        self.granger_weights = granger_weights  # {feature: granger_score}
        # Build adjacency: effect → [causes]
        self._effect_map: dict[str, list] = {}
        for cause, effect, direction, strength in priors:
            self._effect_map.setdefault(effect, []).append(
                (cause, direction, strength)
            )

    @classmethod
    def load(cls, path: str) -> "CausalCreditGraph":
        with open(path) as f:
            state = json.load(f)
        return cls(
            priors=state.get("priors", CREDIT_CAUSAL_PRIORS),
            granger_weights=state.get("granger_weights", {}),
        )

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump({
                "priors": self.priors,
                "granger_weights": self.granger_weights,
            }, f, indent=2)

    # ─── CAUSAL ATTRIBUTION ────────────────────────────────────

    def attribute(
        self,
        X: np.ndarray,
        feature_names: list[str],
        probability: float,
    ) -> list[dict]:
        """
        Identify which features causally drive this prediction.
        Returns ranked list of causal factors with weights.
        """
        feature_vals = {name: float(X[0, i]) for i, name in enumerate(feature_names)}

        factors = []
        for cause, effect, direction, prior_strength in self.priors:
            if effect != "probability":
                continue  # Only direct-to-outcome causes for top-level attribution
            if cause not in feature_vals:
                continue

            val = feature_vals[cause]
            granger = self.granger_weights.get(cause, prior_strength * 0.8)

            # Combined causal weight: prior × granger × feature value magnitude
            if direction == "increases_risk":
                impact = val * granger
            else:
                impact = (1.0 - val) * granger

            if impact > 0.05:
                factors.append({
                    "feature": cause,
                    "display_name": FACTOR_DISPLAY_NAMES.get(cause, cause),
                    "direction": direction,
                    "causal_weight": round(float(granger), 3),
                    "impact": round(float(impact), 3),
                    "value": round(float(val), 4),
                })

        # Add indirect causes (2-hop: cause → mediator → probability)
        indirect = self._indirect_attribution(feature_vals)
        factors.extend(indirect)

        # Sort by impact, deduplicate
        seen = set()
        unique = []
        for f in sorted(factors, key=lambda x: x["impact"], reverse=True):
            if f["feature"] not in seen:
                seen.add(f["feature"])
                unique.append(f)

        return unique[:8]  # Top 8 causal factors

    def _indirect_attribution(self, feature_vals: dict) -> list[dict]:
        """Find 2-hop causal paths: feature → mediator → probability."""
        indirect = []
        for cause, mediator, direction_1, strength_1 in self.priors:
            if mediator == "probability":
                continue
            if mediator not in self._effect_map:
                continue
            for cause2, direction_2, strength_2 in self._effect_map.get("probability", []):
                if cause2 != mediator:
                    continue
                if cause not in feature_vals:
                    continue
                val = feature_vals[cause]
                combined_strength = strength_1 * strength_2
                # Determine net direction
                if direction_1 == direction_2:
                    net_direction = direction_1
                else:
                    net_direction = "increases_risk" if direction_2 == "increases_risk" else "decreases_risk"

                impact = (val if net_direction == "increases_risk" else 1 - val) * combined_strength
                if impact > 0.03:
                    indirect.append({
                        "feature": cause,
                        "display_name": FACTOR_DISPLAY_NAMES.get(cause, cause),
                        "direction": net_direction,
                        "causal_weight": round(combined_strength, 3),
                        "impact": round(float(impact), 3),
                        "value": round(float(feature_vals.get(cause, 0)), 4),
                        "path": f"{cause} → {mediator} → risk",
                    })
        return indirect

    # ─── CAUSAL CHAIN NARRATIVE ────────────────────────────────

    def explain_chain(self, factors: list[dict]) -> list[str]:
        """Generate human-readable causal chain sentences."""
        chains = []
        risk_factors = [f for f in factors if f["direction"] == "increases_risk" and f["impact"] > 0.1]
        protective_factors = [f for f in factors if f["direction"] == "decreases_risk" and f["impact"] > 0.1]

        for f in risk_factors[:3]:
            name = f["display_name"]
            if "path" in f:
                mediator = f["path"].split("→")[1].strip()
                mediator_display = FACTOR_DISPLAY_NAMES.get(mediator, mediator)
                chains.append(f"High {name} → elevated {mediator_display} → increased default risk")
            else:
                chains.append(f"High {name} directly increases default probability")

        for f in protective_factors[:2]:
            chains.append(f"Strong {f['display_name']} partially offsets risk")

        return chains

    # ─── TRAJECTORY FORECAST ───────────────────────────────────

    def forecast_trajectory(
        self,
        X: np.ndarray,
        feature_names: list[str],
        horizons: list[int] = [3, 6, 12],
    ) -> dict:
        """
        Simulate future credit score trajectory using the causal model.
        Assumes baseline behavior (no major behavioral changes).
        Returns score estimates at 3, 6, 12 months.
        """
        feature_vals = {name: float(X[0, i]) for i, name in enumerate(feature_names)}
        trajectory = {}

        for h in horizons:
            # Propagate causal model forward h months
            projected = self._propagate_forward(feature_vals, steps=h)
            proj_prob = self._estimate_probability(projected)

            # Convert probability to score
            log_odds = np.log(proj_prob / (1 - proj_prob + 1e-9))
            proj_score = int(np.clip(580 - (log_odds * 80), 300, 850))

            # Identify key drivers of projected change
            current_prob = self._estimate_probability(feature_vals)
            delta_prob = proj_prob - current_prob

            trajectory[f"month_{h}"] = {
                "predicted_score": proj_score,
                "predicted_probability": round(float(proj_prob), 4),
                "change_direction": "improving" if delta_prob < 0 else "worsening",
                "score_delta": proj_score - int(np.clip(580 - (np.log(current_prob/(1-current_prob+1e-9)) * 80), 300, 850)),
                "key_drivers": self._top_drivers(projected, feature_vals, k=3),
            }

        return trajectory

    def _propagate_forward(self, features: dict, steps: int) -> dict:
        """Simulate causal dynamics forward in time."""
        state = features.copy()
        monthly_decay = 0.02  # Missed payments age, utilization drifts

        for _ in range(steps):
            new_state = state.copy()

            # Missed payments naturally age/reduce over time
            new_state["missed_payments_12m"] = max(
                0, state.get("missed_payments_12m", 0) - monthly_decay
            )
            # Utilization follows income stability
            income_effect = state.get("income_stability", 0.5) - 0.5
            new_state["revolving_utilization"] = np.clip(
                state.get("revolving_utilization", 0.5) - income_effect * 0.02, 0, 1
            )
            # Credit history length increases
            new_state["oldest_account_months_norm"] = min(
                1.0, state.get("oldest_account_months_norm", 0) + (1 / 360)
            )
            # Propagate causal effects
            for cause, effect, direction, strength in self.priors:
                if effect not in new_state or cause not in state:
                    continue
                cause_val = state[cause]
                effect_val = new_state[effect]
                if direction == "decreases_risk":
                    delta = cause_val * strength * 0.01
                    new_state[effect] = np.clip(effect_val - delta, 0, 1)
                else:
                    delta = cause_val * strength * 0.01
                    new_state[effect] = np.clip(effect_val + delta, 0, 1)

            state = new_state

        return state

    def _estimate_probability(self, features: dict) -> float:
        """Estimate default probability from feature dict using causal model."""
        prob = 0.15  # base rate
        for cause, effect, direction, strength in self.priors:
            if effect != "probability":
                continue
            val = features.get(cause, 0.0)
            if direction == "increases_risk":
                prob += val * strength * 0.08
            else:
                prob -= val * strength * 0.08
        return float(np.clip(prob, 0.01, 0.99))

    def _top_drivers(self, projected: dict, original: dict, k: int = 3) -> list[str]:
        """Find which features changed most between original and projected state."""
        changes = []
        for key in projected:
            if key in original and key in FACTOR_DISPLAY_NAMES:
                delta = projected[key] - original[key]
                if abs(delta) > 0.01:
                    direction = "improving" if delta < 0 else "worsening"
                    changes.append((abs(delta), FACTOR_DISPLAY_NAMES[key], direction))
        changes.sort(reverse=True)
        return [f"{name} ({direction})" for _, name, direction in changes[:k]]
