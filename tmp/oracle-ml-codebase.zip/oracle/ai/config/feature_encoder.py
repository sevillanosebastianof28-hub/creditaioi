"""
ORACLE Feature Encoder
ai/config/feature_encoder.py

Transforms raw applicant data into 512-dimensional feature vector.
Handles: transaction sequences, bureau data, behavioral signals,
         macro context, merchant NLP embeddings, temporal features.
"""

from __future__ import annotations
import re
import pickle
import hashlib
import numpy as np
from datetime import datetime, timezone
from typing import Optional
import logging

logger = logging.getLogger("oracle.encoder")


# ─────────────────────────────────────────────────────────────
# FEATURE SCHEMA  (what raw_features dict must contain)
# ─────────────────────────────────────────────────────────────

RAW_FEATURE_SCHEMA = {
    # Bureau tradeline data
    "fico_score":              "int|None    — existing bureau score if available",
    "total_accounts":          "int         — number of open tradelines",
    "revolving_utilization":   "float       — 0.0-1.0, revolving balance / limit",
    "missed_payments_12m":     "int         — 30+ day lates in last 12 months",
    "missed_payments_24m":     "int         — 30+ day lates in last 24 months",
    "derogatory_marks":        "int         — collections, charge-offs, public records",
    "inquiries_6m":            "int         — hard inquiries in last 6 months",
    "oldest_account_months":   "int         — age of oldest tradeline in months",
    "avg_account_age_months":  "float       — average age of all tradelines",
    "total_credit_limit":      "float       — sum of all credit limits ($)",
    "total_balance":           "float       — sum of all balances ($)",

    # Income & Employment
    "stated_income":           "float       — monthly gross income ($)",
    "income_verified":         "bool        — whether income was verified",
    "employment_months":       "int         — months at current employer",
    "employment_type":         "str         — 'employed'|'self-employed'|'unemployed'|'retired'",

    # Transaction history (last 12 months)
    "transactions":            "list[dict]  — see transaction schema below",
    # transaction: {"date": "ISO", "amount": float, "merchant": str, "category": str, "type": "debit|credit"}

    # Application
    "loan_amount_requested":   "float       — amount in $ requested",
    "loan_purpose":            "str         — 'auto'|'home'|'personal'|'business'|'education'|'debt_consolidation'",
    "stated_purpose_text":     "str|None    — free text purpose (NLP processed)",

    # Behavioral (from app usage, optional)
    "app_sessions_30d":        "int|None    — number of logins in 30 days",
    "form_completion_seconds":  "int|None   — time to complete application form",
}

MACRO_SCHEMA = {
    "fed_funds_rate":   "float — current federal funds rate",
    "cpi_yoy":          "float — CPI year-over-year % change",
    "unemployment_rate": "float — national unemployment %",
    "credit_spread":    "float — IG corporate spread bps",
    "hpi_yoy":          "float — home price index YoY change",
    "sector_stress":    "float — 0-1, stressed sector indicator for applicant's employment",
}

MERCHANT_CATEGORY_CODES = {
    "groceries": 0, "restaurants": 1, "fast_food": 2, "alcohol": 3,
    "entertainment": 4, "gambling": 5, "rideshare": 6, "gas": 7,
    "utilities": 8, "rent": 9, "mortgage": 10, "medical": 11,
    "education": 12, "insurance": 13, "subscriptions": 14, "travel": 15,
    "clothing": 16, "electronics": 17, "atm_cash": 18, "transfer": 19,
    "income": 20, "loan_payment": 21, "investment": 22, "other": 23,
}

EMPLOYMENT_TYPES = {"employed": 0, "self-employed": 1, "unemployed": 2, "retired": 3}
LOAN_PURPOSES = {"auto": 0, "home": 1, "personal": 2, "business": 3, "education": 4, "debt_consolidation": 5}


# ─────────────────────────────────────────────────────────────
# TRANSACTION FEATURE EXTRACTOR
# ─────────────────────────────────────────────────────────────

class TransactionFeatureExtractor:
    """
    Extracts 200+ features from raw transaction history.
    This is where behavioral intelligence lives.
    """

    def extract(self, transactions: list[dict]) -> dict:
        if not transactions:
            return self._zero_features()

        txns = self._parse_and_sort(transactions)
        debits = [t for t in txns if t["type"] == "debit"]
        credits = [t for t in txns if t["type"] == "credit"]

        features = {}

        # ── Volume & amount statistics
        features.update(self._amount_stats(debits, "spend"))
        features.update(self._amount_stats(credits, "income"))

        # ── Rolling windows (30/60/90/180d)
        features.update(self._rolling_windows(debits))

        # ── Category distribution (spending diversity)
        features.update(self._category_features(debits))

        # ── Merchant diversity score (Shannon entropy)
        features["merchant_entropy"] = self._entropy(
            [t["category"] for t in debits]
        )

        # ── Payment timing consistency
        features.update(self._timing_features(txns))

        # ── Stress signals
        features.update(self._stress_signals(debits, credits))

        # ── Income stability
        features.update(self._income_stability(credits))

        # ── Night/weekend spending ratio (lifestyle signal)
        features["night_spend_ratio"] = self._night_ratio(debits)
        features["weekend_spend_ratio"] = self._weekend_ratio(debits)

        # ── ATM cash withdrawal frequency (liquidity stress proxy)
        atm = [t for t in debits if t["category"] == "atm_cash"]
        features["atm_frequency_30d"] = len([t for t in atm if t["days_ago"] <= 30])
        features["atm_amount_30d"] = sum(t["amount"] for t in atm if t["days_ago"] <= 30)

        # ── Gambling transactions (strong default predictor)
        gambling = [t for t in debits if t["category"] == "gambling"]
        features["gambling_frequency_90d"] = len([t for t in gambling if t["days_ago"] <= 90])
        features["gambling_amount_90d"] = sum(t["amount"] for t in gambling if t["days_ago"] <= 90)

        # ── Subscription churn (canceling services = financial stress signal)
        features["active_subscriptions"] = len(set(
            t["merchant"] for t in debits
            if t["category"] == "subscriptions" and t["days_ago"] <= 30
        ))

        # ── Loan repayment behavior
        loan_pmts = [t for t in debits if t["category"] == "loan_payment"]
        features["loan_payment_count_30d"] = len([t for t in loan_pmts if t["days_ago"] <= 30])
        features["loan_payment_regularity"] = self._payment_regularity(loan_pmts)

        # ── Spending velocity change (acceleration = stress signal)
        features["spend_velocity_change_30_60"] = self._velocity_change(debits, 30, 60)
        features["spend_velocity_change_60_90"] = self._velocity_change(debits, 60, 90)

        return features

    def _parse_and_sort(self, transactions: list[dict]) -> list[dict]:
        now = datetime.now(timezone.utc)
        parsed = []
        for t in transactions:
            try:
                dt = datetime.fromisoformat(t["date"].replace("Z", "+00:00"))
                days_ago = (now - dt).days
                parsed.append({
                    **t,
                    "dt": dt,
                    "days_ago": days_ago,
                    "amount": abs(float(t.get("amount", 0))),
                    "category": t.get("category", "other"),
                    "type": t.get("type", "debit"),
                })
            except Exception:
                continue
        return sorted(parsed, key=lambda x: x["dt"], reverse=True)

    def _amount_stats(self, txns: list, prefix: str) -> dict:
        if not txns:
            return {f"{prefix}_mean": 0, f"{prefix}_std": 0,
                    f"{prefix}_max": 0, f"{prefix}_total": 0, f"{prefix}_count": 0}
        amounts = [t["amount"] for t in txns]
        return {
            f"{prefix}_mean": float(np.mean(amounts)),
            f"{prefix}_std": float(np.std(amounts)),
            f"{prefix}_max": float(np.max(amounts)),
            f"{prefix}_total": float(np.sum(amounts)),
            f"{prefix}_count": len(amounts),
        }

    def _rolling_windows(self, debits: list) -> dict:
        windows = {}
        for w in [30, 60, 90, 180]:
            subset = [t for t in debits if t["days_ago"] <= w]
            windows[f"spend_total_{w}d"] = sum(t["amount"] for t in subset)
            windows[f"spend_count_{w}d"] = len(subset)
            windows[f"spend_mean_{w}d"] = (
                windows[f"spend_total_{w}d"] / max(1, windows[f"spend_count_{w}d"])
            )
        return windows

    def _category_features(self, debits: list) -> dict:
        features = {}
        total = max(1, sum(t["amount"] for t in debits))
        for cat_name, cat_idx in MERCHANT_CATEGORY_CODES.items():
            cat_txns = [t for t in debits if t["category"] == cat_name]
            cat_amount = sum(t["amount"] for t in cat_txns)
            features[f"cat_ratio_{cat_name}"] = cat_amount / total
            features[f"cat_freq_{cat_name}"] = len(cat_txns)
        return features

    def _entropy(self, categories: list) -> float:
        if not categories:
            return 0.0
        from collections import Counter
        counts = Counter(categories)
        total = sum(counts.values())
        probs = [c / total for c in counts.values()]
        return float(-sum(p * np.log2(p + 1e-9) for p in probs))

    def _timing_features(self, txns: list) -> dict:
        """Consistency of transaction timing — irregular = stress signal."""
        if len(txns) < 3:
            return {"timing_consistency": 0.5, "avg_days_between_txns": 0}
        dates = sorted([t["dt"] for t in txns])
        gaps = [(dates[i+1] - dates[i]).days for i in range(len(dates)-1)]
        return {
            "timing_consistency": 1.0 / (1.0 + float(np.std(gaps))),
            "avg_days_between_txns": float(np.mean(gaps)),
        }

    def _stress_signals(self, debits: list, credits: list) -> dict:
        """Detect financial stress patterns in transaction flow."""
        # Cash flow deficit months
        monthly_deficits = 0
        for month in range(12):
            start, end = month * 30, (month + 1) * 30
            month_debits = sum(t["amount"] for t in debits if start <= t["days_ago"] < end)
            month_credits = sum(t["amount"] for t in credits if start <= t["days_ago"] < end)
            if month_debits > month_credits * 1.1:
                monthly_deficits += 1

        # Overdraft-adjacent: many small transactions at end of month
        eom_small_txns = len([
            t for t in debits
            if t["days_ago"] % 30 >= 25 and t["amount"] < 20
        ])

        return {
            "monthly_deficit_count": monthly_deficits,
            "eom_small_txns": eom_small_txns,
            "cash_flow_stress_ratio": monthly_deficits / 12.0,
        }

    def _income_stability(self, credits: list) -> dict:
        """Stable, regular income is a strong negative default predictor."""
        if not credits:
            return {"income_stability": 0, "income_regularity": 0, "income_sources": 0}
        monthly_income = []
        for month in range(12):
            start, end = month * 30, (month + 1) * 30
            mo = sum(t["amount"] for t in credits if start <= t["days_ago"] < end)
            monthly_income.append(mo)
        cv = np.std(monthly_income) / (np.mean(monthly_income) + 1e-9)
        income_sources = len(set(t.get("merchant", "") for t in credits if t["amount"] > 500))
        return {
            "income_stability": float(1.0 / (1.0 + cv)),
            "income_regularity": float(np.mean([1 if x > 0 else 0 for x in monthly_income])),
            "income_sources": income_sources,
        }

    def _night_ratio(self, debits: list) -> float:
        night = sum(1 for t in debits if t.get("dt") and t["dt"].hour >= 22 or t["dt"].hour <= 5)
        return night / max(1, len(debits))

    def _weekend_ratio(self, debits: list) -> float:
        weekend = sum(1 for t in debits if t.get("dt") and t["dt"].weekday() >= 5)
        return weekend / max(1, len(debits))

    def _payment_regularity(self, payments: list) -> float:
        if len(payments) < 2:
            return 0.5
        dates = sorted([t["dt"] for t in payments])
        gaps = [(dates[i+1] - dates[i]).days for i in range(len(dates)-1)]
        expected_gap = 30.0
        deviations = [abs(g - expected_gap) / expected_gap for g in gaps]
        return float(1.0 - min(1.0, np.mean(deviations)))

    def _velocity_change(self, debits: list, window1: int, window2: int) -> float:
        """Ratio of spending velocity in recent vs older window."""
        recent = sum(t["amount"] for t in debits if t["days_ago"] <= window1)
        older_start, older_end = window1, window1 + window2
        older = sum(t["amount"] for t in debits if older_start < t["days_ago"] <= older_end)
        if older < 1:
            return 0.0
        return float((recent / window1) / (older / window2))

    def _zero_features(self) -> dict:
        """Return zero-valued features when no transaction data."""
        return {
            "spend_mean": 0, "spend_std": 0, "spend_max": 0,
            "spend_total": 0, "spend_count": 0,
            "income_mean": 0, "income_std": 0, "income_total": 0, "income_count": 0,
            "merchant_entropy": 0, "timing_consistency": 0.5,
            "avg_days_between_txns": 0, "monthly_deficit_count": 0,
            "eom_small_txns": 0, "cash_flow_stress_ratio": 0,
            "income_stability": 0, "income_regularity": 0, "income_sources": 0,
            "night_spend_ratio": 0.1, "weekend_spend_ratio": 0.28,
            "atm_frequency_30d": 0, "atm_amount_30d": 0,
            "gambling_frequency_90d": 0, "gambling_amount_90d": 0,
            "active_subscriptions": 0, "loan_payment_count_30d": 0,
            "loan_payment_regularity": 0.5, "spend_velocity_change_30_60": 1.0,
            "spend_velocity_change_60_90": 1.0,
        }


# ─────────────────────────────────────────────────────────────
# MAIN FEATURE ENCODER
# ─────────────────────────────────────────────────────────────

class FeatureEncoder:
    """
    Combines all feature sources into a single normalized feature vector
    ready for ONNX ensemble inference.
    """

    EXPECTED_DIM = 512

    def __init__(self, scaler_params: dict, feature_names: list[str]):
        self.scaler_params = scaler_params  # {"mean": [...], "std": [...]}
        self.feature_names = feature_names
        self.txn_extractor = TransactionFeatureExtractor()

    @classmethod
    def load(cls, path: str) -> "FeatureEncoder":
        with open(path, "rb") as f:
            state = pickle.load(f)
        enc = cls(state["scaler_params"], state["feature_names"])
        return enc

    def save(self, path: str) -> None:
        import pickle
        with open(path, "wb") as f:
            pickle.dump({
                "scaler_params": self.scaler_params,
                "feature_names": self.feature_names,
            }, f)

    def encode(
        self,
        raw: dict,
        macro: dict,
    ) -> tuple[np.ndarray, list[str]]:
        """
        Encode raw features + macro context into normalized feature vector.
        Returns (X, feature_names) where X is shape (1, n_features).
        """
        f = {}

        # ── Bureau features
        f["fico_score_norm"] = (raw.get("fico_score") or 580) / 850.0
        f["revolving_utilization"] = float(raw.get("revolving_utilization", 0.5))
        f["missed_payments_12m"] = min(float(raw.get("missed_payments_12m", 0)), 12) / 12.0
        f["missed_payments_24m"] = min(float(raw.get("missed_payments_24m", 0)), 24) / 24.0
        f["derogatory_marks"] = min(float(raw.get("derogatory_marks", 0)), 10) / 10.0
        f["inquiries_6m"] = min(float(raw.get("inquiries_6m", 0)), 10) / 10.0
        f["oldest_account_months_norm"] = min(float(raw.get("oldest_account_months", 0)), 360) / 360.0
        f["avg_account_age_months_norm"] = min(float(raw.get("avg_account_age_months", 0)), 180) / 180.0
        f["total_accounts_norm"] = min(float(raw.get("total_accounts", 0)), 30) / 30.0
        f["credit_limit_norm"] = min(float(raw.get("total_credit_limit", 0)), 100000) / 100000.0
        f["total_balance_norm"] = min(float(raw.get("total_balance", 0)), 100000) / 100000.0

        # ── Income & employment
        income = float(raw.get("stated_income", 0))
        f["income_norm"] = min(income, 50000) / 50000.0
        f["income_verified"] = 1.0 if raw.get("income_verified") else 0.0
        f["employment_months_norm"] = min(float(raw.get("employment_months", 0)), 120) / 120.0
        emp_type = raw.get("employment_type", "employed")
        for etype, idx in EMPLOYMENT_TYPES.items():
            f[f"emp_{etype}"] = 1.0 if emp_type == etype else 0.0

        # ── Debt-to-income
        loan_requested = float(raw.get("loan_amount_requested", 0))
        monthly_debt_estimated = float(raw.get("total_balance", 0)) * 0.025
        f["dti_ratio"] = min(monthly_debt_estimated / max(income, 1), 2.0)
        f["loan_to_income"] = min(loan_requested / max(income * 12, 1), 5.0)

        # ── Loan purpose
        purpose = raw.get("loan_purpose", "personal")
        for p, idx in LOAN_PURPOSES.items():
            f[f"purpose_{p}"] = 1.0 if purpose == p else 0.0

        # ── Transaction features (200+ features)
        txn_features = self.txn_extractor.extract(raw.get("transactions", []))
        for k, v in txn_features.items():
            f[k] = float(v) if v is not None else 0.0

        # ── Behavioral signals
        f["app_sessions_30d_norm"] = min(float(raw.get("app_sessions_30d") or 5), 100) / 100.0
        f["form_completion_seconds_norm"] = min(float(raw.get("form_completion_seconds") or 300), 1800) / 1800.0

        # ── Macro context (conditions all predictions)
        f["macro_fed_rate"] = float(macro.get("fed_funds_rate", 5.25)) / 10.0
        f["macro_cpi"] = float(macro.get("cpi_yoy", 3.0)) / 15.0
        f["macro_unemployment"] = float(macro.get("unemployment_rate", 4.0)) / 15.0
        f["macro_credit_spread"] = float(macro.get("credit_spread", 100)) / 500.0
        f["macro_hpi"] = float(macro.get("hpi_yoy", 3.0)) / 20.0
        f["macro_sector_stress"] = float(macro.get("sector_stress", 0.2))

        # ── Derived interaction features
        f["util_x_missed"] = f["revolving_utilization"] * f["missed_payments_12m"]
        f["income_x_dti"] = f["income_norm"] * (1.0 - f["dti_ratio"])
        f["gambling_x_deficit"] = (
            min(txn_features.get("gambling_amount_90d", 0), 5000) / 5000.0
            * txn_features.get("cash_flow_stress_ratio", 0)
        )
        f["macro_stress_x_util"] = f["macro_credit_spread"] * f["revolving_utilization"]

        # ── Assemble & normalize
        feature_names = sorted(f.keys())
        values = np.array([f[k] for k in feature_names], dtype=np.float32)

        # Pad or truncate to EXPECTED_DIM
        if len(values) < self.EXPECTED_DIM:
            values = np.pad(values, (0, self.EXPECTED_DIM - len(values)))
        else:
            values = values[:self.EXPECTED_DIM]
            feature_names = feature_names[:self.EXPECTED_DIM]

        # StandardScaler normalization using saved params
        if self.scaler_params:
            mean = np.array(self.scaler_params["mean"][:self.EXPECTED_DIM], dtype=np.float32)
            std = np.array(self.scaler_params["std"][:self.EXPECTED_DIM], dtype=np.float32)
            values = (values - mean) / (std + 1e-8)

        # Clip to [-5, 5] to handle outliers
        values = np.clip(values, -5.0, 5.0)

        return values.reshape(1, -1), feature_names
