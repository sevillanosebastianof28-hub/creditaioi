"""
ORACLE Adversarial Fairness Layer
ai/config/fairness_layer.py

Implements:
  - Adversarial debiasing: fairness trained INTO the loss function
  - Real-time fairness check on every prediction
  - ECOA/FCRA-compliant adverse action reason generation
  - Demographic parity monitoring
"""

from __future__ import annotations
import json
import numpy as np
import onnxruntime as ort
import logging
from dataclasses import dataclass

logger = logging.getLogger("oracle.fairness")


# ─────────────────────────────────────────────────────────────
# ECOA ADVERSE ACTION REASON TEMPLATES
# Legally compliant, feature-derived, no protected class language.
# Source: Regulation B (12 CFR Part 1002), Appendix C
# ─────────────────────────────────────────────────────────────

ECOA_REASON_MAP = {
    "revolving_utilization":       "Proportion of balances to credit limits is too high",
    "missed_payments_12m":         "Delinquent past or present credit obligations with others",
    "missed_payments_24m":         "Delinquent past or present credit obligations with others",
    "derogatory_marks":            "Derogatory public record or collection filed",
    "inquiries_6m":                "Too many inquiries in the last 12 months",
    "oldest_account_months_norm":  "Length of time accounts have been established",
    "total_accounts_norm":         "Number of accounts with delinquency",
    "dti_ratio":                   "Ratio of debt to income",
    "income_norm":                 "Insufficient income",
    "employment_months_norm":      "Length of employment",
    "cash_flow_stress_ratio":      "Insufficient balance in deposit accounts",
    "gambling_amount_90d":         "Proportion of income dedicated to discretionary expenses",
    "atm_frequency_30d":           "Excessive pattern of cash withdrawals",
    "income_stability":            "Inability to verify income",
    "loan_payment_regularity":     "Delinquent past credit obligations",
    "spend_velocity_change_30_60": "Recent increase in debt obligations",
    "macro_sector_stress":         "Current economic conditions in applicant's industry",
}

# Fallback reasons if feature mapping unavailable
FALLBACK_ECOA_REASONS = [
    "Insufficient credit history",
    "Poor payment history",
    "Excessive obligations relative to income",
    "Number of recent inquiries",
]


class AdversarialFairnessLayer:
    """
    Two functions:
    1. TRAIN TIME: adversary model trained to detect protected attribute proxies
       from the main model's output. If adversary succeeds → penalty to main model.
    2. INFERENCE TIME: check each prediction passes fairness threshold.

    Protected attribute proxies we guard against:
    - Geographic clustering (ZIP → income/race proxy)
    - Employer SIC code (occupation → gender proxy)
    - Seasonal payment patterns (cultural calendar proxy)
    - Name-derived patterns (encoded at training time)
    """

    FAIRNESS_THRESHOLD = 0.65  # Adversary must be below near-random confidence

    def __init__(
        self,
        adversary_session: ort.InferenceSession | None,
        fairness_stats: dict,
    ):
        self.adversary_session = adversary_session
        self.fairness_stats = fairness_stats  # Group-level stats for monitoring

    @classmethod
    def load(cls, path: str) -> "AdversarialFairnessLayer":
        try:
            session = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
        except Exception as e:
            logger.warning(f"Fairness adversary ONNX not found ({e}). Using heuristic check.")
            session = None

        # Load fairness stats if available
        stats_path = path.replace(".onnx", "_stats.json")
        try:
            with open(stats_path) as f:
                stats = json.load(f)
        except FileNotFoundError:
            stats = {"group_approval_rates": {}, "score_distributions": {}}

        return cls(adversary_session=session, fairness_stats=stats)

    # ─── INFERENCE-TIME CHECK ──────────────────────────────────

    def check(
        self,
        X: np.ndarray,
        probability: float,
    ) -> tuple[bool, float]:
        """
        Check if this prediction passes the adversarial fairness test.

        Returns:
            (fair: bool, confidence: float)
            fair=True means the adversary CANNOT detect protected attributes
            from this prediction (i.e., prediction is fair).
        """
        if self.adversary_session is None:
            return self._heuristic_check(X, probability)

        try:
            input_name = self.adversary_session.get_inputs()[0].name
            # Adversary input: original features + model output concatenated
            adversary_input = np.hstack([
                X, np.array([[probability]], dtype=np.float32)
            ]).astype(np.float32)

            output = self.adversary_session.run(None, {input_name: adversary_input})
            # Adversary outputs probability distribution over protected attribute classes
            adversary_probs = output[0][0]
            max_confidence = float(np.max(adversary_probs))

            # If adversary is confident → prediction leaks protected info → NOT fair
            is_fair = max_confidence < self.FAIRNESS_THRESHOLD
            return is_fair, round(1.0 - max_confidence, 3)

        except Exception as e:
            logger.error(f"Fairness check error: {e}")
            return True, 0.5  # Fail open — don't block predictions

    def _heuristic_check(
        self, X: np.ndarray, probability: float
    ) -> tuple[bool, float]:
        """
        Heuristic fairness check when adversary model unavailable.
        Checks for known proxy feature patterns.
        """
        # Simple check: is prediction in a range that historically showed bias?
        # In production this is replaced by the adversary model
        extreme = probability > 0.95 or probability < 0.02
        return (not extreme), 0.7 if not extreme else 0.4

    # ─── ECOA ADVERSE ACTION REASONS ───────────────────────────

    def ecoa_reasons(
        self,
        causal_factors: list[dict],
        counterfactuals: list[dict],
    ) -> list[str]:
        """
        Generate ECOA Regulation B compliant adverse action reasons.
        Maximum 4 reasons required by law.
        Derived from causal factors — not protected attributes.
        Never uses race, sex, age, national origin, marital status language.
        """
        reasons = []

        # Primary: use top causal risk factors
        for factor in causal_factors:
            if factor["direction"] != "increases_risk":
                continue
            feature = factor["feature"]
            if feature in ECOA_REASON_MAP:
                reason = ECOA_REASON_MAP[feature]
                if reason not in reasons:
                    reasons.append(reason)
            if len(reasons) >= 4:
                break

        # Supplement from counterfactuals if needed
        if len(reasons) < 4:
            for cf in counterfactuals:
                feature = cf.get("feature", "")
                if feature in ECOA_REASON_MAP:
                    reason = ECOA_REASON_MAP[feature]
                    if reason not in reasons:
                        reasons.append(reason)
                if len(reasons) >= 4:
                    break

        # Pad with fallbacks
        for fallback in FALLBACK_ECOA_REASONS:
            if len(reasons) >= 4:
                break
            if fallback not in reasons:
                reasons.append(fallback)

        return reasons[:4]

    # ─── DEMOGRAPHIC PARITY MONITORING ─────────────────────────

    def update_fairness_stats(
        self,
        group_key: str,
        approved: bool,
        score: int,
    ) -> None:
        """
        Update running fairness statistics for demographic parity monitoring.
        Called after each prediction. Used for CI/CD fairness alerts.
        """
        if group_key not in self.fairness_stats["group_approval_rates"]:
            self.fairness_stats["group_approval_rates"][group_key] = {
                "approved": 0, "total": 0, "scores": []
            }
        stats = self.fairness_stats["group_approval_rates"][group_key]
        stats["total"] += 1
        if approved:
            stats["approved"] += 1
        stats["scores"].append(score)
        # Keep only last 1000 scores in memory
        if len(stats["scores"]) > 1000:
            stats["scores"] = stats["scores"][-1000:]

    def get_fairness_report(self) -> dict:
        """
        Compute demographic parity metrics across all tracked groups.
        Returns Equal Opportunity Difference and disparate impact ratio.
        """
        rates = {}
        for group, data in self.fairness_stats["group_approval_rates"].items():
            if data["total"] > 0:
                rates[group] = data["approved"] / data["total"]

        if len(rates) < 2:
            return {"status": "insufficient_data", "rates": rates}

        values = list(rates.values())
        max_rate = max(values)
        min_rate = min(values)

        return {
            "status": "ok" if (max_rate - min_rate) < 0.1 else "alert",
            "equal_opportunity_difference": round(max_rate - min_rate, 4),
            "disparate_impact_ratio": round(min_rate / max(max_rate, 0.001), 4),
            "group_rates": rates,
            "cfpb_threshold": 0.10,
            "passes_threshold": (max_rate - min_rate) < 0.10,
        }


# ─────────────────────────────────────────────────────────────
# TRAINING-TIME ADVERSARIAL FAIRNESS (PyTorch)
# Used in scripts/train_oracle.py — not at inference time
# ─────────────────────────────────────────────────────────────

ADVERSARIAL_TRAINING_CODE = '''
"""
This code runs during training only (scripts/train_oracle.py).
Shows how adversarial fairness is trained into the model.
"""
import torch
import torch.nn as nn

class OracleMainNetwork(nn.Module):
    """Main credit scoring network."""
    def __init__(self, input_dim=512, hidden=256):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden), nn.GELU(), nn.Dropout(0.3),
            nn.Linear(hidden, hidden//2), nn.GELU(), nn.Dropout(0.2),
        )
        self.output = nn.Linear(hidden//2, 1)  # default probability

    def forward(self, x):
        encoded = self.encoder(x)
        return torch.sigmoid(self.output(encoded)), encoded  # (prob, embedding)


class AdversaryNetwork(nn.Module):
    """
    Adversary: tries to predict protected attribute proxies
    from the main model's output embedding.
    If it succeeds → main model penalized → model forgets the proxy.
    """
    def __init__(self, embedding_dim=128, n_protected_classes=8):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(embedding_dim + 1, 64), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(64, n_protected_classes)
        )

    def forward(self, embedding, prob):
        x = torch.cat([embedding, prob], dim=1)
        return self.net(x)  # logits over protected attribute classes


def adversarial_training_step(main_net, adversary, optimizer_main, optimizer_adv,
                               X, y_default, y_protected, lambda_adv=0.5):
    """
    Minimax training:
    - Adversary maximizes its ability to detect protected attributes
    - Main model maximizes credit prediction accuracy AND minimizes adversary success
    """
    # Step 1: Train adversary (maximize its detection ability)
    prob, embedding = main_net(X)
    adv_logits = adversary(embedding.detach(), prob.detach())
    adv_loss = nn.CrossEntropyLoss()(adv_logits, y_protected)
    optimizer_adv.zero_grad()
    adv_loss.backward()
    optimizer_adv.step()

    # Step 2: Train main model (credit accuracy - adversary ability)
    prob, embedding = main_net(X)
    adv_logits = adversary(embedding, prob)
    credit_loss = nn.BCELoss()(prob.squeeze(), y_default.float())
    fairness_penalty = -nn.CrossEntropyLoss()(adv_logits, y_protected)  # negative!

    total_loss = credit_loss + lambda_adv * fairness_penalty
    optimizer_main.zero_grad()
    total_loss.backward()
    optimizer_main.step()

    return {
        "credit_loss": credit_loss.item(),
        "fairness_penalty": fairness_penalty.item(),
        "total_loss": total_loss.item(),
        "adversary_accuracy": (adv_logits.argmax(1) == y_protected).float().mean().item(),
    }
'''
