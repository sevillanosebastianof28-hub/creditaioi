"""ORACLE AI Config"""
from .oracle_model import OracleModel, OracleScore, get_oracle
