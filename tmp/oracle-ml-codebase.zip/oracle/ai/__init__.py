"""ORACLE AI Package"""
